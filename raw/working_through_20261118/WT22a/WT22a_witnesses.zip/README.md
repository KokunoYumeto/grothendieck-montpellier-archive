# WT22a: the witnesses

- `ours/`: witness O, the Pro first pass MPL_22+23_002-016 (GPT-6 Astra, ChatGPT Pro mode, 9-10 Nov 2026): the page files of this slice, the package's notes and doubts (they cover cotes 22 and 23: the entries about this slice's scans are the ones to consume; `NOTES_INDEX.tsv` lists every entry with the scans it cites), and the first-pass prompt, which defines our macros.
- `hua/`: witness H, the Commutator project of Michel Hua (github.com/Commutator-IO/grothendieck-project, commit aef7db2), batch files of cote 22 and their preamble; their page n is our scan n + 1. A witness, credited; never a basis.
- `page_map.tsv`: per scan, the files of both witnesses.
