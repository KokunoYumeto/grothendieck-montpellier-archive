# Our results so far on these folders (package 60: cotes 22, 23)

Built 2026-11-16 18:41 UTC by `tools_20261113/build_results_state.py` from our own results, selected for this package by its place in the plan (rank 3: the EGA plans, with 127 and 128), its cotes and its subjects (ega). Rebuilt just before the package is sent, so it is as current as our records.

**How to use it.** Read it before you write the research notes, never before the transcription is frozen. Cite an entry by its id (for example **LM4 C.12**). Where an entry settles a point, cite it and add only what these pages change; where these pages bear on an open entry, say how, with the scan and his words. Each entry gives its id, its status in brackets and its source file in parentheses (full paths in the last section).

**Status.** A register row's status is the return's own (Proved, Refuted, Known, Open): a claim of a GPT-6 Astra (ChatGPT Pro mode) run unless an intake verdict follows it. Intake verdicts and the intake files were written by Claude Fable 5.2 at effort high (13 and 14 Nov 2026), the expert's readings by Claude Fable 5.2 at effort max (14 Nov 2026). Research notes of returned packages are first-pass leads. War-game items are our planning guesses (Claude Fable 5.2, 12 Nov 2026), unchecked.
**Referee check (14 Nov 2026, two referees, Claude Opus 5.5 at effort max).** LM7_PUSH checkpoint 09 claims, in E.65, that one character Δ on ĜT₀ reduces E.3 to whether Δ vanishes on ĜT; the chain is D.50 → E.58 → E.65. Refereed and proved as claimed: LM4 D.32, LM4 D.34, LM7_PUSH D.44, LM7_PUSH D.50, LM7_PUSH E.58, LM7_PUSH E.61, LM7_PUSH E.62, LM7_PUSH E.64, LM7_PUSH E.65, LM7_PUSH E.67. 


## Open items: the rows our runs left open, and what we are pushing next (0 of 0 matching entries)

None of ours meets these folders yet.


## Settled in our registers: statements proved, refuted or known (0 of 0 matching entries)

None of ours meets these folders yet.


## Intake readings and implications (0 of 0 matching entries)

None of ours meets these folders yet.


## Research notes of returned archive packages that meet these folders (10 of 10 matching entries)

- **MPL_131 10** [observation (research note of a returned package, first pass; a lead)] 10. Explicit disposition of the planning questions and prior findings: | Context question / ID | Disposition for this package | Evidence | |---|---|---| | Book I I.VI, rank 22: descent and representable functors | **Confirmed** as the core handwritten subject… (MPL_131_notes.md)
- **MPL_147_048-137 §230** [observation (research note of a returned package, first pass; a lead)] Consolidated verified primary bibliography: References are deduplicated across the four research sections. The scope notes record the passages actually used; the manuscript-specific deductions remain those of the research notes. Publication years identify the… (MPL_147_048-137_notes.md)
- **MPL_131 §108** [observation (research note of a returned package, first pass; a lead)] Stacks Project: individually checked stable locators: The Stacks Project Authors. (2026). *The Stacks Project*. Retrieved November 16, 2026, from the stable tag URLs below. The tag, rather than a mutable section number, identifies the result used in each note… (MPL_131_notes.md)
- **MPL_142_001-093 §316** [observation (research note of a returned package, first pass; a lead)] Primary bibliography and verification limits: References use APA author–date form. The entry for SGA 1 follows the publisher's description of the seminar as directed by Alexander Grothendieck, with additional exposés by Michèle Raynaud; the short citation is… (MPL_142_001-093_notes.md)
- **MPL_147_003-047 §85** [observation (research note of a returned package, first pass; a lead)] Published literature and current preprint: Abramovich, D., Caporaso, L., & Payne, S. (2015). The tropicalization of the moduli space of curves. *Annales scientifiques de l'École Normale Supérieure, 48*(4), 765–809. [https://doi.org/10.24033/asens.2258](https:… (MPL_147_003-047_notes.md)
- **MPL_147_138-190 §143** [observation (research note of a returned package, first pass; a lead)] Primary literature: APA references and verified supporting locations: Artin, M., Grothendieck, A., & Verdier, J.-L. (Eds.). (1972). *Théorie des topos et cohomologie étale des schémas (SGA 4), Tome 1: Théorie des topos* (Lecture Notes in Mathematics, Vol. 269… (MPL_147_138-190_notes.md)
- **MPL_15_087-138 1** [observation (research note of a returned package, first pass; a lead)] 1. Rational zero-dimensional correspondences and their matrices: Fix the separable closure \(k^{\mathrm{sep}}\), the profinite group \(\Gamma_k\), and finite étale \(k\)-schemes \(X,Y\). The symbols \(\mathbb Q^{S_X}\) and \(\mathbb Q[S_X]\) are identified by… (MPL_15_087-138_notes.md)
- **MPL_33_147-181+34_002-017 11** [observation (research note of a returned package, first pass; a lead)] 11. Checked primary comparisons and APA references: These sources were retrieved after the transcription freeze on **16 November 2026**. The exact inspected passages and limits below govern the citations in the numbered notes. A modern theorem may test a chos… (MPL_33_147-181+34_002-017_notes.md)
- **MPL_33_147-181+34_002-017 8.3** [observation (research note of a returned package, first pass; a lead)] 8.3. Cote 34: all fifteen retained leaves: The manuscript-page and marginal-numeral sequences are recorded separately; neither is a source-wide total-page count. “Continuation” below is an editorial description of the retained text, not a supplied title. | Sc… (MPL_33_147-181+34_002-017_notes.md)
- **MPL_36_053-085+39 §115** [observation (research note of a returned package, first pass; a lead)] Primary bibliography and comparison limits: These sources were checked after the freeze, only for research notes. They supply comparison targets and definitions; none was used to rewrite the transcription. The cited original SGA pages were also inspected visu… (MPL_36_053-085+39_notes.md)


## Questions of our planning document (the war game) for these folders (1 of 1 matching entries)

- **WG2 §2.1 #2** [question or plan item of the war game (round 2; unchecked)] 2.1 What came back: 16 ; 54 ; 37 ; (a) "Sur certains anneaux gradués", ms. pp. 1–16, nos 1–8 (scans 3–18): graded rings of endomorphisms with their grading projectors π_i; uniqueness and existence of the π_i; the "conditions de Lefschetz"; the universal ring Φ₀ = Z[L₀, Λ₀] acting on the exterior algebra of a symplectic lattice;… (PROGRAM_WARGAME_ROUND2_20261112.md)

## Findings of another project on these pages, to check (Michel Hua, github.com/Commutator-IO/grothendieck-project)

AI-produced in his project (its README names the models used) and taken from its findings register; their page n is our scan n + 1. These are claims to check, not results. While you write the research notes, check each one against these pages: does the page support it, what does it add, what does it get wrong; cite it as "Hua, findings register, <id>". After each entry: our intake verdict (Claude Fable 5.2 at effort medium, statement level only, 14 Nov 2026).

- **22-power-series-discrete-obstruction** (cote 22, their pp. 22, 24; our scans 023, 025) [conjecture (candidate: their search found no reference) | L…] For k = ℚ(x_i : i ∈ I) with I infinite, A = k[[t]] is formally smooth over k for its t-adic topology but not for the discrete topology: no derivation D : A → Ω¹_k ⊗_k A ≅ A^{(I)} induces d_k, because D(Σ x_{i_n} tⁿ) would have infinitely many non-zero components. Our intake: new to us: our package for this cote is waiting
- **22-p23-proposition-reconstruction** (cote 22, their pp. 22–24; our scans 023, 024, 025) [conjecture (unsearched) | Lean card: partly proved] Page 23’s Proposition: for a field extension K/k with Ω_{K/k} of infinite dimension over K and A = K[[t_1,…,t_n]], n > 0, with the discrete topology, there is no derivation D : A → Ω_{K/k} ⊗_K A inducing d_{K/k}, so Ω_{K/k} ⊗_K A → Ω_{A/k} has no left inverse and A is not formally smooth over K; the page adds that it is « a fortiori »… Our intake: new to us: our package for this cote is waiting
- **22-differentials-kernel-counterexample** (cote 22, their pp. 26, 28; our scans 027, 029) [conjecture (unsearched) | Lean card: partly proved] For a field extension K/k in characteristic p > 0, the map Ω¹_{k/(k∩K^p)} ⊗_k K → Ω¹_K need not be injective. Our intake: new to us: our package for this cote is waiting

## The runs these entries come from, and their state

- (none of the runs above has a row in MATHS_PROMPTS_TALLY.md)

## Source files (relative to the Documents folder of our records)

- `grothendieck_archive_montpellier/PROGRAM_WARGAME_ROUND2_20261112.md`
- `grothendieck_archive_transcription_20261110/returns/MPL_131_unzipped/MPL_131_notes.md`
- `grothendieck_archive_transcription_20261110/returns/MPL_142_001-093_unzipped/MPL_142_001-093_notes.md`
- `grothendieck_archive_transcription_20261110/returns/MPL_147_003-047_unzipped/MPL_147_003-047_notes.md`
- `grothendieck_archive_transcription_20261110/returns/MPL_147_048-137_unzipped/MPL_147_048-137_notes.md`
- `grothendieck_archive_transcription_20261110/returns/MPL_147_138-190_unzipped/MPL_147_138-190_notes.md`
- `grothendieck_archive_transcription_20261110/returns/MPL_15_087-138_unzipped/MPL_15_087-138_notes.md`
- `grothendieck_archive_transcription_20261110/returns/MPL_33_147-181+34_002-017_unzipped/MPL_33_147-181+34_002-017_notes.md`
- `grothendieck_archive_transcription_20261110/returns/MPL_36_053-085+39_unzipped/MPL_36_053-085+39_notes.md`
