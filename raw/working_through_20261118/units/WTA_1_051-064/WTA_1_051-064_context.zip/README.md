# The context of WT_1_051-064

- `this_folder/cote_1.tex`: the whole folder as transcribed so far, each page in the reading a pass starts from, for the argument before and after this range
- `topics/SA23_TOPIC.md`: the catalogue of the topic (its folders, what is transcribed and how)

No earlier range of this topic has been worked through yet; when one has, its tables join this context as `earlier_ranges/`.
