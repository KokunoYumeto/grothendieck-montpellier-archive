# The context of WT_81_002-011

- `this_folder/cote_81.tex`: the whole folder as transcribed so far, each page in the reading a pass starts from, for the argument before and after this range
- `esquisse/esquisse_cote119.tex`: Esquisse d'un programme (1984), the typescript in the archive (cote 119), transcribed by Claude Opus 5.5 over the API
- `esquisse/cote119_rest.tex`: the rest of the 1984 CNRS dossier (cote 119), transcribed by Claude Opus 5.5 over the API
- `neighbours/cote_75.tex`: cote 75, Cours C4, DEA (notes, a letter of 1978, the 1977-1978 typescript), as transcribed
- `neighbours/cote_72.tex`: cote 72, regular polyhedra and hyperpolyhedra, as transcribed so far
- `neighbours/cote_83.tex`: cote 83, as transcribed so far
- `neighbours/cote_84.tex`: cote 84, as transcribed so far
- `topics/SA01_TOPIC.md`: the catalogue of the topic (its folders, what is transcribed and how)

No earlier range of this topic has been worked through yet; when one has, its tables join this context as `earlier_ranges/`.
