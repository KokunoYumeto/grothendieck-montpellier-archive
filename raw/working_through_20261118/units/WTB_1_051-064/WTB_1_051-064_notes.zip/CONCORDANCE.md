# The concordance of WT_1_051-064

For every object (the sweep's tag) that the notes on these pages are about, the entries on the same object elsewhere in the archive, nearest first (the same folder, then the same topic, then other topics), with their text.

# H0CX: Hilbert tensor products and vector-valued L2 spaces

- its entries on these pages: codex:K1-01#1, work:K1-01#1, work:K1-01#2, work:K1-01#3, work:K1-01#4, work:K1-01#5, work:K1-01#6
- in the archive: 2 entries; 1: 51-64

# H0D8: Fredholm theory: trace-class operators, Fredholm determinants det(1+zu), exterior powers of operators

- its entries on these pages: codex:K1-01#1, work:K1-01#1, work:K1-01#2, work:K1-01#3, work:K1-01#4, work:K1-01#5, work:K1-01#6
- in the archive: 6 entries; 1: 51-64,65-78,79-92

## codex:K1-02#1 (same folder; 1: 65-78): Steps the pages themselves mark as unverified

| Scan and approximate line | Words or mark on the sheet | What is left open |
|---|---|---|
| 67, short sideways direction | “à développer en rédigeant le cas de la dimension finie” | A revision instruction singles out the finite-dimensional case for fuller treatment. The verb is doubtful. |
| 68, last line | “matrice triangulaire” followed by a disputed hook and small word | The hook may be punctuation. Its status as a question about the triangular-matrix argument is uncertain. |
| 69, lines 4–8 | “dans un sens évident à préciser” | The continuity of the whole system of eigenvalues is invoked in passing from finite rank to compact operators. The precise sense of continuity is deferred. |
| 71, after (5), by the rejected pair of norm formulas | “(deux références)” and a marginal “?” | The justification needs references. The question mark stands beside a cancelled corollary, so its exact target is uncertain. |
| 71, after (10) | “Pour la preuve, on … ramènera au cas où $u$ est hermitien positif, où c'est facile” | The reduction for the determinant theorem is announced. These sheets do not carry it out. |
| 72, lower left at (16)–(17) | “notation ? à réviser” | A slanted pencil direction calls for another look at the notation. The mark following “notation” is doubtful. |
| 73, first argument below Proposition 3 | “pour tout $i$ (---)” | There are strokes where a justification or reference for the singular-value comparison might belong. Their meaning is uncertain. |
| 74, lines 1–6 | “semblent les inégalités les plus fortes possibles” and “on pourrait déduire … directement l'inégalité (15)” | Optimality is tentative. A direct deduction from (12) is suggested. |
| 74, after (18) | “le raisonnement est … laissé au lecteur” | The proof of the determinant supremum formula is left to the reader. |
| 76, middle and last lines | “Question … Trouver la forme générale des fonctions $f$ d'une variable positive” and “Généralisation à des fonctions de $n$ arguments.” | The classification and its generalization are posed here. |
| 78, top insertion | “(vérifier d'après cas décomposable)” | The insertion points to verification of the finite-rank case of (14), before the appeal to continuity. |

## codex:K1-03#1 (same folder; 1: 79-92): Steps marked as unverified

- Scan 82, lower left of the continuity argument. A faint mark can be read as “?”. Its attachment to a particular step is uncertain.
- Scan 90, left of the cancelled continuation after Corollaire 4. A pencilled circled “?” lies below a heavily crossed inequality. It cannot be assigned securely to one inequality sign.
- Scan 92, lower slip beside (39). A pencilled “?” sits to the left of the formula, near the condition on the arguments. Its scope is uncertain.

Scan 80 explicitly says “Nous supposons connu” in a cancelled argument. This is an appeal to an assumed result. The unresolved “N° ?” references on scans 87 and 91 identify missing cross-references.

## work:K1-02#1 (same folder; 1: 65-78): What the pages do

**U01 · Composition and adjoints, scan 65.** Formula (10) composes two induced exterior-power maps. The two lines of (11) pass an adjoint through a mixed exterior product and through a pure exterior power. A crossed-out polarization route survives above the calculation. In the live calculation, the determinant of the pairings $(u a_i,b_j)$ is the determinant of $(a_i,u^*b_j)$.

**U02 · Positivity and positive powers, scans 65–66.** The author writes $h=k^2$ and takes the exterior power of both sides. He then treats positive integral and reciprocal-integral exponents, passes to rational exponents, and appeals to continuity in the exponent for (12). Proposition 1 collects boundedness of the mixed product and the multiplicative and adjoint properties of the pure power. The statement breaks off after “opérateurs positifs en”. Its verbal continuation is at the head of scan 77.

**U03 · Eigenvalues of an exterior power, scans 67–69.** Proposition 2 on scan 67 lists the products $\lambda_{i_1}\cdots\lambda_{i_n}$ for strictly increasing indices. In the finite-rank case the author splits off a space $E_1$ on which $u$ vanishes. In the exterior-power decomposition all terms containing a factor from $E_1$ vanish. The remaining term is computed on the finite-dimensional $E_0$ using a triangular matrix. Scan 69 appeals to approximation for a general compact operator. The struck sideways note on 67 also discusses the order and multiplicity of the eigenvalues.

**U04 · Two different products, scan 69.** In the side-written corollary, (21) expresses the leading eigenvalue of an exterior power as a product of eigenvalues, while (22) expresses its norm as a product of singular values. In the main text, (23) bounds the absolute value of the first product by the second. The lower diagonal lines continue a computation begun sideways beside (22).

**U05 · Composition of compact maps, scans 69–70.** The statement beginning at the foot of 69 becomes the product inequality (24) at the top of 70. The short live argument applies the operator norm bound for a product to the exterior powers. A much longer crossed calculation in terms of $(uv)(uv)^*$ remains legible in parts.

**U06 · Trace coefficients and determinant, scan 71.** The new outline begins with a factorial bound on the trace norm of a mixed exterior product. It identifies $\alpha_n$ with a trace and compares $|\alpha_n(u)|$, $\alpha_n(|u|)$ and the trace norm of the exterior power. Several numbered corollaries are cancelled and their numbers reused. The determinant statement under the live Corollaire 4 is discussed below (S71).

**U07 · Genus zero, scan 71.** Théorème 1 states summability of the eigenvalues and a product formula for $\det(1+zu)$. The following lines express the coefficients as elementary symmetric sums in the eigenvalues, give the trace as their sum, and give the corresponding positive expression in the singular values. A reduction to the positive Hermitian case is announced.

**U08 · Mixed products and determinants of a sum, scans 71–72.** Prop 2 estimates the product of a $p$th and a $q$th exterior power with factor $p!q!/(p+q)!$. Scan 72 expands the two operators as sums of rank-one tensors. Sorting the two families of indices produces the factorials. The next two corollaries compare the determinants for $u+v,u,v$ and then their individual coefficients. The expansion of $\Lambda^n(u+v)$ supplies the binomial coefficients.

**U09 · Partial products and a supremum, scans 72–73.** Théorème 2 gives a bounded-length analogue of the determinant inequality. The notation $\sigma_n^m$ in (17) sums products of $m$ of the first $n$ singular values. Scan 73 relates it to a supremum over contractions of rank at most $n$. A finite-rank lemma gives the upper bound. The author pairs the two singular-vector systems to attain it, then applies the coefficient inequality (14) to the compressed sum to reach (16).

**U10 · A determinant supremum, scan 74.** The author asks how strong the simultaneous partial-product inequalities are and suggests a direct route from (12) to (15). Proposition 4, labelled (18), sets the product of the factors $1+\rho_i(u)$ equal to a supremum involving $\det(1+v_nu)$. The same norm and rank restrictions on $v_n$ appear as on 73.

**U11 · Logarithms and decreasing weights, scan 75.** Taking logarithms of the partial products gives an additive inequality. The page introduces an integral transform $f_\varphi$ and a sum $S_\varphi^n$ over singular values. The faint parenthesis uses integration by parts to pass from a comparison of two functions to a comparison involving their derivatives against a decreasing weight. A step-shaped weight is drawn beside the converse observation.

**U12 · Power sums and the question on functions, scans 75–76.** Substituting $\varphi(r)=r^{-p}$ with $0<p<1$ gives a constant times $\rho^p$. Scan 76 boxes a subadditivity bound first for a finite initial sum and then for the untruncated sum. A separate “Remarque” compares another pair of sums and invokes Weyl. The “Question” asks which functions of one positive variable give the indicated subadditivity for every $n$.

**U13 · Mixed products of Fredholm maps, scan 77.** Proposition 3 bounds the trace norm of $u_1\wedge\cdots\wedge u_n$ by $1/n!$ times the product of the individual trace norms. For rank-one $u_i=\bar b_i\otimes a_i$, the mixed product is written as a single tensor of two wedge products divided by $n!$. The passage to general operators uses continuity.

**U14 · Trace and Hilbert–Schmidt norms, scans 77–78.** Corollaire 1 gives the mixed and pure trace identities (14). Scan 78 adds the verification note and derives (15). Corollaire 3 expresses the trace norm using $\alpha_n(|u|)$ and the square of the Hilbert–Schmidt norm using $\alpha_n(u^*u)$. The proof uses the adjoint-product identity and writes the positive square root as a power $1/2$.

## work:K1-02#2 (same folder; 1: 65-78): Statements left without proof

| Scan | Wording on the sheet | Scope |
|---|---|---|
| 66 | “on sait que … est une fonction … de $\alpha>0$” | The continuity of positive operator powers as a function of the exponent is invoked here. |
| 68–69 | “Il est bien connu” and “dans un sens évident à préciser” | The triangular-matrix step is indicated. The continuity of the eigenvalue system used for passage to the compact case is left imprecise. |
| 71 | “Corollaire 4” and “Théorème 1 … de genre 0” | No derivation accompanies the determinant corollary. The theorem has an announced reduction to the Hermitian positive case and no completed proof in this set of scans. |
| 71, after (11) | “le même vrai pour plus de deux facteurs” | The argument that follows on 72 treats two groups of factors. |
| 73 | “comme on a $\rho_i(v_nu)\leq\rho_i(u)$ pour tout $i$” | Used in the supremum argument. The parenthesis immediately after it contains short strokes. |
| 74 | “se démontre comme (17)” and “laissé au lecteur” | The proof of the displayed determinant supremum is explicitly deferred. |
| 76 | “Il suffit qu'on ait” | The sufficiency of the untruncated inequality in the classification question is asserted briefly. |
| 78 | “vérifier d'après cas décomposable” | The finite-rank verification of (14) is still marked for checking. |

## work:K1-02#3 (same folder; 1: 65-78): Questions and conjectures

- **Scan 68.** After “matrice triangulaire” there is a small hook followed by a contracted word. Whether this is an authorial question is unresolved.
- **Scans 71–72.** A separate “?” stands next to the cancelled pair of norm identities on 71. The side note “notation ? à réviser” on 72 concerns the $\sigma_n^m$ notation.
- **Scan 74.** The inequalities “semblent les inégalités les plus fortes possibles” concerning the singular values of $u+v$ given those of $u$ and $v$. The formulation of optimality is left open.
- **Scan 76.** “Trouver la forme générale des fonctions $f$ d'une variable positive” for which the displayed inequality holds “quel que soit $n$”. At the end of the preceding remark, “on trouve rien de spécial” may also carry a question mark. The last line asks for a “Généralisation à des fonctions de $n$ arguments.”

## work:K1-02#4 (same folder; 1: 65-78): Slips

| ID | Scan and reading | Apparent correction and reason | Confidence |
|---|---|---|---|
| S66 | 66, near the argument by continuity, the exponent of $h$ looks like $1/\alpha$ or $\alpha$ | The target (12) on 65 calls for $h^\alpha$. The short stroke before the exponent is disputed. The first parenthetic formula reference on 66 could likewise be (12) instead of the apparent (11). | Low, both readings are marked. |
| S69 | 69, “la prop. 3” in the compact-spectrum proof | The statement on 67 that this paragraph finishes is headed “Proposition 2”. If this is an internal reference within this version, 2 is intended. | Medium, a working renumbering is possible. |
| S70 | 70, “en vertu de (23)” in the proof of (24) | The exact norm identity invoked twice is (22) in the margin of 69. Formula (23) there is an inequality. At the end of 70, “(13) et (14)” may likewise be earlier labels for (23) and (24). | High for the norm identity, medium for the final pair of labels. |
| S71 | 71, live Corollaire 4, $\vert \det(1+u)\vert =\det(1+\vert u\vert )$ | For the scalar $u=-1$, the two sides are 0 and 2. A plausible replacement is $\leq$ (S71a). The computation rules out equality as a universal statement. | High for the counterexample to the printed reading. |
| S72 | 72, the line after “d'où” juxtaposes $\alpha_n(\vert u+v\vert )$ and $\Vert \Lambda^n(u+v)\Vert _1$ | The inserted identity just above has an equals sign in that position. | High for the absent relation in this line. |
| S73a | 73, “projecteur hermitien de rang $n$ pour $E$ de dimension $\leq n$” | For dimension strictly smaller than $n$, such a projection cannot have rank $n$. “De rang $\leq n$”, or the reversed dimension condition if exact rank is required, would avoid the obstruction (S73b). | High for the rank obstruction, medium for the intended repair. |
| S73c | 73, “Prouvons maintenant (16)” ends “d'où la formule (18)” | The displayed bound proved by summing the two $\sigma$ terms is (16) on 72. | High for the mismatch. |
| S74 | 74, (18), $\sup\det(1+v_nu)$ | For complex spaces the displayed determinant can be nonreal. Absolute-value bars would give the supremum its ordinary real meaning (S74a). The example $u=1,\ v_n=i$ yields $1+i$. | High for the issue with the literal complex supremum, medium for the intended repair. |
| S75 | 75, $A'(r)=\sum r/(1+r\rho_i(u))$ | The derivative of a summand $\log(1+r s)$ is $s/(1+rs)$. With $s=\rho_i(u)$ the numerator should be $\rho_i(u)$ (S75a). | High, the final reading of the numerator is unmarked. |
| S76 | 76, “Remarque”, $\sum\rho_i(u+v)^p\leq\sum(\rho_i(u)+\rho_i(v))^p$ | For $p=1/2$, two orthogonal rank-one projections in dimension two give $2$ on the left and $\sqrt2$ on the right. The boxed comparison immediately above uses separate sums of $p$th powers (S76a). | High for the literal inequality in the stated range. |
| S78 | 78, (15), the right side has ordinary double bars with no subscripts | If the bars mean operator norm, $n=1$ and $u=I_2$ give $2\leq1$. The trace norms in (13) would give $2\leq2$ (S78a). | High for the numerical distinction, medium for whether an implicit norm convention was intended. |

## work:K1-02#5 (same folder; 1: 65-78): Pointers

| Scan | Words or reference | What the page invokes |
|---|---|---|
| 65 | “voir Introduction, 2, formule (8,--)” | The expansion of a mixed exterior product in pure powers. The trailing marks in the reference are not clear. |
| 69 | “Voir conventions de notation … au N° 1” | The notation used in the boxed product inequalities. |
| 70, 76 | “H. Weyl”; “le lemme de Weyl” | The first attributes the demonstration and its application to Weyl. The second invokes a lemma in the power-sum discussion. No title is supplied. |
| 77 | “voir Chap I, N° 1, formule (8)” and “formule (5…)” | The rank-one tensor formula and the bound for the norm of a wedge. |
| 77–78 | “Chap 1, § 2, prop 1”; “Chap I, § 1, N° 2, définition 1”; “N° 2, prop 1” | The definition of the trace coefficient, the finite-rank case and the stated normalization of the coefficient. |
| 78 | “N° 1, formule (22)”, “prop 1”, “N° 1, th. 4”, “N° 1, th. 3, corollaire 3” | Earlier trace, adjoint-product and Hilbert–Schmidt facts used in (16)–(17). |

## work:K1-02#6 (same folder; 1: 65-78): Remarks of the model

- **Model remark M1, high confidence.** The sentence ending on scan 66 resumes at the first words of 77. “et opérateurs positifs en” is followed there by “/ op. hermitiens positifs, enfin satisfait à la formule (12).” This local join explains why the first line of 77 reads differently from the proposition immediately below it.
- **Model remark M2, medium confidence.** The two appearances of the factorial estimate, on 71 and 77, anchor two numbering sequences. The trace identities are (2)–(3) on 71 and (14) on 77. A cross-reference can sometimes identify a different stage of the same writing. The pages establish the correspondence of the formulas more firmly than the chronology.
- **Model remark M3, low confidence.** In the definition after “Question” on 76, the independent reading of the summand is $\rho_i(u)$ or $f_i(u)$. The final text also records $f(\rho_i(u))$. The question about varying $f$ favours the last expression. The ink has too few distinguishable strokes to establish it.
- **Model remark M4, low confidence.** The crossed definition $w=vu$ near the top of 70 and the surviving $uv$ in (24) run in different orders. Formula (10) on 65 makes the order of composition explicit, but the earlier definition on 70 is struck. These pages do not settle whether the author meant to reverse the maps in the statement or change the product notation.

## work:K1-03#1 (same folder; 1: 79-92): What the pages do

**M01 · Fredholm coefficients, scan 79.** Corollaires 4 and 5 compare the coefficients of $\det(1+zu)$ with the corresponding positive-operator coefficients, then compare the determinants. The proof uses the trace of an induced operator. The order of the two factors under one radical is doubtful.

**M02 · Eigenvalues, determinant and trace, scans 79–80.** A cancelled theorem expresses the Fredholm determinant by a product over eigenvalues. The turned note links its coefficients to elementary symmetric sums and its first coefficient to the trace. The draft considers orthogonal projection onto a span of eigenvectors, the zeros of the entire determinant and the expansion in rank-one tensors for a positive operator. Its last calculation groups tuples that differ only by their order.

**M03 · Supporting affine functions, scan 81.** The author places a hyperplane through a boundary point of the strict epigraph of a convex function. He writes its affine equation, compares its height with the function and describes the function as the supremum of such supports. For monotonicity he varies one coordinate at a time. A small curve and a marked point accompany this argument.

**M04 · Two forms of the convexity theorem, scan 82.** The theorem marked “(H. Weyl)” starts from decreasing $\alpha_i$ and upper bounds on their prefix sums. It compares the values of a convex symmetric function under either coordinatewise monotonicity or equality of the full sums. The multiplicative form uses prefix products and convexity after exponentiating the arguments. For strictly positive entries the change of variables is logarithmic.

**M05 · Boundary points, scans 82–83.** The author approximates admissible nonnegative systems by positive ones for the increasing-function case. Several longer constructions involving primed and double-primed entries are struck. The shorter surviving prescription keeps the rho sequence and adds epsilon to the sigma sequence at this stage of the argument.

**M06 · Proof of the additive comparison, scans 83–85.** Affine supports reduce the comparison of functions to a comparison of weighted sums. Symmetry permits permutations of a support. The rearrangement lemma places the coefficients in decreasing order. Formula (9) then writes the weighted sum as a combination of prefix sums. The last coefficient explains the separate roles of monotonicity and equality of the totals.

**M07 · Reciprocal sequences, scan 85.** After (9) a corollary compares the function on two lists of reciprocals. The argument divides the equal full products by prefix products and reverses the order of the entries. The written directions of comparison matter here, both in the proof and in (10). See S11–S12.

**M08 · Truncation and norms, scans 86–87.** The first remark passes to shorter sequences for the increasing-function comparison. A marginal converse tests a function inequality against sums over subsets of indices. The examples include an increasing convex function composed with exponentials and a normalized symmetric norm invariant under changes of sign. The margin discusses monotonicity of the norm by means of its unit ball. A later marginal formula pads the shorter vector with zeros.

**M09 · Separable functions and powers, scans 87–88.** The single sheet at scan 88 builds a function of several variables by summing one-variable functions and applies the two theorem hypotheses to full sums and prefixes. The choice $f(s)=s^p$ gives $f(e^t)=e^{pt}$. These are the examples associated with (13)–(16), whose numbers run across the two physical sheets in a different order. An unfinished converse is crossed out on scan 87.

**M10 · Eigenvalues and singular values, scans 87 and 89.** The first Hilbert-space convexity theorem compares $f(|\lambda_1|,\ldots,|\lambda_n|)$ with $f(\rho_1,\ldots,\rho_n)$ for a compact operator. Corollaries apply it to prefix sums and their limits, to positive powers and to the Fredholm and Hilbert–Schmidt cases. The two separate formulae numbered (21) are retained in the transcription.

**M11 · Determinants and extension of norms, scans 89–91.** In finite dimension the equality of full products permits the comparison without coordinatewise monotonicity, subject to invertibility or boundary continuity. The turned calculation on scan 90 identifies the singular-value product with the absolute determinant. A second corollary compares finite-dimensional Schatten norms. For a sequence $\xi$, scan 91 defines $N(\xi)$ by the increasing limit of the norms of its zero-padded truncations, allowing an infinite limit.

**M12 · Products of compact operators, scan 91.** The second Hilbert-space convexity theorem compares a function of the singular values of a composite with the same function of the coordinatewise products of the two singular-value lists. The corollary gives finite and infinite sum inequalities. A crossed strip below the main page discusses multiplication operators and a further corollary left to the reader. The written orders $uv$ and $vu$ need attention wherever the two letters nearly coincide.

**M13 · Hölder and the trace, scan 92.** The long turned insertion specializes the sum comparison, gives a sufficient condition for the composite to be Fredholm and writes a bound on its trace. The main text applies scalar Hölder to obtain bounds in terms of two power norms, then singles out conjugate exponents and the trace norm. The marginal corollary number is uncertain.

**M14 · Equal finite dimensions, scan 92.** The lower slip removes monotonicity under an invertibility or continuity hypothesis. Its proof identifies the full product in (40) with the absolute determinant of the composite and the product of the two absolute determinants. A limiting argument covers boundary points. The final pencil line is an instruction about composition of operators.

## work:K1-03#2 (same folder; 1: 79-92): Statements left without proof

| ID and scan | Manuscript wording | What is assumed or deferred |
|---|---|---|
| U01 · 80, cancelled margin | “Nous prouvons au N° suivant que” followed by $\sum\lvert\lambda_i\rvert\leq\lVert u\rVert_1$. | The stronger eigenvalue-sum estimate is deferred. It occurs again at the second (21) on scan 89. |
| U02 · 80, cancelled argument | “Nous supposons connu qu'une fonction entière dont les inverses des zéros forment une suite sommable” | The author assumes the genus-zero criterion with the stated majorization of coefficients. |
| U03 · 83 | “Il est bien connu qu'une” … “fonction convexe” … “est de la forme” | A short geometric explanation accompanies the affine-supremum representation. The separation fact used to obtain closed half-spaces is invoked. |
| U04 · 84–85 | “D'après un lemme connu” | The assertion that the decreasing ordering maximizes the weighted sum is used here without a proof of that lemma. |
| U05 · 87 and 91 | “Il suffit en effet de conjuguer” and “en vertu du N°” … “corollaire 3.” | Both Hilbert-space theorems use previously numbered operator estimates. The section numbers in the references are doubtful. |
| U06 · 90 | “les deux mbs sont des fonctions continues de $u$ comme on vérifie aussitôt” | Continuity is used in passing from invertible operators to the boundary. |
| U07 · 91, cancelled lower sheet | “donner un corollaire” … “mais en laissons l'énoncé au lecteur.” | The author leaves the formulation to the reader. |
| U08 · 92 | “grâce à l'inégalité” followed by a tentative reading “de Hölder ordinaire” | The scalar inequality used in the norm and trace estimates is invoked. |

## work:K1-03#3 (same folder; 1: 79-92): Questions and conjectures

| ID and scan | Words or mark | Scope |
|---|---|---|
| Q01 · 82 | “?” (uncertain) | A pencil mark beside the boundary argument. The exact step is unclear. |
| Q02 · 87 | “réciproquement” | A cancelled attempt at a converse breaks off. No complete proposed converse survives. |
| Q03 · 90 | Circled “?” | Beside a rejected marginal inequality. The crossing strokes obscure both its indices and the target of the question mark. |
| Q04 · 92 | “?” beside (39) | A separate pencil mark on the lower slip. Its position could refer to the hypothesis or to the formula. |
| Q05 · 92 | “Généraliser l'inégal. du (29).” and “Donner des” … “sur la composition des opérateurs” | These are instructions for further work. The noun in the second instruction is doubtful. |

None of the surviving passages gives a fully worded conjecture with an explicit assertion of uncertainty.

## work:K1-03#4 (same folder; 1: 79-92): Slips

Proposed corrections describe the local argument. Confidence refers to the proposed identification of a slip, including the reading on which it depends.

| ID and scan | Reading on the sheet | Possible corrected form | Reason and confidence |
| --- | --- | --- | --- |
| S01 · 79, cancelled formulae and turned note | (20), reference to (21), then (22), and (23) twice in the margin | A different earlier numbering may underlie the references. | Both a determinant and its coefficients appear during renumbering. The cancellations prevent a unique reconstruction. Low confidence. |
| S02 · 80, lines 1–7 | Σ\|zᵢ\| in the statement and \|z₁+…+zₙ\| in the projection calculation | An additional argument, or the weaker absolute value of a sum | The following calculation gives the second expression directly. The stronger assertion and the marginal qualification are both within a cancelled draft. Low confidence. |
| S03 · 81, lines 12–14 | « pour x∈E » | « pour x∈U » | The sheet initially defines f on U, the open convex set. The switch could also be a tacit enlargement of the domain. Medium confidence. |
| S04 · 81, last line | f(x₁)≤f(a)≤[underlined f / L / f](x₁) | L(x₁) would serve as the final term. | The preceding sentence calls the affine minorant L. The mark on the final letter is ambiguous. Low confidence. |
| S05 · 83, lines 5–6 | σₙ=0, followed by « avec σₙ>0 » | σ′ₙ>0 | The unprimed term describes the starting system. A positive last term is sought for the approximating one. Medium confidence. |
| S06 · 83, lines 22–30 | « Lₖ(t)≥0 » in the description of the half-spaces | An inequality involving the vertical coordinate as well | The cited set is in Rⁿ×R and the surrounding argument concerns a graph. The line is reworked. Low confidence. |
| S07 · 84, lines 8–9 | L(t)→0, alternative ∞ | L(t)→+∞ | A negative coordinate coefficient is being evaluated as its coordinate tends to minus infinity. A point of the written limit is doubtful. Low confidence. |
| S08 · 84, lines 20–25 | « des aᵢ>0 » | aᵢ≥0 would suffice. | Scan 83 concludes only nonnegativity, which is enough for the subsequent comparison. Medium confidence. |
| S09 · 85, lines 10–12 | aᵢ−aᵢ₋₁, alternative aᵢ−aᵢ₊₁ | aᵢ−aᵢ₊₁ | The displayed expansion (9) lists forward neighbouring pairs. The little sign is doubtful. Low confidence. |
| S10 · 85, lines 15–19 | « l’inégalité (1) » | (3) is the conclusion at the start of the proof. | On scan 82, (1) orders the alpha sequence and (3) compares the two function values. The reference is added above deleted text. Low confidence. |
| S11 · 85, below (10) | ρ_M⋯ρₙ≤σ_M⋯σₙ and σ₁⋯σ_{M−1}≤ρ₁⋯ρ_{M−1} | Reverse both comparisons if the prefix hypothesis (5) is used with this ordering. | The quotient above the first comparison and the equality of the full positive products determine the tail comparison. Low confidence about the manuscript reading or its intended revision. |
| S12 · 85, (10) | f(1/σ₁,…,1/σₙ)≤f(1/ρ₁,…,1/ρₙ) | Reverse the comparison under the displayed prefix and equal-total hypotheses. | With ρ=(2,2), σ=(4,1) and f the sum, the displayed claim would require 5/4≤1. The case reference was inserted in a rewritten heading. Low confidence about the intended revision. For the reciprocal-sum test use the refined comparison R05. |
| S13 · 85, same paragraph | « Il s’ensuit que que » | « Il s’ensuit que » | The same short connective occurs twice in succession. High confidence in the repetition. |
| S14 · 86, cancelled opening | Σφ(−α₁,…,−αₙ) and the corresponding Σφ on the right | φ on each side is a possible intended form. | The comparison on scan 82 evaluates one function of all the coordinates. No summation index is visible, and this line is struck. Low confidence. |
| S15 · 88, before (14) | « sous les conditions de b) », alternative a) | a) | The preceding truncation remark uses the monotonicity hypothesis. The case letter has an ambiguous loop. Low confidence. |
| S16 · 89, (19) | Left sum begins at i=1, right at i=0. | Matching lower limits, most naturally 1 in view of (18). | The preceding bound compares prefixes of equal length. The prose immediately before (19) also uses 0. Medium confidence. |
| S17 · 89, (20) | Lower limit j=1 or i=1 under the right sum | i=1 if the summand is ρᵢᵖ. | The summand has i. The lower stroke at the sum can resemble j and the box is reworked. Low confidence. |
| S18 · 89, first (21) | Σρᵢᵖ=‖u‖ₚ | Σρᵢᵖ=‖u‖ₚᵖ under the rooted convention of (22). | The square-root expression at p=2 gives the basis for this conditional comparison. A neighbouring norm equality has been struck. Low confidence about the manuscript reading or its intended revision. |
| S19 · 89, (21) after Corollaire 3 | Two separate displays numbered (21) | No unique replacement number. | The full p-power bound and its p=1 special case both carry the label. High confidence in the repetition. |
| S20 · 89, last lines | \|λ₁…λₙ\|≤ρ₁…ρₙ with « k≤n » | End the two prefixes at k if they precede the announced full-product equality. | The next line distinguishes the full product. The first terminal index is doubtful. Low confidence. |
| S21 · 91, lines 6–9 | The finite norm formula is called (25), its limit (26). | (27) and (28) in the current numbering. | On scan 90 the first pair numbers determinant identities and the second pair numbers the norm bounds. The second norm label is overwritten. Low confidence. |
| S22 · 91, below (29) | « de l’hyp. b, n° 2°) du th 1 » | The increasing-function case a) appears applicable here. | Case b) includes equality of full positive products. The theorem on this page does not impose that condition. The reference is inserted in a rewritten passage. Low confidence. |
| S23 · 92, top lines | 27, 28 with 30, 31 added above. « th. 2 » | (30) and (31) under Th 3 on scan 91. | The preceding sheet gives the two sum bounds for the composite. Both reference numbers on this sheet carry additions. Low confidence. |
| S24 · 92, turned addition before (32) | f(… )≡1 | f(s)=s would give the displayed sum of singular values directly. | Replacing the scalar function by a constant in the preceding sum comparison does not produce the displayed summands. The scalar argument remains doubtful. Low confidence. |
| S25 · 92, (34) | 1/p+1/q=1/s, followed by p,q,s≥0 | p,q,s>0 for ordinary reciprocals of finite real numbers. | The written comparison allows zero and no convention for its reciprocal is specified here. Medium confidence. |
| S26 · 92, (35) and the adjacent norm | r, 1/r, with s and 1/s possible | s and 1/s in the notation of (34). | The relation above names s as the third exponent. Several powers and the discarded norm are overwritten. Low confidence. |
| S27 · 92, below (36) | Reference to « l’inégalité (37) » | Possibly the adjacent norm form of (36). | The neighbouring displays and their numbers are reworked. A separate number for the norm form is possible. Low confidence. |
| S28 · 92, lower slip, proof of (40) | « les deux mb. de (35) » | « … de (40) » | The current line computes the two sides of the full-product equality, not the partial-sum inequality (35). Medium confidence. |
| S29 · 92, same sentence | « (formule (16)) » | (26) on scan 90 is the explicit determinant identity used here. | What appears to be a different reference can also belong to an older numbering. Low confidence. |

## work:K1-03#5 (same folder; 1: 79-92): Pointers

| ID and scan | Wording | Reference |
|---|---|---|
| P01 · 79–80 | “(formule (16))”, “(prop. 1 corollaire 4)”, “au N° suivant” | A preceding trace or coefficient formula, the coefficient comparison, and the deferred eigenvalue estimate. |
| P02 · 82 | “(H. Weyl).” | The name is inserted beside the theorem on convex functions of finite sequences. No publication details occur. |
| P03 · 83–85 | “le lemme”, “D'après un lemme connu”, “th. 1, 2°, b)” | The general convexity statement, a rearrangement lemma and the multiplicative equal-product case. |
| P04 · 86–87 | “normes de Schatten”, “avec les notations indiquées au N°” … “avant la prop 3”, “prop 3, corollaire 2” | The norm terminology and internal references used in the first Hilbert-space theorem. The two section-number readings are doubtful. |
| P05 · 89 | “N° 1, th. 2 et th. 3, formules (15) et (20)” | The author uses these references in singling out Fredholm and H.-S. operators. The names Fredholm and Hilbert also appear throughout the preceding statements. |
| P06 · 90–91 | “En comparant (25) et (26)”, “N°” … “prop.” … “corollaire 3.” | The determinant calculation on the turned margin, then the inequalities for a product in the second theorem. |
| P07 · 92 | “Nᵒ 1, th. 3”, “Inégalité de Hölder … opérationnelle”, “grâce à l'inégalité” | The first reference is in the turned addition. The two mentions of Hölder distinguish the operator result from the scalar inequality it uses. |

No other archive cote, dated letter or identifiable bibliographical title is cited on these sheets.

## work:K1-03#6 (same folder; 1: 79-92): Remarks of the model

**R01 · Scan 85, formula (9). Model, high confidence.** The two-term case shows what the differences of adjacent coefficients are doing. With $a=(5,2)$ and $\alpha=(3,1)$, the weighted sum and the prefix expression both equal 17. This is one direct computation on the displayed identity.

**R02 · Scans 90–92, full products and prefixes. Model, high confidence.** Let $u$ and $v$ be diagonal with entries $(3,2)$ and $(1,5)$. The composite has singular values $10,3$. Its first singular value is strictly below $3\cdot5=15$, while its full product $30$ equals $(3\cdot2)(5\cdot1)$. Thus the full-product equality used on the last slip can coexist with a strict prefix comparison. The example also distinguishes the two hypotheses cited around (29).

**R03 · Scan 92, lower slip, last proof. Reading question, low confidence.** The frozen transcription reads “(formule (16))”. “(formule (26))” is a possible reading of the first digit and points to the marginal determinant identity on scan 90. The internal reference alone cannot decide a faint figure.

**R04 · Scans 91–92, repeated operator letters. Reading question, low confidence.** The first argument in the frozen (29) reads $\rho_1(\mathrm{uv}|\mathrm{vu})$, with $uv$ first. The two letters are joined at that site. The order in words, an application from $E$ to $F$ followed by one from $F$ to $G$, clarifies the composite meant, while leaving the writer's choice of letter order open.

**R05 · Scan 85, (10). Model, low confidence about the intended revision.** Under the equal-product, prefix-product hypotheses, the reciprocal example in S12 gives a corrected numerical comparison $1\leq5/4$. The displayed order gives the reverse. Here both original lists are positive, decreasing and have product 4, and the test function is the sum of the coordinates. The numerical counterexample is exact. The interpretation of the revised case label is less secure.

**R06 · Scan 79, opening line of Corollaire 4. Reading question, low confidence.** The frozen text reads “d'un espace de Hilbert”. “dans l'espace de Hilbert” is another possible division of the strokes after “Fredholm”. The first downstroke is tall, but the following letters are compressed before “espace”. Either wording fits the sentence.

**R07 · Scan 86, first example below the crossed heading on convexity. Reading question, low confidence.** The frozen text has $\rho_i\geq0$. Another reading is $\rho_i>0$. A small stroke below the angle is hard to separate from the adjacent writing. The later discussion includes zero among the norm arguments, which favours the first reading without settling the shape here.

# H0CT: cote 1 documentary: section headings and archive sheet numbers (no title sheets or dates)

- its entries on these pages: codex:K1-01#2
- in the archive: 7 entries; 1: 51-64,65-78,82,93-107,108-121,122-136,137-150

## codex:K1-02#2 (same folder; 1: 65-78): Title sheets, dates and page counts

Scan 71 begins a section headed “Puissances extérieures d'op. de Fredholm, inégalités diverses.” The section number is damaged at the torn edge. The transcription favours “5.)” and gives alternatives. This is a heading on a sheet of formulas.

Separate title sheets, dates, authorial page numbers and statements of total page count — none. The lower-corner numbers run consecutively from 66 on scan 65 to 79 on scan 78. They are recorded as archive comments in the LaTeX files. The numbers beside the propositions, corollaries and formulas belong to the text.

## codex:K1-03#2 (same folder; 1: 79, 82, 87, 92): Title sheets, dates and page counts

No separate title sheet, date or statement of a page count appears. The section heading on scan 82 is “Inégalités de convexité et degrés remarquables d’opérateurs compacts”, with “remarquables” confirmed at the post-freeze comparison. Scans 87 and 91 carry the headings of the first and second convexity theorems for Hilbert spaces. The corner numbers are archive marks. They run from 80 on scan 79 through 93 on scan 92.

## codex:K1-04#2 (same folder; 1: 93-105, 107): Title sheets, dates and page counts

There is no separate title sheet, written date, authorial sheet number or explicit total page count among the 14 supplied scans.

| Scan | Heading or change of text |
|---|---|
| 93 | Underlined « Th. 4 » followed by « troisième th. de convexité dans les espaces de Hilbert ». |
| 94 | Circled 5 and the underlined section heading « Classes remarquables d'opérateurs dans l'espace de Hilbert ». |
| 102 | Boxed « Espaces de Schatten ». Circled subdivisions introduce « Normes de Schatten » and « Espaces de Schatten ». |
| 104–105 | Underlined « Théorème » on scan 104. Its numbered parts continue with 4 and 5 on scan 105. |
| 107 | « Décomposition en facteurs des fonctions entières. » followed by underlined « Théorème 1 » and « (Weierstrass) ». The equation numbers start again at (1). |

The archive pencil numbers are 94–106 on scans 93–105 and 108 on scan 107. They are entered as comments in the transcription. Scan 106 is outside the supplied selection.

## codex:K1-05#2 (same folder; 1: 108-121): Title sheets, dates and page counts

There is no separate title sheet, written date, manuscript page count or authorial page number in these fourteen images. Scan 108 contains the underlined headings « Genre d’une fonction entière » and « Ordre d’une fonction entière ». Scan 120 begins with an underlined, corrected heading whose live wording is « Sur une certaine fonction holomorphe sur l’espace de Banach \(l^1\). »

The pencilled lower-corner numerals are archive sheet numbers. They are recorded as comments in the LaTeX.

| PDF scan | 108 | 109 | 110 | 111 | 112 | 113 | 114 |
|---|---:|---:|---:|---:|---:|---:|---:|
| Archive sheet | 107 | 110 | 111 | 112 | 113 | 114 | 115 |

| PDF scan | 115 | 116 | 117 | 118 | 119 | 120 | 121 |
|---|---:|---:|---:|---:|---:|---:|---:|
| Archive sheet | 116 | 117 | 118 | 119 | 120 | 121 | 122 |

## codex:K1-06#2 (same folder; 1: 122, 124-136): Title sheets, dates and page counts

None. These handwritten mathematical notes have local headings such as « Théorème », « Démonstration », « Corollaire », « Lemme » and « Preuve ». No title sheet, manuscript date, authorial pagination or statement of total page count is visible. The lower-corner numbers 123 and 125–137 are the archive’s pencil numbers.

## codex:K1-07#2 (same folder; 1: 137-140, 142-150): Title sheets, dates and page counts

None. No dated letter, title sheet, stated page total or authorial page number appears in the selection. « Proposition », « Corollaire », « Remarque », « Lemme », « Théorème », « Question » and « Démonstration » head local parts of the mathematics. The small lower-corner pencil numbers are 138–141 and 143–151, respectively, for scans 137–140 and 142–150.
