# The nodes of WT_1_051-064

- `NOTES_ON_THESE_PAGES.md`, `NOTES_INDEX.tsv`: the 8 entries that cite these pages (0 from Pro's notes, 6 from Work's math notes, 2 from Codex's notes); `files/`: the whole files they come from.
- `CONCORDANCE.tsv`, `CONCORDANCE.md`: 20 entries on the same objects elsewhere.
- `OBJECTS.tsv`: the sweep's global rows of these 3 objects (their tags are the handbook's draft tags).
- `CHECKS.tsv`: 0 rows of the check register (results_register/CHECK_REGISTER.tsv) about these entries, items and objects: who checked what, how, with what result.
- `DRAFT_UNITS.tsv`: the 11 draft units of Work's math notes for these pages.
