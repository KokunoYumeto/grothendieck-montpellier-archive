# Our results that cite WT_22_020-030

The statements of our research runs (results_register/REGISTER.tsv, 18 Nov 2026) whose `his_places` cite cote 22 at these scans or without a scan: 0 rows. A status is the run's own claim unless `check_events` records a check. Open this only when the work on the pages is done.
