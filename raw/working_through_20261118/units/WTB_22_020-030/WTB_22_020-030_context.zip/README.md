# The context of WT_22_020-030

- `this_folder/cote_22.tex`: the whole folder as transcribed so far, each page in the reading a pass starts from, for the argument before and after this range
- `ega_fr/ega0-19-fr.tex`: EGA 0_IV §19, formally smooth algebras and Cohen rings (French, our edition)
- `ega_fr/ega0-19b-fr.tex`: EGA 0_IV §19, continued (French, our edition)
- `ega_fr/ega0-20-fr.tex`: EGA 0_IV §20, derivations and differentials (French, our edition)
- `ega_fr/ega0-21-fr.tex`: EGA 0_IV §21, differentials in rings of characteristic p (French, our edition)
- `ega_fr/ega0-22-fr.tex`: EGA 0_IV §22, differential criteria of smoothness and regularity (French, our edition)
- `ega_fr/ega0-23-fr.tex`: EGA 0_IV §23, Japanese rings (French, our edition)
- `ega_fr/ega4-16-fr.tex`: EGA IV §16, differential invariants; differentially smooth morphisms (French, our edition)
- `ega_fr/ega4-17-fr.tex`: EGA IV §17, smooth, unramified and étale morphisms (French, our edition)
- `ega_v/cote24_ega_v_english_typescript.tex`: EGA V, the English typescript in the archive (cote 24), transcribed by Claude Opus 5.5 over the API (not yet checked by eye)
- `ega_v/cote25_nouveau_ega_v_typescript.tex`: EGA V, the French typescript in the archive (cote 25), transcribed by Claude Opus 5.5 over the API (not yet checked by eye)
- `neighbours/cote_23.tex`: cote 23, EGA IV Compléments (his notes, letters of 1966 and 1968, a typescript), as transcribed so far
- `neighbours/cote_26.tex`: cote 26, EGA VI: plans, notations, open problems
- `neighbours/cote_21.tex`: cote 21, chapter 0_III, as transcribed so far
- `topics/SA23_TOPIC.md`: the catalogue of the topic (its folders, what is transcribed and how)

No earlier range of this topic has been worked through yet; when one has, its tables join this context as `earlier_ranges/`.
