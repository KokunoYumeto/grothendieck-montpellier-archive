# SA23: Éléments de Géométrie Algébrique (EGA); MATHÉMATIQUES / RECHERCHE / Travaux; Dossiers rassemblés par Grothendieck sur différentes thématiques

| cote | catalogue title | pages | Pro | Codex | API | in this run |
|---|---|---:|---:|---:|---:|---|
| 1 | Analyse fonctionnelle : notes manuscrites (s.d.), lettre (1953). | 149 | 45 | 8 | 0 | HC1-01, K1-01, K1-02, K1-03, K1-04, K1-05, K1-06, K1-07 |
| 2 | Théorème de Riemann-Roch[2] / RR [Riemann-Roch] Notes Antiques (antérieur[es à] 1958)[3] : notes manuscrites (s.d.). | 44 | 41 | 0 | 0 | MPL_2 |
| 21 | [Chapitre] 0 III[19] : tapuscrit et copies de tapuscrit annotés (s.d.), notes manuscrites (s.d.). | 28 | 0 | 0 | 0 | K21-01, K21-02 |
| 22 | [EGA IV]. [Chapitre] 0 IV. Cohen, différentielles, algèbres formellement simples (Compléments) : tirés à part (1963), tapuscrit annoté (s.d.), notes manuscrites (s.d.). | 29 | 29 | 0 | 0 | MPL_22+23_002-016, K22-01, K22-02 |
| 23 | EGA IV. Compléments : notes manuscrites (s.d.), lettres (1966, 1968), tapuscrit (s.d.). | 98 | 15 | 0 | 0 | MPL_22+23_002-016, K23-01, K23-02, K23-03, K23-04, K23-05, K23-06 |
| 24 | [EGA V, traduction en anglais][22] : copies de tapuscrit annoté (s.d.), notes manuscrites (s.d.). | 76 | 0 | 0 | 76 | other part |
| 25 | Nouveau EGA V[24] : copies de tapuscrits annotés (s.d.). | 184 | 0 | 0 | 184 | other part |
| 26 | EGA VI. Plans, notations, problèmes ouverts[25] : notes manuscrites (s.d.). | 10 | 0 | 10 | 0 | H26-01 |
| 161-1 | Catégories[173] : notes manuscrites (s.d.). | 19 | 0 | 0 | 0 | K161-1-01 |
| 161-2 | Algèbre universelle [ou catégories] : notes manuscrites (s.d.). | 111 | 0 | 0 | 0 | K161-2-01, K161-2-02, K161-2-03, K161-2-04, K161-2-05, K161-2-06, K161-2-07 |
| 161-3 | Topos[176] : notes manuscrites (s.d.). | 54 | 0 | 0 | 0 | K161-3-01, K161-3-02, K161-3-03 |
| 161-4 | Introduction à géométrie algébrique[178] : notes manuscrites (s.d.). | 31 | 0 | 0 | 0 | K161-4-01, K161-4-02 |
| 161-5 | Barsotti-Tate[179] : tirés à part annotés (1967-1969), notes manuscrites (s.d.). | 28 | 27 | 0 | 0 | MPL_93_221-236+161-5, K161-5-01, K161-5-02 |
| 161-6 | Graphes, icosaèdre [etc.][181] : notes manuscrites (s.d.). | 33 | 0 | 0 | 0 | K161-6-01, K161-6-02 |
| 162-1 | Papiers prêtés [liste de noms et de références documentaires] : notes manuscrites (s.d.). | 9 | 0 | 9 | 0 | MPL_68_033-056+162-1+162-6 |
| 162-5 | Tapis de Quillen : tapuscrit et copies de tapuscrits (1968, s.d.), notes manuscrites (1968), tiré à part (1968). | 68 | 0 | 0 | 51 | K162-5-01, K162-5-02 |
| 162-6 | [Documents isolés][185] : notes manuscrites (s.d.). | 5 | 0 | 5 | 0 | MPL_68_033-056+162-1+162-6 |
