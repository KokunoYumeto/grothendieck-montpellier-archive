# The nodes of WT_22_020-030

- `NOTES_ON_THESE_PAGES.md`, `NOTES_INDEX.tsv`: the 36 entries that cite these pages (28 from Pro's notes, 6 from Work's math notes, 2 from Codex's notes); `files/`: the whole files they come from.
- `CONCORDANCE.tsv`, `CONCORDANCE.md`: 36 entries on the same objects elsewhere.
- `OBJECTS.tsv`: the sweep's global rows of these 7 objects (their tags are the handbook's draft tags); `LINKS.tsv`, the sweep's links among them.
- `CHECKS.tsv`: 2 rows of the check register (results_register/CHECK_REGISTER.tsv) about these entries, items and objects: who checked what, how, with what result.
