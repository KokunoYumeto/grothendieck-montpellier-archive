# The notes on WT_22_020-030

Every note entry that cites a page of this range, in page order, in full as it stands in its file, with the placement of horizontal sweep 1 (Claude Opus 5.5 at effort max, 18 Nov 2026): the object, its item and the object's tag.

## MPL_22+23_002-016#77: P06. Title sheets, source headings and stated lengths

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 399
- pages: 22: 2-16, 18-20, 26; 23: 2-16
- kind: research note
- the sweep's object: cotes 22-23 documentary -- Title sheets, source headings and stated lengths (item SA23-47, tag H0DY; basis index-row; fidelity not checked)

**Kind: reading question — title and extent inventory.** Every title below is quoted from the frozen source; dates in the date column come from the identified inscriptions, while “undated” reports the absence of a date on that title sheet. The observed scan runs are counts of the retained material, and the page labels are reported in P07. **Context / state:** compare `README.md`, “This package in our plan”; **MPL_33_147-181+34_002-017 8.3** [first-pass lead] likewise distinguishes manuscript numerals from a total count, but the underlying source and full note are not included here.

| Cote / scan and approximate position | Exact title or heading | Date written with the text | Extent evidence |
|---|---|---|---|
| 22/002, printed header/title | “Étude différentielle des anneaux locaux réguliers : applications.” | Header: “13 novembre 1963”; note on 22/004: “Séance du 4 novembre 1963.” | Printed journal range “p. 2948–2950”; offprint text occupies scans 002–004, followed by printer page 005. |
| 22/006, printed header/title | “Sur les modules de différentielles.” | Header: “Séance du 21 janvier 1963”; note on 22/008: “Séance du 14 janvier 1963.” | Printed journal range “p. 842-844”; offprint text occupies scans 006–008, followed by printer page 009. |
| 22/019, title sheet | “Questions” | Undated | Sheet label 18; the following heading and four numbered questions occupy 020–021, with developments on 022–025. |
| 22/020, top heading | “Questions ouvertes” | Undated | Four explicit items, continued on 021; no total-page declaration. |
| 22/026, title sheet | Deleted “Différentielles” | Undated | Sheet label 25; handwritten calculation on 027 and 029, with reused typed pages 028 and 030. |
| 23/002, title sheet | “EGA IV, Calcul diff.” / “(Compléments)” | Undated | Sheet label 1; 15 retained pages in this cote segment, scans 002–016. |
| 23/003, title sheet | “Discriminant etc” | Undated | Sheet label 2; handwritten calculations on scans 004–006. |
| 23/008, title sheet | “Exponentielle” | Undated | Sheet label 7; exponential notes continue through scans 009–016. |
| 23/009, top heading | Underlined “Suite\|Suites sur l'exponentielle” | Undated | The singular/plural reading remains doubtful; sheet label 8 and a circled 1 begin the numbered discussion. |
| 22/018, lower paragraph | Proposed redaction “en deux pages ou trois” | Undated | This is the author's desired length for a rewrite of the results around 4.13, rather than an inscribed count of the surviving unit. |

There is no title-sheet declaration of the form “19 pages” or “Pages 1–67” in the frozen 44-page text. The numbers 29 and 15 are the retained scan counts supplied by the task, and the sequential labels below are the page evidence within the images.

## MPL_22+23_002-016#78: P07. All page-number sequences in this package

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 418
- pages: 22: 2-30; 23: 2-16
- kind: research note
- the sweep's object: cotes 22-23 documentary -- All page-number sequences in this package (item SA23-47, tag H0DY; basis index-row; fidelity not checked)

**Kind: reading question — competing pagination. Location: every retained sheet, visible numerals.** The lower-label run in cote 22 is 1–29 across scans 002–030, with the label 4 on 005 still doubtful, and the cote 23 run is 1–15 across scans 002–016. Several sheets also carry a second number belonging to an internal typed or printed sequence, which is preserved below; the repeated 27 on 22/028 and the 29/26 pair on 22/030 remain separate source observations. **Context / state:** `README.md`, supplied scan ranges; **MPL_33_147-181+34_002-017 8.3** [first-pass pagination lead], used only as a comparison question, with no inherited numbering supplied for these cotes.

| Cote and scan(s) | Visible labels preserved in transcription | Source position / qualification |
|---|---|---|
| 22/002–004 | 1, 2, 3 | Offprint unit; printed centred (2), (3) also appear on 003–004. |
| 22/005 | `4` doubtful | Printer sheet. |
| 22/006–009 | 5, 6, 7, 8 | Second offprint unit; printed centred (2), (3) on 007–008. |
| 22/010–018 | Upper/internal 24–32; lower 9–17 | Nine annotated typed sheets; both number series preserved. |
| 22/019–027 | 18–26 | Includes the two title sheets and mathematical/reused sheets. |
| 22/028 | 27, 27 | Two locations, one adjacent to the typed text and one at the foot. |
| 22/029 | 28 | Handwritten continuation. |
| 22/030 | 29, 26 | Two source labels; do not sort the archive sequence by the second one. |
| 23/002–006 | 1–5 | Covers and discriminant calculations. |
| 23/007 | 3, 6 | Reused English typescript's internal page 3 and separate sheet label 6. |
| 23/008–016 | 7–15 | Exponential cover and eight continuation sheets. |

## MPL_22+23_002-016#2: P02. The thirteen chapters announced in EGA I

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 30
- pages: 22: 10, 21; 23: 2
- kind: research note
- the sweep's object: the EGA plan -- The thirteen chapters announced in EGA I (item SA23-28, tag H0DH; basis index-row; fidelity not checked; flag: F10)

**Kind: reading question — exact chapter numbering. Location: current package 23/002, title “EGA IV”; comparison witness: EGA I introduction, printed p. 6.** The following is the complete list in the supplied EGA I witness; **1960** is the shared date given for that plan in the prompt and README, rather than thirteen separately dated inscriptions. The source explicitly calls the plan “sujet à modifications ultérieures” and treats chapters as open to later additions, so the list supplies a dated comparison witness for subsequent archive plans. **Context / state:** `context/ega_fr/EGA_I_introduction_plan_of_the_treatise.tex`, printed p. 6, paragraph “A titre informatif” and following table; **WG2 §2.1 #2** [unchecked plan], with no settled numbering concordance in the supplied state register.

| Chapter number in the 1960 witness | Exact title in the supplied French text | Plan date | Number/title in the 44 current pages |
|---|---|---:|---|
| Premier / I | Le langage des schémas. | 1960 | No corresponding chapter-list entry on these sheets |
| II | Étude globale élémentaire de quelques classes de morphismes. | 1960 | No corresponding chapter-list entry on these sheets |
| III | Cohomologie des faisceaux algébriques cohérents. Applications. | 1960 | Internal “Chap III” reference on 22/010 |
| IV | Étude locale des morphismes. | 1960 | Cover: “EGA IV, Calcul diff. (Compléments)” on 23/002; “Cf IV” reference on 22/021 |
| V | Procédés élémentaires de construction de schémas. | 1960 | No chapter-list entry on these sheets |
| VI | Technique de descente. Méthode générale de construction des schémas. | 1960 | No chapter-list entry on these sheets |
| VII | Schémas de groupes, espaces fibrés principaux. | 1960 | No chapter-list entry on these sheets |
| VIII | Étude différentielle des espaces fibrés. | 1960 | No chapter-list entry on these sheets |
| IX | Le groupe fondamental. | 1960 | No chapter-list entry on these sheets |
| X | Résidus et dualité. | 1960 | No chapter-list entry on these sheets |
| XI | Théories d'intersection, classes de Chern, théorème de Riemann-Roch. | 1960 | No chapter-list entry on these sheets |
| XII | Schémas abéliens et schémas de Picard. | 1960 | No chapter-list entry on these sheets |
| XIII | Cohomologie de Weil. | 1960 | No chapter-list entry on these sheets |

The twelve-chapter **CSG U90d** list, the chapter lists in **cotes 26 and 48**, and their dates remain untranscribed comparison columns because those witnesses are absent from both supplied archives; the README's reported cardinalities alone cannot specify a permutation or a merger of named chapters.

## MPL_22+23_002-016#3: P03. Subjects after IV: what this package actually contributes

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 52
- pages: 22: 10, 18, 28; 23: 4-6, 13, 16
- kind: research note
- the sweep's object: the EGA plan -- Subjects after IV: what this package actually contributes (item SA23-28, tag H0DH; basis index-row; fidelity not checked; flag: F10)

These are chapter-assignment reading notes, each tied to a visible formula or stated question. The chapter titles are the 1960 titles above. The local question list appears separately in P04, because its author does not assign those four questions to numbered Chapters V–XIII.

| Note / kind | Chapter and planned subject from the 1960 witness | Current page evidence and explicit connection | Context locator; state linkage |
|---|---|---|---|
| P03-V — reading question | V: elementary construction of schemes | 23/004 begins “\(P=P(E)\) fibré projectif associé” and constructs \(J\) from maps \(g^*(M_d)(-d)\to J\), followed by \(\coprod f^*(M_d)(-d)\xrightarrow{\sim}J/J^2\); 23/006 uses the section \(\varphi:S\to\Phi^k(P^r)\) and its hypersurface. These are concrete projective construction data for comparison, while the cover places this material under “EGA IV.” | EGA I introduction p. 6, V; `ega2-indexes-and-contents-fr.tex`, II §§2–4, especially 3.6 and 4.1–4.4, printed pp. 213–214. `RESULTS_STATE`: **WG2 §2.1 #2**, unchecked planning status. |
| P03-VI — reading question | VI: descent and general construction methods | 22/018, lower paragraph, asks to “se ramener à ce cas … par descente comme dans 4.11,” after constructing a complete \(B\) with a prescribed special fibre \(B_0\); the comparison object is the local map \(A\to B\) and the isomorphism of its reduction with \(B_0\). This supplies a specific descent passage to collate with the planned construction chapter. | EGA I introduction pp. 6, 8–9; `EGA_chap0_ega0-19.tex`, 19.0.2 III and 19.7.2. **MPL_131 10** [first-pass lead] reports descent/representable functors in a separate package, whose full note and scans are not included; **WG2 §2.1 #2** remains an unchecked plan. |
| P03-VII — reading question | VII: group schemes and principal bundles | 23/013 writes \(\pi_0(U\otimes\Lambda)\underset{\log}{\stackrel{\exp}{\rightleftarrows}}\gamma_0(U\otimes_k\Lambda)\), and 23/016 states the infinitesimal automorphism/derivation correspondence for \(A\otimes_k\Lambda\), with the group law given by “Hausdorff-Campbell.” These explicit maps provide the package's group-theoretic link; 23/013 also writes the marginal “Cor Un groupe alg. en car 0 … toujours lisse,” with its reading doubts preserved. | EGA I introduction p. 6, VII; `EGA_chap0_ega0-20.tex`, 20.1–20.3 on derivations and their functorial/topological properties. State register has no settled item about this exponential construction. |
| P03-VIII — reading question | VIII: differential study of fibre spaces | 23/004 gives the Euler sequence \(0\to\Omega^1_{P/S}\to g^*E(-1)\to O_P\to0\), then the conormal map \(J/J^2\to\Omega^1_{P/S}\otimes O_X\) and its determinant isomorphism; 23/005 carries the calculation to an elliptic cubic. This is direct differential material on the displayed projective bundle \(P(E)\to S\). | EGA I introduction p. 6, VIII; `ega4-backmatter-contents-fr.tex`, IV 16.1–16.6 and 17.12, printed pp. 341–342; `EGA_chap0_ega0-20.tex`, 20.5. No matching settled register item. |
| P03-IX — reading question | IX: fundamental group | The current titles and numbered questions provide no chapter-IX programme, covering-space construction, or fundamental-group calculation; the nearest supplied context is the introduction's explicit use of Chapter IX as an example of formal-to-algebraic methods. The retained evidence is thus the local-ring/formal-method discussion on 22/010–018, without assigning it an unwritten Chapter IX heading. | EGA I introduction pp. 6, 8–9; `ega4-backmatter-contents-fr.tex`, IV 18.1–18.3 “Revêtements étales” and “Algèbres finies et étales,” printed p. 342. **MPL_142_001-093 §316** is only a first-pass bibliography lead in the supplied state register. |
| P03-X — reading question | X: residues and duality | 23/004–005 records the determinant isomorphism relating \(\Omega^n_{X/S}\), \(\bigwedge^p(J/J^2)\), and \(f^*(\bigwedge^{r+1}E)(-r-1)\); 22/028 and 030 provide trace/norm maps on répartitions, idèles and divisors, including \(D'(N(I))=N(D(I))\). Those displayed morphisms and identities give precise comparison points for the planned “Résidus et dualité,” while these sheets do not label them as a Chapter X plan. | EGA I introduction p. 6, X; `ega2-indexes-and-contents-fr.tex`, II 6.4–6.5; `ega4-backmatter-contents-fr.tex`, IV 21.4–21.5 and 21.9–21.10, printed p. 343. No matching settled register item. |
| P03-XI — reading question | XI: intersections, Chern classes and Riemann–Roch | The words “intersection complète” on 23/004 are accompanied by the map from the graded generators to \(J/J^2\), and 23/005 computes its top exterior power with twist \(-\sum\alpha_i d_i\). This supplies an explicit conormal/determinant calculation for comparison with the planned intersection subject; the current pages supply no Chern-class or Riemann–Roch statement. | EGA I introduction p. 6, XI; `ega4-backmatter-contents-fr.tex`, IV 19.1–19.3, printed p. 342; `EGA_chap0_ega0-16.tex`, regular sequences, and `EGA_chap0_ega0-20.tex`, 20.5. No matching settled register item. |
| P03-XII — reading question | XII: abelian schemes and Picard schemes | 23/005, lower half, names a “courbe elliptique lisse sur S” and ends with \(M\xrightarrow{\sim}\mathcal L^{\otimes6}\); the preceding displayed isomorphism \(\check{\mathcal L}\xrightarrow{\sim}\mathcal L^{\otimes5}\otimes\check M\) is the concrete link to its line-bundle calculation. The supplied material reaches this elliptic example and does not provide a representability statement for a Picard functor. | EGA I introduction p. 6, XII; `ega2-indexes-and-contents-fr.tex`, II 4.1–4.4, projective bundles; IV contents 21.2–21.3, invertible fractional ideals and linear equivalence. No matching settled register item. |
| P03-XIII — reading question | XIII: Weil cohomology; the request also asks about étale cohomology | The exact announced title is “Cohomologie de Weil,” and the introduction p. 9 describes its motivation through Weil's conjectures; the 44 current sheets supply no chapter-XIII outline or étale-cohomology construction. The supplied IV contents list étale morphisms and étale coverings (17.1–18.3), which provides a documented adjacent heading without changing the 1960 chapter title. | EGA I introduction pp. 6, 9; `ega4-backmatter-contents-fr.tex`, IV 17–18, printed pp. 341–342. **MPL_147_138-190 §143** [first-pass bibliography lead] names SGA 4, but its full research note is absent here. |

## codex:K22-02#1: 

- written by: GPT-6 Astra at reasoning effort max (Codex web), notes of the folder K22-02
- file: `files/K22-02_notes.md`, line 0
- pages: 22: 17-30
- kind: his marks of doubt and unfinished steps
- the sweep's object: Cohen algebras, his questions, derivations and the counterexample (cote 22, scans 17-30) -- his marks of doubt and unfinished steps (item SA23-17,SA23-18,SA23-19,SA23-20, tag H0D5, H0D6, H0D7, H0D9; basis index-row; fidelity not checked)

(text not found)

## codex:K22-02#2: 

- written by: GPT-6 Astra at reasoning effort max (Codex web), notes of the folder K22-02
- file: `files/K22-02_notes.md`, line 0
- pages: 22: 17-30
- kind: titles, dates and page counts
- the sweep's object: Cohen algebras, his questions, derivations and the counterexample (cote 22, scans 17-30) -- titles, dates and page counts (item SA23-47, tag H0DY; basis index-row; fidelity not checked)

(text not found)

## work:K22-02#1: What the pages do

- written by: GPT-6.2 Astra at reasoning effort max (ChatGPT Work), math notes of the folder K22-02
- file: `files/K22-02_mathnotes.md`, line 3
- pages: 22: 17-30
- kind: summary of the pages
- the sweep's object: Cohen algebras, his questions, derivations and the counterexample (cote 22, scans 17-30) -- summary of the pages (item SA23-17,SA23-18,SA23-19,SA23-20, tag H0D5, H0D6, H0D7, H0D9; basis index-row; fidelity not checked)

**Cohen algebras, scan 17.** Corollary 4.12 concerns a local homomorphism of noetherian local rings with r(B)=r(A)B and residue extension K/k. It puts three descriptions of B side by side: complete and formally simple over A, complete and flat with separable K/k, and a Cohen algebra over A. It adds existence over a prescribed separable residue extension and uniqueness up to A-algebra isomorphism.

**Completeness and editorial choices, scans 17–18.** The author considers replacing completeness for B’s own topology by completeness for the IB-adic topology. He identifies earlier numbers requiring changes and leaves the decision to the addressee. The next sheet proposes reordering existence, descent and uniqueness.

**A fibre criterion, scan 18.** Corollary 4.13 compares formal simplicity with flatness and universal regularity of the fibre B⊗ₐk. The hypothesis on the residue extension is finite “multiplicité radicielle”; a handwritten “ou” introduces the radical condition. The argument passes to the completion and appeals to earlier numbered results.

**Open questions about topology, scans 20 and 22–23.** The first question asks whether universal regularity implies formal simplicity. The second asks whether the topology can be changed from the usual one to the discrete one. A later sheet treats a presentation by formal power series in positive characteristic using a finite p-basis. The characteristic-zero discussion tests k[[t]] and turns to differentials.

**Open loci, scans 20–21.** Question 3 concerns the points of Spec B whose fibre local ring is formally simple over the residue field. There is a separate question about localization, an appeal to Nagata and a discussion of resolution of singularities. Question 4 asks for openness of the flat locus. Its reduction singles out a pair of primes and an open subset after forming the primed rings. Some of the qualifications are in rapidly written diagonal notes.

**A proposed obstruction, scans 23–25.** The map from differentials of the coefficient field, tensored up to the power-series ring, is tested for a left inverse. Scan 24 states a proposition for K/k with an infinite-dimensional differential module and a positive number of variables. The proposed derivation is reduced to the case Dtᵢ=0. Scan 25 expands into components indexed by a basis and proposes a series whose components would not have finite support.

**A field example, scans 27 and 29.** The square starts with k′=k∩Kᵖ. The writer compares p-independence over that intersection with p-independence after passage to K, and records a possible failure of injectivity for a map of differentials. Below the square he builds fields from x, y and coefficients aᵢ. The two defining lines give a=xᵖ and express a₀ using y and the terms with positive index. Scan 29 compares two coefficient expansions, then revises the conditions on the generators.

**Extension and norm of divisors, scan 30.** Formula (31) extends a place with its ramification multiplicities. Formula (34) uses the residue-degree factors for the norm. The typescript relates both operations to principal divisors and towers, then records the two degree identities (38) under its product-formula assumptions.

**Extension, trace and norm of repartitions, scans 30 and 28.** The last paragraph of typescript page 26 (scan 30) continues on typescript page 27 (scan 28). The local entries of an extension are specified first. Formula (40) defines trace by a sum of local traces and norm by a product of local norms. The text then identifies their restrictions to principal repartitions and the effect on idèles.

**Product topology, scan 28.** Section 6 introduces a family of topological groups and open distinguished subgroups. The last sentence starts to describe a fundamental system of neighbourhoods of the identity and breaks off at “for-”.

## work:K22-02#2: Statements left without proof

- written by: GPT-6.2 Astra at reasoning effort max (ChatGPT Work), math notes of the folder K22-02
- file: `files/K22-02_mathnotes.md`, line 25
- pages: 22: 17-30
- kind: unproved claims
- the sweep's object: Cohen algebras, his questions, derivations and the counterexample (cote 22, scans 17-30) -- unproved claims (item SA23-17,SA23-18,SA23-19,SA23-20, tag H0D5, H0D6, H0D7, H0D9; basis index-row; fidelity not checked)

| Scan | Statement and the writer’s words | Extent of the argument on these sheets |
| --- | --- | --- |
| 17 | “Conditions équivalentes”; “il existe une algèbre de Cohen B sur A … et B est unique à isomorphisme de A-algèbres près.” | The introductory “En particulier” presents this as a consequence of earlier material. |
| 18 | “les conditions (i) et (ii) étant invariantes par changement de B en [B avec chapeau]”; “formellement simple = … régulier en vertu de …” | Completion and an earlier result are invoked. The writer also proposes proving existence by descent and comparing with a B-type. |
| 21 | “OK. en caractéristique 0 pour les bons anneaux, grâce à la résolution des singularités.” | A justification is named. The long margin also introduces a further condition on openness or constructibility. |
| 22 | “En la complétant par les tᵢ, on trouve une p-base de A sur k”; “Donc dans ce cas on gagne.” | The construction and a tensor expression are written down. The reference “Diff.” follows. |
| 24–25 | “Il faut prouver que l’hom … n’a pas d’inverse à gauche”; “Il reste à prouver …”; “il suffit alors de prendre f=∑aₙtⁿ.” | A reduction and proposed construction are present. The final series is followed by dots; no concluding verification appears. See R25 below. |
| 27 | “il peut arriver que le noyau … ne soit pas engendré sur K par les dx⊗1 …”; “On peut prendre un exemple où il est de dim 1”. | The kernel statement introduces an example. Its dimension assertion appears in the slanted note; a dimension computation is not written there. |
| 29 | “a′ᵢ=aᵢ, donc aᵢ∈k=F(x,y), absurde”; “Conditions essentielles”. | The author uses the uniqueness of the coefficients in the stipulated presentation and lists variants of the data. |
| 30 | “Il est clair que … est un isomorphisme croissant”; “En vertu de (29)”; “D’autre part (30) montre que l’on a”; “on voit que” before (35). | Formulas (32) and (36) concern principal divisors, (33) and (37) towers, and (38) the two degree identities. Formulas (29) and (30) themselves are outside these fourteen scans. C30.35 below concerns (35) only. |
| 28 | “Enfin une formule évidente de transitivité”; “On a enfin les formules suivantes (que l’on vérifie comme l’âne qui trotte)”; “formules de transitivité”. | In (39) the divisor operation commutes with extension. The typescript states linearity of trace, multiplicativity of norm on idèles, and the identities (41)–(44) for scalars, extended elements and the divisor of a norm. The final transitivity item is verbal. |

## work:K22-02#3: Questions and conjectures

- written by: GPT-6.2 Astra at reasoning effort max (ChatGPT Work), math notes of the folder K22-02
- file: `files/K22-02_mathnotes.md`, line 39
- pages: 22: 17-30
- kind: questions and conjectures
- the sweep's object: Cohen algebras, his questions, derivations and the counterexample (cote 22, scans 17-30) -- questions and conjectures (item SA23-17,SA23-18,SA23-19,SA23-20, tag H0D5, H0D6, H0D7, H0D9; basis index-row; fidelity not checked)

- **Scan 17.** “Je t’en laisse donc le choix” applies to the change of completeness hypothesis. On scan 18, “peut-être plus service” introduces the proposed alternative exposition.
- **Scan 20, point 1.** “Est-il vrai que A … simple sur k si A est … régulier sur k” is followed by its proposed consequence for a local homomorphism. The short marginal answer is “OK”.
- **Scans 20 and 22, point 2.** “Est-il vrai … pour sa topologie discrète? Cas où A est complète?” On 22 the question returns with “???”. Scan 20 suggests that “la réponse soit affirmative en car p>0, négative en car 0”, then considers the relative case over Λ. The margin has “Faux, cf …”, “Je suis pessimiste”, and a qualified “Peut-être y-a-t-il de l’espoir …”.
- **Scans 20–21, point 3.** “est-il ouvert?” concerns the locus in the fibres. The next page asks whether the relevant set is “stable par localisation?” and mentions residual extensions of finite degree. A slanted passage asks for a locus to be “ouvert (ou au moins constructible)”.
- **Scan 21, point 4.** “Lieu des pts de Spec B en lesquels B est plat sur A est-il ouvert?” The writer follows with “vérifier que … ∃ un ouvert non vide de Spec B′”.
- **Scan 23.** “Je présume que si dim A>0, A n’est jamais … simple sur k pour sa topologie discrète.” The text also says “je doute qu’il y ait …” relative to the prime field and asks whether the differential map “admet un inverse à gauche?”. The abbreviation in the conjecture is uncertain.
- **Scans 27 and 29.** “peut ne être pas injectif” and “il peut arriver” introduce a proposed counterexample. The second sheet compares presentations and gives “Conditions essentielles”.

## work:K22-02#4: Slips

- written by: GPT-6.2 Astra at reasoning effort max (ChatGPT Work), math notes of the folder K22-02
- file: `files/K22-02_mathnotes.md`, line 49
- pages: 22: 17-30
- kind: slips
- the sweep's object: Cohen algebras, his questions, derivations and the counterexample (cote 22, scans 17-30) -- slips (item SA23-17,SA23-18,SA23-19,SA23-20, tag H0D5, H0D6, H0D7, H0D9; basis index-row; fidelity not checked)

| ID | Scan | Written → apparently intended | Confidence and reason |
| --- | --- | --- | --- |
| S17a | 17, line 3 | tel with s struck → tels | Low. The surviving word is followed by que and the preceding nouns are plural. The deleted s could be part of a change the author did not finish. |
| S17b | 17, line 10 | je me répens → je me repens | High. The verb has a clearly typed acute accent on the first e. |
| S17c | 17, line 14 | des réajustement analogues → des réajustements analogues | High. The last typed t is followed by a space before analogues. No s is visible. |
| S18 | 18, near the foot | lesdémontre → les démontre | High. The d and the preceding s are one normal typewriter pitch apart. |
| S28 | 28, paragraph below heading 6 | une famille se sous-groupes → une famille de sous-groupes | High for the separately typed word se. Its two letters are clear; the overprint is on the following word. The parallel preceding phrase has de. |
| S30 | 30, product-formula paragraph | P∣P → P∣P′ under the second displayed-in-prose sum of e(P)f(P) | High. The earlier version following (34) has a prime on the second P; the later line has two unprimed P’s and no covered or struck mark at that spot. |

## work:K22-02#5: Pointers

- written by: GPT-6.2 Astra at reasoning effort max (ChatGPT Work), math notes of the folder K22-02
- file: `files/K22-02_mathnotes.md`, line 60
- pages: 22: 17-30
- kind: pointers
- the sweep's object: Cohen algebras, his questions, derivations and the counterexample (cote 22, scans 17-30) -- pointers (item SA23-17,SA23-18,SA23-19,SA23-20, tag H0D5, H0D6, H0D7, H0D9; basis index-row; fidelity not checked)

| Scan | Words or reference | Referent on these pages |
| --- | --- | --- |
| 17 | “définition … .7”, “.2., … .6. et la suite”, “dans … .9. à … .12.” | Proposed alterations to an earlier treatment. The initial section numeral is corrected in pen. “Cohen” identifies the named algebras. |
| 18 | “(cf 2.6.)”, “contenu dans … .11.” with “resp. 3.12.” above, “en vertu de … .6.”, “par descente comme dans … .11.” | Earlier criteria and the descent argument. The margin proposes keeping 4.1 in N°1 and mentioning 4.6 in a remark. |
| 21 | “Cf IV 2.10.1”; “critère jacobien de Nagata et Th. de Nagata” | The former is attached by a line to the localization question. The latter accompanies a complete local algebra over a field. |
| 22, 26 | “[cf … Diff. …]”; “Différentielles” on the cancelled cover | The abbreviation is an internal pointer. The cover offers a possible expansion; it does not establish the precise text intended. |
| 29 | “cf le NB marginal” | Points back to a marginal note in the field example. |
| 30 | “En vertu de (29)”, “(30) montre”, “en vertu de (30)” | Previous numbered statements of the divisor typescript. |
| 28 | “D’après les formules (12) et (13) (§ 2,n°2)” | Earlier trace and norm rules used to identify the restrictions to principal repartitions. |

## work:K22-02#6: Remarks of the model

- written by: GPT-6.2 Astra at reasoning effort max (ChatGPT Work), math notes of the folder K22-02
- file: `files/K22-02_mathnotes.md`, line 72
- pages: 22: 17-30
- kind: model remarks
- the sweep's object: Cohen algebras, his questions, derivations and the counterexample (cote 22, scans 17-30) -- model remarks (item SA23-17,SA23-18,SA23-19,SA23-20, tag H0D5, H0D6, H0D7, H0D9; basis index-row; fidelity not checked)

- **R25, medium.** The condition that the individual coefficient differentials be nonzero, taken alone, permits repeating a single coefficient. All the resulting differentials can then occupy the same finite set of basis positions. The distinction matters because scan 25 asks for infinitely many nonzero components. **Low confidence** that a step was inadvertently omitted: the more specific component conditions are crossed out, and the manuscript ends with dots.
- **C30.35, high.** Using the definitions (31) and (34) on a single place P′ gives the coefficient ∑e(P)f(P) at P′. The sheet identifies this sum with n, which recovers (35) by additivity. This checks the displayed consequence conditional on the local degree sum used on the page.
- **Reading question, scan 20, relative version of point 2.** The frozen reading has “sur” followed by a cancelled group and then Λ. There appears to be a separate small **de** immediately before Λ. It may be a live word outside the cancelled group. The final text retains the frozen boundary.
- **Reading question, scan 27, start of the field example.** The frozen text gives “Voici un exemple”. The group after “un” has a long join and a tall final stroke. An abbreviated **contre-ex.** is also plausible. This word was outside the marked span before Voici.
- **Reading question, scan 29, after the cancelled explanatory sentence.** The frozen line has “p-indép. sur F”. A small oval below and to the right of F might be an index **0**, or the lead-in to the hooked addition. The field later in the same paragraph is written with a plain double-stem F.

## MPL_22+23_002-016#36: A13 — conjecture / source question subsequently matched in context; 22/020, question 1

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 200
- pages: 22: 20
- kind: conjecture
- the sweep's object: his open questions 1-4 on formally simple and Cohen algebras -- 22/020, question 1 (item SA23-18, tag H0D6; basis index-row; fidelity not checked)

“Est-il vrai” asks for the converse from universal regularity to formal simplicity, and the nearby “OK” is itself only a short annotation. The supplied `EGA_chap0_ega0-22.tex`, 0.22.5.8, identifies the two tests through the maps $A\to A\otimes_k k'$ for finite extensions with $k'^p\subset k$, proving the implication the question asks about for the preadic topology. This is a direct context match to the field-base question; the bracketed general local-homomorphism formulation on the sheet additionally uses flatness and fibre comparison as organized in `EGA_chap0_ega0-19.tex`, 0.19.7.1, so the scope of “OK” should remain attached to its actual position.

## MPL_22+23_002-016#37: A14 — conjecture / self-flagged; 22/020, question 2 and heavily doubtful margin

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 204
- pages: 22: 20, 22
- kind: self-flagged / conjecture
- the sweep's object: his open questions 1-4 on formally simple and Cohen algebras -- 22/020, question 2 and heavily doubtful margin (item SA23-18, tag H0D6; basis index-row; fidelity not checked)

The author asks whether formal simplicity for the ordinary local topology persists for the discrete topology and writes “Il est possible que la réponse soit affirmative en car $p>0$, négative en car 0.” The margin begins “Faux” but the continuation and its attachment contain many frozen doubts, so it cannot certify a precise withdrawn general statement without further reading evidence. The relevant concrete comparisons are `EGA_chap0_ega0-19.tex`, 0.19.3.1 and 0.19.3.8 (the lifting problems under change of topology), and `EGA_chap0_ega0-22.tex`, 0.22.6.7 (the finite-type field-algebra case), while 22/022–025 adds the author's own finite-$p$-base case and infinite-differential obstruction.

## MPL_22+23_002-016#38: A15 — conjecture; 22/020 bottom–021 upper half, question 3

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 208
- pages: 22: 20
- kind: conjecture
- the sweep's object: his open questions 1-4 on formally simple and Cohen algebras -- 22/020 bottom–021 upper half, question 3 (item SA23-18, tag H0D6; basis index-row; fidelity not checked)

“Lieu ... est-il ouvert?” concerns the local formal-simplicity locus in the fibres of a flat noetherian map, followed by “bons anneaux,” Nagata, and resolution-of-singularities annotations. `EGA_chap0_ega0-22.tex`, 0.22.5.10(ii), repeats the openness question for the locus $\{\mathfrak p:A_{\mathfrak p}\text{ formally smooth over }k\}$, and 0.22.6.7 gives a finite-type/separable-field case via the determinant $\det(D_j(f_i))$ defining a neighbourhood. The sheet extends the enquiry to the displayed relative fibre rings $B\otimes_A\kappa(\mathfrak p)$; its difficult marginal qualifications remain reading questions, not a proof of the entire relative assertion.

## MPL_22+23_002-016#4: P04. The open problems actually listed

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 68
- pages: 22: 20, 23
- kind: research note
- the sweep's object: the EGA plan -- The open problems actually listed (item SA23-28, tag H0DH; basis index-row; fidelity not checked; flag: F10)

**Kind: conjecture / question inventory. Location: 22/020–021, numbered 1–4, heading “Questions ouvertes.”** The four explicit questions ask about (1) formal simplicity and universal regularity for noetherian local algebras/local maps, (2) passage from the habitual to the discrete topology, (3) openness of the fibrewise formally simple locus, with a related localisation question, and (4) openness of the flat locus of a noetherian ring map. The list carries its own qualifications and later annotations, including “OK” by (1), the positive/zero-characteristic expectation in (2), “bons anneaux” in (3), and the generic-flatness reduction written under (4); their exact wording and uncertain margin attachment must govern any resolution claim. **Context / state:** `EGA_chap0_ega0-19.tex`, 19.0.2 and 19.7; `EGA_chap0_ega0-22.tex`, 22.5.8 and introduction; IV contents 17.5, 17.8 and 17.14; **WG2 §2.1 #2** [unchecked plan] is answered by this actual question inventory, while the three Hua entries in `RESULTS_STATE.md` attach specifically to the later 22/023–029 developments.

## MPL_22+23_002-016#39: A16 — unproved claim; 22/021, “stable par localisation ?” and margins

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 212
- pages: 22: 21
- kind: unproved claim
- the sweep's object: his open questions 1-4 on formally simple and Cohen algebras -- 22/021, “stable par localisation ?” and margins (item SA23-18, tag H0D6; basis index-row; fidelity not checked)

The localization question has an exact map-level counterpart in `EGA_chap0_ega0-22.tex`, 0.22.5.9: $A_{\mathfrak p}\otimes_k k'$ is a localization of $A\otimes_k k'$, so the geometric-regularity test of 0.22.5.8 travels through that localization. This verifies the field-base localization mechanism associated with the manuscript's question, while its two marginal conditions about generization and neighbourhoods concern the further passage from stability to openness. The tentative reference “Cf IV 2.10.1|2.40.1” remains unresolved in the frozen text, and the supplied IV contents alone cannot adjudicate its digits.

## MPL_22+23_002-016#40: A17 — conjecture / unproved reduction; 22/021, question 4, lower half

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 216
- pages: 22: 21
- kind: conjecture
- the sweep's object: his open questions 1-4 on formally simple and Cohen algebras -- 22/021, question 4, lower half (item SA23-18, tag H0D6; basis index-row; fidelity not checked)

The author asks whether the flat locus of an arbitrary noetherian ring map $A\to B$ is open and reduces the enquiry to finding a nonempty flat open after $A'=A/\mathfrak p\subset B'=B/\mathfrak q$ and passage to $K'=\operatorname{Frac}(A')$. Context search finds local flatness comparison in `EGA_chap0_ega0-19.tex`, 0.19.7.1, and completed base change in 0.19.7.1.2, but no supplied proof of this full arbitrary-noetherian-map openness reduction. The exact quotient and localization maps written here are therefore a separate research item; a finite-type generic-flatness argument requires its own finite-type input, which this question does not write down.

## MPL_22+23_002-016#41: A18 — unproved claim; 22/022, lower half

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 220
- pages: 22: 22
- kind: unproved claim
- the sweep's object: derivations, p-bases and infinite support -- 22/022, lower half (item SA23-19, tag H0D7; basis index-row; fidelity not checked)

“En la complétant par les $t_i$, on trouve une $p$-base ... Donc dans ce cas on gagne” proposes a finite-$p$-base proof for a power-series algebra. In `EGA_chap0_ega0-21.tex`, 0.21.2.7, the discrete lifting argument uses both the $p$-basis and the injectivity of the Frobenius comparison $k\otimes_{k,F_k}A\to A$, $c\otimes a\mapsto ca^p$; the sheet's displayed $K\otimes_{K^p}A^p\to A$ is the corresponding coefficient comparison. This gives the two actual maps a verification of the surviving argument must examine, while the crossed-out broader assertions on the same page remain cancellations.

## MPL_22+23_002-016#42: A19 — conjecture / self-flagged; 22/023, upper half

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 224
- pages: 22: 23
- kind: self-flagged / conjecture
- the sweep's object: derivations, p-bases and infinite support -- 22/023, upper half (item SA23-19, tag H0D7; basis index-row; fidelity not checked)

“Je suis pessimiste,” “Je présume que,” and “je doute” mark distinct expectations, including the examples $\mathbb Q[[t]]$ and $\mathbb C[[t]]$ and the broader positive-dimensional assertion whose comparison sign is doubtful. The argument actually developed on 22/023–025 uses infinitely many coefficient differentials; for $\mathbb Q$ as coefficient field, $\Omega_{\mathbb Q/\mathbb Q}=0$, so that particular map does not supply the proposed contradiction. Context `EGA_chap0_ega0-20.tex`, 0.20.7.16, separately records the large ordinary differential module of characteristic-zero power series, giving a relevant route of comparison without converting the entire manuscript expectation into an established claim.

## MPL_22+23_002-016#43: A20 — own calculation / confirmation of a prior lead; 22/023 and 025, derivation argument

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 228
- pages: 22: 23
- kind: own calculation
- the sweep's object: derivations, p-bases and infinite support -- 22/023 and 025, derivation argument (item SA23-19, tag H0D7; basis index-row; fidelity not checked)

**Hua, findings register, `22-power-series-discrete-obstruction`** is marked conjectural and “new to us” in `notes/RESULTS_STATE.md`; the manuscript supplies the explicit test $f=\sum_n x_{i_n}t^n$ and the phrase “$Dt$ est combinaison lin. finie.” For the displayed $k=\mathbb Q(x_i)_{i\in I}$ and $A=k[[t]]$, removing the finitely many basis coordinates supporting $D(t)$ leaves infinitely many $dx_i$-coordinates and makes $D_j(t)=0$, so $D_j(f)\equiv D_j(\sum_{n<N}x_{i_n}t^n)\pmod {t^N}$. The $i_n$-coordinate of $D(f)$ then has coefficient $1$ at $t^n$, contradicting finite support in $A^{(I)}$ and verifying the asserted discrete $A/k$ obstruction through the coefficient-map criterion of `EGA_chap0_ega0-20.tex`, 0.20.7.2, whereas `EGA_chap0_ega0-19.tex`, 0.19.3.4, supplies the stated $t$-adic lifting property. Confidence is high in this verification of the lead's actual claim, and A22 supplies an additional projectivity argument for failure over the smaller base $\mathbb Q$; neither calculation asserts novelty or changes the register's recorded status.

## MPL_22+23_002-016#47: A24 — own calculation; 22/023, “$k=\mathbb Q$” example

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 244
- pages: 22: 23
- kind: own calculation
- the sweep's object: derivations, p-bases and infinite support -- 22/023, “$k=\mathbb Q$” example (item SA23-19, tag H0D7; basis index-row; fidelity not checked)

For the concrete algebra $A=\mathbb Q[[t]]$, the map $A\to A/(t)=\mathbb Q$ gives $\Omega_{A/\mathbb Q}/t\Omega_{A/\mathbb Q}\simeq\mathbb Q\,dt$: every derivation into the residue field sends $a_0+a_1t+t^2g$ to $a_1D(t)$. Localization gives $\Omega_{A/\mathbb Q}\otimes_A\mathbb Q((t))\simeq\Omega_{\mathbb Q((t))/\mathbb Q}$, whose dimension is infinite because $\mathbb Q((t))$ is uncountable while every algebraic extension of a finite-transcendence-degree extension of $\mathbb Q$ is countable. These two fibres exclude a free module of differentials, and Kaplansky's freeness theorem over the local ring $A$, combined with the projective-differential requirement for discrete formal smoothness, establishes the failure of that lifting property for this exact example. Context: `EGA_chap0_ega0-20.tex`, 0.20.4.13, 0.20.5.9, and 0.20.7.16; primary checks: Stacks Project [Tag 0593](https://stacks.math.columbia.edu/tag/0593) and [Section 00TH, Lemma 10.138.7](https://stacks.math.columbia.edu/tag/00TH); confidence high in the displayed argument, with no novelty claim and no extension to every possible interpretation of the doubtful positive-dimensional sentence.

## MPL_22+23_002-016#44: A21 — unproved claim / confirmation of a prior lead; 22/024–025, proposition and proof

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 232
- pages: 22: 24-25
- kind: unproved claim
- the sweep's object: derivations, p-bases and infinite support -- 22/024–025, proposition and proof (item SA23-19, tag H0D7; basis index-row; fidelity not checked)

**Hua, findings register, `22-p23-proposition-reconstruction`** is unsearched/conjectural with a partly proved Lean card, while the frozen proposition explicitly includes “sur $K$ relativement à $k$” before “à fortiori ... sur $k$.” The proof's finite-dimensional span $V$ is killed by choosing finitely many elements $a_1,\ldots,a_s\in K$ whose differentials span a subspace containing it and applying $\Omega_{K/k}\to\Omega_{K/k(a_1,\ldots,a_s)}$; the quotient still has infinite dimension because the removed span has finite dimension. After that quotient, truncation modulo $(t_1,\ldots,t_n)^N$ justifies the coefficientwise derivations on 025, and the nonzero $i_n$-coordinate at coefficient $t_1^n$ proves the claimed failure of a left inverse to $\Omega_{K/k}\otimes_K A\to\Omega_{A/k}$. Context: `EGA_chap0_ega0-19.tex`, 0.19.9.1, and `EGA_chap0_ega0-20.tex`, 0.20.7.2, identify precisely this relative lifting test; the manuscript adds both the relative qualification and the finite-base-enlargement step omitted from the register summary.

## MPL_22+23_002-016#45: A22 — own calculation / supplied proof step; 22/024, proposition's “à fortiori” clause, approximate lines 3–8

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 236
- pages: 22: 24
- kind: own calculation
- the sweep's object: derivations, p-bases and infinite support -- 22/024, proposition's “à fortiori” clause, approximate lines 3–8 (item SA23-19, tag H0D7; basis index-row; fidelity not checked)

The source's “à fortiori n'est pas ... sur $k$” is also valid for its displayed $A=K[[t_1,\ldots,t_n]]$, $n>0$, $\dim_K\Omega_{K/k}=\infty$: writing $\mathfrak m=(t_1,\ldots,t_n)$, coefficient inclusion and constant-term retraction give the explicit isomorphism $\Omega_{A/k}\otimes_AK\simeq\Omega_{K/k}\oplus\bigoplus_jK\,dt_j$, with $df\mapsto(d(f(0)),\text{linear coefficients of }f)$, because derivations into residue-field modules kill $\mathfrak m^2$. A free-module representation of $\Omega_{A/k}$ leads to a derivation $\delta:A\to F$ into a free direct sum after removing the finitely many basis coordinates supporting all $dt_j$; it has $\delta(t_j)=0$ and its coefficient image modulo $\mathfrak m$ still spans an infinite-dimensional space. Choose $a_r\in K$ and a coordinate $i_r$ outside the supports of all earlier $\delta(a_s)$ with $u_r=\delta_{i_r}(a_r)(0)\ne0$: for $f=\sum_ra_rt_1^r$, the equality $\delta(t_j)=0$ gives $\delta_i(\mathfrak m^N)\subset\mathfrak m^N$, hence $\delta_{i_r}(f)\equiv u_rt_1^r\not\equiv0\pmod{\mathfrak m^{r+1}}$, contradicting finite support in $F$. Thus $\Omega_{A/k}$ is not free, hence not projective by [Stacks 0593](https://stacks.math.columbia.edu/tag/0593), and $A/k$ fails discrete formal smoothness by `EGA_chap0_ega0-20.tex`, 0.20.4.9, with `EGA_chap0_ega0-19.tex`, 0.19.2.1, also checked against [Stacks 00TH, 10.138.8(6)](https://stacks.math.columbia.edu/tag/00TH): confidence high because the residue isomorphism, quotient and every nonzero coordinate are explicit; this adds a projectivity argument beyond the manuscript's displayed coefficient-map proof and supports Hua `22-p23-proposition-reconstruction` without a novelty claim or changing its recorded unreviewed status (details in `records/research_power_series_review.md`).

## MPL_22+23_002-016#52: A29 — supplied-context transcription errors verified against print; 22/024, “n'a pas d'inverse à gauche”

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 264
- pages: 22: 24
- kind: research note
- the sweep's object: derivations, p-bases and infinite support -- supplied-context transcription errors verified against print; 22/024, “n'a pas d'inverse à gauche” (item SA23-19, tag H0D7; basis index-row; fidelity not checked)

The original [EGA IV-1, printed p. 131](https://doi.org/10.1007/BF02684747), 0.20.5.7.1, labels the coefficient map $\Omega_{B/A}\otimes_BC\to\Omega_{C/A}$ by $v_{C/B/A}$ and the quotient map by $u_{C/B/A}$, consistently with its left-inverse criterion; `EGA_chap0_ega0-20.tex` reverses those two display labels. The concrete substitution $A=\mathbb Q$, $B=C=\mathbb Q[x]$ makes the printed $v$ the identity and $u$ the map $\mathbb Q[x]dx\to0$, locating exactly the left inverse used by the proof. Independently inspected printed pp. 147–148 also give the contravariant map $\operatorname{Hom}_C(\Omega_{C/A},L)\to\operatorname{Hom}_C(\Omega_{B/A}\otimes_BC,L)$ in 0.20.7.2, whose direction is reversed in the context, and a short topology-induced proof of 0.20.7.3 that differs from the supplied text. These primary checks confirm the coefficient-map criterion used in A20/A21 and the manuscript's “n'a pas d'inverse à gauche” on 22/024, without resolving or changing its frozen arrow-reading marker; confidence high from direct inspection and the explicit test maps.

## MPL_22+23_002-016#81: S02. The proof text at EGA 0.20.7.2–3

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 446
- pages: 22: 24
- kind: research note
- the sweep's object: formally smooth, formally unramified and formally simple algebras; Cohen algebras (EGA 0_IV 19-22 draft, cote 22) -- The proof text at EGA 0.20.7.2–3 (item SA23-17, tag H0D5; basis index-row; fidelity not checked)

**Kind: reading question in the supplied context. Location: 22/024's coefficient-differential map; context `EGA_chap0_ega0-20.tex`, 0.20.7.2–3.** The printed p. 147 gives the precomposition map \(h\mapsto h\circ v\) from \(\operatorname{Hom}_{C,\mathrm{cont}}(\Omega_{C/A},L)\) to \(\operatorname{Hom}_{C,\mathrm{cont}}(\Omega_{B/A}\otimes_BC,L)\), agreeing with restriction of derivations, whereas the supplied context reverses that display. The printed topology comparison says “moins fines”; the supplied English text says “finer,” so the identity from the induced module topology to the stated differential topology is the comparison to retain. At 0.20.7.3 the original p. 148 uses induced topologies and cites 20.7.2 and 19.1.7, while the supplied context inserts a substantially different paragraph asserting surjectivity, injectivity and density. These verified textual differences are recorded for the comparison edition only, with primary reference [B6] and no change to the frozen page files.

## MPL_22+23_002-016#46: A23 — unpursued implication; 22/025, first display and infinite-support conclusion

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 240
- pages: 22: 25
- kind: unpursued implication
- the sweep's object: derivations, p-bases and infinite support -- 22/025, first display and infinite-support conclusion (item SA23-19, tag H0D7; basis index-row; fidelity not checked)

The inclusion “$A^{(I)}\subset A^I$” isolates an actual completion issue: for $A=K[[t]]$ and a countable subset of $I$, the vector $(t^n)_n$ belongs to $\varprojlim_N\bigoplus_n A/t^NA$ through its finite truncations, while it has infinitely many nonzero coordinates in $A^I$. The canonical map $\bigoplus_n A\to\varprojlim_N\bigoplus_n A/t^NA$ thus places the manuscript's forbidden coefficient vector in a larger target where each reduction modulo $t^N$ has finite support. `EGA_chap0_ega0-20.tex`, 0.20.7.17–18, compares the corresponding completed differential map with the ordinary one, so the sheet supplies a concrete element explaining the role of completion rather than merely a verbal distinction between two topologies.

## MPL_22+23_002-016#48: A25 — own calculation / confirmation of a prior lead; 22/027 and 029, counterexample

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 248
- pages: 22: 27
- kind: own calculation
- the sweep's object: the counterexample on 22/027-029 and EGA 0_IV 22.5.10(i) -- 22/027 and 029, counterexample (item SA23-20, tag H0D9; basis index-row; fidelity not checked)

**Hua, findings register, `22-differentials-kernel-counterexample`** is unsearched/conjectural with a partly proved Lean card; the source's “Voici un contre” admits the concrete specialization $K=\mathbb F_2(x,b,c)$, $a=b^2$, $y=ax+c^2$, and $k=\mathbb F_2(x,y)$. Here $x,a,y$ are algebraically independent (the rational field $K$ is algebraic over $\mathbb F_2(x,a,y)$), hence $a\notin k$, and $dy=a\,dx$ in $\Omega_K$, and every $f\in k\cap K^2$ satisfies $0=df=(\partial_xf+a\partial_yf)dx$, whence both partial derivatives vanish and $f\in k^2$ by the basis $1,x,y,xy$ of $k$ over $k^2$. Thus $k\cap K^2=k^2$ and the exact map $K\,dx\oplus K\,dy=\Omega_{k/k^2}\otimes_kK\to\Omega_K$ has kernel $K(dy-a\,dx)$, whose nonzero vectors cannot descend to a $k$-line because their coefficient ratio is $a\notin k$. Context: `EGA_chap0_ega0-21.tex`, 0.21.1.9 and 0.21.2.5, and `EGA_chap0_ega0-20.tex`, 0.20.5.7; confidence high in this explicit specialization, which verifies the advertised phenomenon and adds the one-dimensional kernel calculation without claiming novelty.

## MPL_22+23_002-016#49: A26 — unpursued implication; 22/027, “ou ... ce qui revient au même”

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 252
- pages: 22: 27
- kind: unpursued implication
- the sweep's object: the counterexample on 22/027-029 and EGA 0_IV 22.5.10(i) -- 22/027, “ou ... ce qui revient au même” (item SA23-20, tag H0D9; basis index-row; fidelity not checked)

Set $k'=k\cap K^p$ as on the sheet; the transitivity map $\Omega_{k/\mathbb F_p}\otimes_kK\to\Omega_{k/k'}\otimes_kK$ is surjective and its kernel is the $K$-span of $d_{k/\mathbb F_p}a$ for $a\in k'$. Because $d_K(a)=0$ for those elements, the map to $\Omega_{K/\mathbb F_p}$ factors through that quotient, and the new kernel is exactly the old kernel modulo this displayed span. This is the precise quotient morphism behind the manuscript's equivalence and its margin about a kernel “défini sur $k$”; context `EGA_chap0_ega0-20.tex`, 0.20.5.7, supplies the transitivity sequence, and the note sharpens the unreviewed Hua `22-differentials-kernel-counterexample` entry by identifying the map rather than asserting an abstract equivalence.

## MPL_22+23_002-016#50: A27 — printed-source discrepancy / own calculation; 22/027–029 compared with EGA 0.22.5.10(i)

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 256
- pages: 22: 27-29
- kind: own calculation / printed-source discrepancy
- the sweep's object: printed EGA 0_IV 22.5.10(i) read literally (K = k(X^{1/p}+ZY^{1/p}), k = k_0(X,Y)) is purely transcendental, so Upsilon_{K/k} = 0; the manuscript counterexample on 22/027-029 works (item SA23-20, tag H0D9; basis passage-read; fidelity agrees; flag: F01)

The context `EGA_chap0_ega0-22.tex`, 0.22.5.10(i), follows the original [EGA IV-1, printed p. 204](https://doi.org/10.1007/BF02684747), independently inspected after freeze: both give $k=k_0(X,Y)$ and $K=k(X^{1/p}+ZY^{1/p})$ for perfect $k_0$ and three indeterminates, followed by “extension inséparable.” Writing $w=X^{1/p}+ZY^{1/p}$ and $E=k(X^{1/p},Y^{1/p})$, the affine change $Z=(w-X^{1/p})/Y^{1/p}$ proves that $w$ is transcendental over $E$, hence gives the exact isomorphism $k(T)\xrightarrow{\sim}K$, $T\mapsto w$. Thus the differential map is the inclusion $K\,dX\oplus K\,dY\hookrightarrow K\,dX\oplus K\,dY\oplus K\,dw$, with zero kernel, and the printed nonzero-$\Upsilon_{K/k}$ assertion fails for these displayed fields, although $K^p\cap k=k^p$ holds by the independent $dX,dY$ coefficients. The manuscript's “Voici un contre” and algebraic-coefficient alternative give the explicit nonzero kernels verified in A25/A28, supporting Hua `22-differentials-kernel-counterexample` through those calculations; confidence is high in the printed discrepancy and these exact maps, while a targeted primary-errata search has not located a correction and no replacement generator is attributed to the author.

## MPL_22+23_002-016#53: A30 — own calculation / exact link between the two examples; 22/027–029 and context 0.22.5.10(i)

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 268
- pages: 22: 27-29
- kind: own calculation
- the sweep's object: explicit link between the manuscript characteristic-2 example and printed 0_IV 22.5.10(i) (item SA23-20, tag H0D9; basis entry-read; fidelity not checked; flag: F01)

In A25's explicit characteristic-two example, set \(X=y\), \(Y=x\), \(Z=b\) and \(w=c\); the identity \(c^2=y+b^2x\) identifies the printed expression \(X^{1/2}+ZY^{1/2}\) with \(c\) in an algebraic closure, so the printed field becomes \(k(c)\) inside the manuscript specialization \(K=k(b,c)=\mathbb F_2(x,b,c)\). The coefficient adjunction is the actual inclusion \(k(c)\hookrightarrow k(b,c)\), and the substitution has inverse \(x=Y,b=Z,c=w\) with \(y=X=w^2+Z^2Y\), specifying the field presentation rather than attributing an unwritten correction to EGA. Along \(k\to k(c)\to K\), the differential maps after extension to \(K\) send \((dx,dy)\) first to their two basis vectors in \(K\,dx\oplus K\,dy\oplus K\,dc\), then send \(dx\mapsto dx,dy\mapsto b^2dx,dc\mapsto dc\), producing exactly the kernel \(K(dy-b^2dx)\) computed in A25. **Confidence: high**, because the substitutions and both differential maps are explicit; context `EGA_chap0_ega0-21.tex`, 0.21.1.9 and 0.21.2.5, and `EGA_chap0_ega0-22.tex`, 0.22.5.10(i), supply the comparison objects, and this construction bears on Hua `22-differentials-kernel-counterexample` without claiming an intended emendation or novelty.

## MPL_22+23_002-016#19: O13. Local completion maps defining trace and norm

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 130
- pages: 22: 28
- kind: research note
- the sweep's object: trace and norm for finite morphisms; separated quotient; divisor/idele compatibility (reused typescripts, cote 22) -- Local completion maps defining trace and norm (item SA23-16, tag H0D4; basis index-row; fidelity not checked)

**Kind: unproved claim. Location: 22/028, formula (40) and paragraph following it.** The reused typescript defines \(\operatorname{Tr}_{K/K'}\) and \(N_{K/K'}\) on répartitions through the component maps \(\widehat K_P\to\widehat K'_{P'}\), summing local traces and multiplying local norms over \(P\mid P'\), then claims agreement with field trace and norm on principal répartitions. A proof of that agreement must supply the local-factor decomposition for the finite extension and the compatibility of field trace/determinant with base change; the supplied leaf cites formulas (12) and (13), which are absent from this package. **Context / state:** the closest supplied locators are `ega2-indexes-and-contents-fr.tex`, II 6.4 “Déterminant d'un endomorphisme” and 6.5 “Norme d'un faisceau inversible,” plus IV contents 21.5; the context search finds no copy of the cited earlier formulas or settled register entry.

## MPL_22+23_002-016#20: O14. The divisor/idèle compatibility squares

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 134
- pages: 22: 28, 30
- kind: research note
- the sweep's object: trace and norm for finite morphisms; separated quotient; divisor/idele compatibility (reused typescripts, cote 22) -- The divisor/idèle compatibility squares (item SA23-16, tag H0D4; basis index-row; fidelity not checked)

**Kind: unpursued implication. Location: 22/030, formulas (31)–(38); 22/028, formulas (39), (44).** The two concrete commutative-square claims are \(D\circ\operatorname{Ext}_{K',K}=\operatorname{Ext}_{K',K}\circ D'\) and \(D'\circ N_{K/K'}=N_{K/K'}\circ D\), with the upper maps acting on idèles and the lower maps on divisors. On the divisor generators the written maps are \(P'\mapsto\sum_{P\mid P'}e(P)P\) and \(P\mapsto f(P)P'\), so their composite sends \(P'\) to \((\sum e(P)f(P))P'\); the further equality with \(nP'\) in formula (35) uses the source's explicit “Comme \(\sum e(P)f(P)=n\),” whose ambient field/valuation hypotheses and proof are not supplied on the retained leaf. **Context / state:** `ega4-backmatter-contents-fr.tex`, IV 21.4–21.5 and 21.9–21.10, printed p. 343; EGA I introduction p. 6, “Résidus et dualité”; these are comparison locators, with no matching settled register item or supplied proof of all idèle-level compatibilities.

## MPL_22+23_002-016#21: O15. The elided verification of projection and transitivity identities

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 138
- pages: 22: 28
- kind: research note
- the sweep's object: trace and norm for finite morphisms; separated quotient; divisor/idele compatibility (reused typescripts, cote 22) -- The elided verification of projection and transitivity identities (item SA23-16, tag H0D4; basis index-row; fidelity not checked)

**Kind: unproved claim. Location: 22/028, immediately before formulas (41)–(45).** The text introduces its identities with “que l'on vérifie comme l'âne qui trotte,” including the trace projection formula, trace/norm after extension, and “formules de transitivité.” At each completion the trace identity requires \(\operatorname{Tr}(a\,x')=\operatorname{Tr}(a)x'\) for the embedded \(x'\in\widehat K'_{P'}\), while the norm identity after extension tracks the scalar determinant \(N(x')=(x')^{[\widehat K_P:\widehat K'_{P'}]}\) and the sum of those local degrees; these are the exact local calculations whose global bookkeeping has been abbreviated. **Context / state:** `ega2-indexes-and-contents-fr.tex`, II 6.4–6.5, and IV contents 21.4–21.5; searches for répartitions/idèles find no fuller derivation in the supplied context and no matching settled register entry.

## MPL_22+23_002-016#22: O16. Reused-page order and the unfinished topology paragraph

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 142
- pages: 22: 28, 30
- kind: research note
- the sweep's object: cotes 22-23 documentary -- Reused-page order and the unfinished topology paragraph (item SA23-47, tag H0DY; basis index-row; fidelity not checked)

**Kind: reading question. Location: 22/030, last line; 22/028, first line and final section heading.** Formula numbers 31–38 on 030 precede 39–45 on 028, supplying internal evidence for the original text's order while the archival transcription retains scan order 028 then 030. The last words on 030, “dans ce,” and the doubtful clipped opening on 028 do not by themselves recover the exact intervening phrase, which remains a reading question. The heading “5. Topologies sur l'espace des répartitions et sur le groupe des idèles” starts a construction from groups \(G_\alpha\) and open normal subgroups \(H_\alpha\), but the retained leaf ends at “for-” before giving the fundamental neighbourhood system, leaving that precise topology unavailable in these sheets. **Context / state:** `README.md`, reused typed material within cote 22; context searches for “répartitions,” “idèles,” and the heading find no continuation; no matching settled register entry.

## MPL_22+23_002-016#51: A28 — own calculation; 22/029, final alternative using an algebraic coefficient

- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `files/MPL_22+23_002-016_notes.md`, line 260
- pages: 22: 29
- kind: own calculation
- the sweep's object: the counterexample on 22/027-029 and EGA 0_IV 22.5.10(i) -- 22/029, final alternative using an algebraic coefficient (item SA23-20, tag H0D9; basis index-row; fidelity not checked)

The final “On peut aussi prendre” construction has a finite-degree realization with $a\in\mathbb F_4\setminus\mathbb F_2$, $a^2+a+1=0$, $b=a^2$, $K=\mathbb F_4(x,c)$, $y=ax+c^2$, and $k=\mathbb F_2(x,y)$. Since $K$ is algebraic over $\mathbb F_4(x,y)$, the two elements $x,y$ are algebraically independent, so $a\notin k$ and $k(b)=\mathbb F_4(x,y)$ has degree two over $k$; the other degree is two because $\partial_y(y-ax)=1$ proves that $y-ax$ is not a square in that field, giving $[K:k]=4$. Here $b^2=a$, the coefficient extension is separable, the adjoining of $c$ is purely inseparable, and $dy=a\,dx$ gives $k\cap K^2=k^2$ and kernel $K(dy-a\,dx)$ by the explicit partial-derivative calculation in A25. This realizes the source's two adjunctions using actual field embeddings, with context `EGA_chap0_ega0-21.tex`, 0.21.4–6, and the comparison question 0.22.5.10(i); confidence high because both degrees and the kernel have been computed, with no claim that these exact constants were written on the page.
