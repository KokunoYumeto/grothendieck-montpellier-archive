# The concordance of WT_22_020-030

For every object (the sweep's tag) that the notes on these pages are about, the entries on the same object elsewhere in the archive, nearest first (the same folder, then the same topic, then other topics), with their text.

# H0DY: cotes 22-23 documentary: titles, page sequences, dates, source checks

- its entries on these pages: MPL_22+23_002-016#77, MPL_22+23_002-016#78, codex:K22-02#2, MPL_22+23_002-016#22
- in the archive: 9 entries; 22: 2-5,17-30; 22,23: 2,4,6,9; 23: 2-16,17-32,33-50,51-65,66-82,91

## MPL_22+23_002-016#79 (same folder; 22: 2, 15; 23: 2): P08. Date evidence and chronology limits

**Kind: reading question — dating a plan or unit. Location: 22/002, 004, 006, 008, printed dating; 23/002–016, source titles.** The explicit 1963 dates belong to the two Jouanolou offprints and their session footnotes, and the 1940 date on 22/015 belongs to the cited MacLane paper; these inscriptions date the identified publications. The catalogue ranges “1963-[vers 1967][20]” for cote 22 and “1966-1968” for cote 23 come from the supplied README, while the selected handwritten title sheets themselves carry no date. Consequently the present record supports the exact offprint dates and catalogue ranges, with the individual manuscript plan/title dates left undetermined. **Context / state:** `README.md`, “This package in our plan”; no matching settled chronology item in `RESULTS_STATE.md`.

## MPL_22+23_002-016#82 (same folder; 22: 3; 23: 7): S03. Scope of the literature comparison

**Kind: reading question / research limit. Locations: 22/003, 015, 024, 027–029; 23/007, 013.** The original Lang 1952 argument, the full MacLane 1940 paper, the continuation and attribution of the English integrability typescript, and the other archive cotes named in the README were not supplied or independently reconstructed here. The Hua statuses describe that register's claims, including its own search and Lean-card reports; the concrete verifications in A20–A28 do not establish priority or the state of all subsequent literature. The source-by-source checks below and the logged searches delimit the evidence actually used.

## codex:K22-01#2 (same folder; 22: 2-9, 15): Title sheets, dates and page counts they carry

| Scans | What is on the paper |
|---|---|
| 2–5 | « Algèbre. — Étude différentielle des anneaux locaux réguliers : applications. » Note by M. Jean-Pierre Jouanolou, presented by M. René Garnier. Scan 2 carries « C. R. Acad. Sc. Paris, t. 257, p. 2948–2950 (13 novembre 1963). Groupe 1. » Scans 3 and 4 carry printed (2) and (3). The note on scan 4 says « Séance du 4 novembre 1963. » Scan 5 has printer's number 165.056. This gives three article pages and a fourth scanned side with the imprint. |
| 6–9 | « Algèbre. — Sur les modules de différentielles. » The author and presenter are again Jouanolou and Garnier. Scan 6 gives t. 256, p. 842–844, « Séance du 21 janvier 1963. » and « Groupe 1 ». Scans 7 and 8 carry printed (2) and (3). Scan 8's note says « Séance du 14 janvier 1963. » Scan 9 has printer's number 163.228. Again there are three article pages and an imprint side. |
| 10–16 | Seven consecutive typescript leaves carry handwritten upper-right numbers 24, 25, 26, 27, 28, 29 and 30. This excerpt starts in a sentence. No title, author line, date or overall page-count statement appears on these sheets. The year 1940 on scan 15 belongs to a citation. |
| 2–16 | The pencilled numbers in the lower corners form a separate sequence, 1–15. The package contains no separate title sheet or letter. |

## codex:K23-01#2 (same topic; 23: 17-32): Title sheets, dates and page counts

Scan 18 has the cover title “Fibrés des germes d’ordre $n$ de sections, etc.” and the second heading “Transformations infinitésimales”, both at upper right. The short strokes beneath *sections* and *infinitésimales* are visible on the scan.

No date, statement of page count or sequence of authorial page numbers appears in these sixteen scans. The consecutive pencil figures 16–31 in the lower corners are the archive sheet numbers. Each is recorded in its page file as a comment. No typed page number or letter date occurs here.

## codex:K23-02#2 (same topic; 23: 33-41, 44-47, 49-50): Title sheets, dates and page counts

| Scan | Inscription | Function on the sheet |
| --- | --- | --- |
| 34 | « Exemples, » / « Cas particuliers » | Two-line cover title. |
| 38 | « -9. 7- », « n° 215 » | Centred typescript folio and separate document number at top right. The text starts in mid-sentence and ends during condition C′. |
| 39–40 | « Foncteur différentiel d'ordre » with a short n/r on 39; « Foncteur différentiel d'ordre ≤ n. » on 40 | Cover title and opening title in the body. |
| 44 | « Paris le 11/01/68 » | Letter from LÊ Dũng Tráng to A. Grothendieck. |
| 45–47 | Circled 1, 2 and 3 | Lê’s numbering on the three enclosures. |
| 49 | « EGA IV 18 » and « EGA VI » | Two reference headings on the same mathematical sheet. |
| 50 | « Suites régulières » / « Th. II.2.9. de Raynaud » | Cover title and theorem reference. The first two strokes of the number can also be 11. |

No sheet in this selection states a total page count. The pencilled numbers at the foot of the scans are recorded as archive comments in the page files.

## codex:K23-03#2 (same topic; 23: 51-65): Title sheets, dates and page counts

| Scans | What the sheets carry |
|---|---|
| 51–52 | Both have the printed heading INSTITUT / DES HAUTES ÉTUDES SCIENTIFIQUES. The manuscript headings concern applications of 11.2.9 and regular sequences/immersions. Scan 52 lists Deligne letters of 17 and 29 October 1966. |
| 53–54 | Two consecutive sides of an undated typescript headed “PS”. It predicts the appearance of SGA 6 “vers la fin de l'année 67 ou début 68”. No typed page number is visible. |
| 55 | Cover title “Lettres Deligne”. |
| 56–57 | “Bruxelles 5, le 15 décembre 1966”. Two scan pages, with no authorial page number. The opening mentions a letter “du 28” without naming the month. |
| 58–59 | “Rösrath, le 29 octobre 1966”. Two scan pages, without authorial foliation. The address is said to hold “jusqu'au 1er juillet 67”. |
| 60–65 | “Bruxelles 5, le 17 octobre 1966”. The first sheet has no visible authorial number. Scans 61–65 have 2, 3, 4, 5 and 6 respectively at upper right. Scan 65 refers back to “pg 2”. |
| 51–65 | The successive lower-corner archive numbers are 50–64. No sheet states a total page count. The spans above count the supplied scans. |

## codex:K23-04#2 (same topic; 23: 66-68, 70-71, 73-82): Title sheets, dates and page counts

| Scan | Title or numbering on the sheet |
| --- | --- |
| 66 | Cover with “Divers ....” in the upper right. |
| 67–68 | “Structure Main Theorem” on 67, continued as c) on 68. Scan 67 carries the printed heading “INSTITUT / DES HAUTES ÉTUDES SCIENTIFIQUES”. |
| 70 | “Morphismes ess.” followed by a cancelled word and “de prés. finie”. |
| 71 | “Morphismes essentiellement affines”. |
| 73 | “X préschéma” and “Conditions équivalentes”. The lower group begins “Cor” and “Cond. équiv.” |
| 74 | Handwritten page 41. The typescript has “Théorème 9.4.” and “9. 4.1.” |
| 75–76 | “Condition” and $(h_0)$ on 75. The continuation on 76 includes “Corollaire 1”. |
| 77 | Unheaded sheet of diagrams and conditions. |
| 78 | “Conditions équivalentes” below the cancelled upper group. |
| 79 | Handwritten page 24 above the typescript beginning “Démonstration. (i).” |
| 80 | “Cond équivalentes”, alongside the arrow from $Y$ to $X$. |
| 81 | “2.14.” is written among the upper formulas. The inverted typescript has “Corollaire 6.3.” No manuscript page number is apparent. |
| 82 | Cover with “IV 5”, a cancelled title, and “Compléments dimensionnels” below. |

No date or statement of a total page count appears on these sheets. The small lower-corner numbers match the archival sequence and are recorded as LaTeX comments. The inventory classifies 74 and 79 as reused typed leaves on the basis of the writing visible through the sheets and their independent text and pagination. On 81 the two orientations are visible on the same face.

## codex:K23-05#2 (same topic; 23: 91): Title sheets, dates and page counts

| Scan | What the sheet carries |
|---|---|
| 91 | “IV” with a bar above and below, followed by a mark read as “12” or “§ 2”. The title is “Fibres des morphismes plats de présentation finie”. |

Dates written on the sheets: none. Stated page counts or typescript pagination: none. The small pencil numbers in the lower corners are archive foliation. They appear as comments in the page files.

## codex:K23-06#2 (same topic; 23: 2-16): Title sheets, dates and page counts

| Scan | Inscription or numbering | Position and interpretation |
| --- | --- | --- |
| 002 | EGA IV, Calcul diff. (compléments) | Folder title at upper right. IV has a rule above and below. |
| 003 | Discriminant / Discriminants etc | Cover at upper right. The word ending remains doubtful. |
| 007 | 3 | Centred page number on an English typescript beginning with a displayed equation. Its last sentence continues beyond the sheet. No author or title appears here. |
| 008 | Exponentielle / Exponentielles | Title at upper right. The low terminal stroke leaves the number open. |
| 009 | Sorites sur l'exponentielle; circled 1 | Underlined heading and the first numbered section of the notes. |
| 010, 011, 014 | Circled 2, 3 and 4 respectively | These introduce successive sections. The circled 3 begins partway down 011. |
| 016 | Proposition | Underlined statement heading in the lower half. The last name in the statement runs to the foot. |

The supplied sheets carry no dates or stated page totals. The pencil numbers 1 through 15 at the lower corners run from scan 002 through 016. They are archival sheet numbers. The date range in the archive description does not appear as a dateline on these pages.

## MPL_22+23_002-016#80 (other topic; ): S01. Supplied context and original-print checks

**Kind: reading question / source control. Locations: A27, A29; O05, O07–O10; E01–E02.** The supplied `ega_fr` files are a textual comparison edition, with English prose in most chapter-0 files despite the README's description of a French edition. The notes identify their filenames and numbered passages, and the original-print checks below cover specific discrepancies rather than certify every line of that edition. The original EGA IV-1 leaves at printed pp. 131, 147–148 and 204 were retrieved and visually inspected after freeze; A27 and A29 record their results.

# H0DH: the EGA plan: thirteen chapters, subjects after IV, EGA VI plans and open problems (cotes 22-23, 26)

- its entries on these pages: MPL_22+23_002-016#2, MPL_22+23_002-016#3, MPL_22+23_002-016#4
- in the archive: 2 entries; 22,23: scans not given at index level; 26: 2-11

## MPL_22+23_002-016#1 (same folder; 22: 10, 19; 23: 2): P01. The available plan witnesses

**Kind: reading question — which plan is actually witnessed? Location: 22/019–021, headings and question numbers; 23/002–003 and 008–009, titles.** The 44 pages carry “Questions,” “Questions ouvertes,” “EGA IV, Calcul diff. (Compléments),” “Discriminant etc,” and “Exponentielle,” together with the local statement numbers in the algebra text; their chapter evidence is the explicit “IV” on 23/002 and the internal references to Chapters III and IV on 22/010 and 021. A chapter-by-chapter treatise plan is supplied by `context/ega_fr/EGA_I_introduction_plan_of_the_treatise.tex`, printed p. 6, while the README only names the other witnesses “CSG U90d,” cotes 26 and 48, without supplying their texts. The side-by-side comparison therefore has one complete numbered column here, with the other columns recorded as unavailable rather than reconstructed from the subject matter. **Context / state:** `context/README.md`, “What our planning document asks”; `RESULTS_STATE.md`, **WG2 §2.1 #2** [unchecked planning item], whose quoted extract supplies no additional complete chapter list; no matching settled register entry.

## MPL_22+23_002-016#5 (same folder; 22: 18; 23: 2, 4): P05. Limits of the requested archive-wide comparison

**Kind: reading question — missing witnesses. Location: current 22/018 “par descente”; 23/002 “Compléments”; context README planning list.** Cotes 127 and 128, Deligne's notes, cote 91, and the open list in cote 26 are not part of these 44 pages or the supplied context files; the current source therefore supplies no textual basis for reporting their statements, proof lengths, chapter assignments or dates. The particular descent passage on 22/018 and the projective maps on 23/004–006 are the concrete evidence that this package adds to the broader planning question. **Context / state:** `README.md`, “What our planning document asks,” including “127 and 128,” “Hom functors by non-projective methods (91),” and “what 26 lists as open”; **MPL_131 10** [first-pass lead] and **WG2 §2.1 #2** [unchecked planning item], with no matching settled register entry.

## MPL_22+23_002-016#6 (same topic; 23: 2): P09. The two context tables of contents

**Kind: reading question — comparison witness, not a newly recovered archive plan. Location: 23/002 “EGA IV,” compared with the supplied EGA tables of contents.** `ega2-indexes-and-contents-fr.tex`, printed pp. 213–215, gives Chapter II “Étude globale élémentaire de quelques classes de morphismes” and closes with “Reçu le 22 juillet 1960”; `ega4-backmatter-contents-fr.tex`, printed pp. 341–343, gives Chapter IV “Étude locale des schémas et des morphismes de schémas (fin)” and §§16–21. These are useful later chapter-title and contents witnesses beside the 1960 introduction's shorter IV title “Étude locale des morphismes,” but the supplied IV contents excerpt has no date inscription. **Context / state:** the two named files at their printed contents pages; **WG2 §2.1 #2** [unchecked planning item], with no settled correspondence table.

## codex:H26-01#1 (same topic; 26: 2-11): Steps the pages mark as unverified

| Scan | Place | Manuscript words or marks |
|---|---|---|
| 3 | §2, after the corrected title | “Intervertir 1 et 2 ??” questions the order of the two entries. |
| 3 | §6 | “Évᵗ descente des … faisceaux étales ?? …” questions the proposed addition. |
| 3 | §10, above the circled number | “Après §12 ??” questions the position of the entry. |
| 3 | §10, brace at right | “Foncteurs excellent sur S / morphismes excellent / ??” (both lines partly uncertain). |
| 3 | §11, pencilled box | “Commun au … ? Cas Greenberg ?” with doubtful words between the two questions. |
| 5 | Under Manquent, Picard group | “(?) Étude du Picard d’un schéma projectif en termes d’un pinceau de sections hyperplanes.” |
| 7 | Question below the ruled-off recommendation | “(pré)-Relation d’équivalence en pièces détachées ??” next to the circled pair of R's. |
| 8 | Crossed draft, Picard des courbes | The bracket after “diviseur Θ” ends “etc ?”. The last line also names an appendix, “Pbs ouverts.” |
| 9 | Lower pair of Hom formulas and the V formula | A question-shaped sign at the left brace and “? / Notation opportune ???” at the loop beside V. |
| 10 | Cover | “Problèmes ouverts”. No individual step on this cover. |
| 11 | Heading and a–e | “Problèmes-types à résoudre”. The listed subjects begin “Anneaux de définition”, “Hilbert, Picard sans hypothèse projective”, “Passage au quotient sans hypothèse de platitude”, “Passage au quotient par Gl …” and “Modules de variétés …”. Beside b the sheet adds “[Résultats partiels]” and, next to the separate Dual line, “OK. par Raynaud”. |
| 11 | f–h | “Classification de fibrés principaux …”, “G commutatif”, “G non néc. commutatif”, “Cas particulier ; G fini”, and the example with X and G. The left note ends “cas fini : rédiger / vérifier / vérifié” (reading uncertain). The explicit question “Pb mal posé ?” is beside h. |
| 11 | i and j | “Les modules formels d’une variété abélienne … sont-ils simples sur l’anneau de base ?” has a circled “oui”. The last boxed entry is “‘Th. du carré’ dans cas non projectif ----”. |

Scans 2, 4 and 6 carry no explicit question about a step. The question marks added to uncertain readings in the transcription are editorial and have not been used as evidence for this list.

## codex:H26-01#2 (same topic; 26: 2-11): Title sheets, dates and page counts

| Scan | What the sheet carries |
|---|---|
| 2 | Cover. A barred V, then “Plan” and “Notations”. |
| 3 | Outline headings “A) Descente et passage au quotient” and “B)”. The earlier B title is crossed; the new wording is “Méthodes de construction non projectives”. |
| 4 | Typescript page number “(32” at upper right. |
| 5 | Outline headings C and D, “Mèthodes de construction projectives” (also read “Méthodes”) and “Méthodes de construction mixtes”. The two occurrences of “de construction” are additions. “Manquent” heads the lower list. |
| 6 | Typescript page number “(31” at upper right; numbered text sections 7.9.2. and 7.9.3. |
| 7 | “Recommandation importante”. |
| 8 | Cancelled draft. A hatched heading in the upper-left corner; the bottom label reads “L … Pbs ouverts.” |
| 9 | “Notations”, in the upper right of the working table. |
| 10 | Cover. “Problèmes ouverts”. |
| 11 | “Problèmes-types à résoudre”. |

Dates written on these sheets: none. Explicit page counts: none. The pale lower-corner numerals 1 through 10 are the archive's sheet numbers; the typescript identifiers on scans 4 and 6 have been recorded separately.

# H0D5: formally smooth, formally unramified and formally simple algebras; Cohen algebras (EGA 0_IV 19-22 draft, cote 22)

- its entries on these pages: codex:K22-02#1, work:K22-02#1, work:K22-02#2, work:K22-02#3, work:K22-02#4, work:K22-02#5, work:K22-02#6, MPL_22+23_002-016#81
- in the archive: 5 entries; 22: 2-4,2-16,10,11,12,13,14,15,16-18,16,17-30,17,18

## MPL_22+23_002-016#24 (same folder; 22: 10): A01 — self-flagged; 22/010, opening paragraph and lower proof

“J'ai oublié d'introduire un système fondamental” and the inserted “tous les $I_iB$ et $I_iC$ qui doivent être fermés” record an explicit repair of the quotient system used in $B\to\varprojlim B_i$ and $C\to\varprojlim C_i$. The same closed-ideal passage is made explicit in `ega_fr/EGA_chap0_ega0-19.tex`, 0.19.7.1.2, through $E/\mathfrak m^hE\simeq(B/\mathfrak m^h)\otimes_A C$, and in 0.19.7.1.5 through lifting $u_0$ before the comparison lemma; the sheet adds the drafting history and its missing hypothesis, rather than another proved register result.

## MPL_22+23_002-016#25 (same folder; 22: 10): A02 — self-flagged / unproved claim; 22/010, last proof paragraph and diagram

The author writes “sauf erreur figure déjà en lemme quelque part au Chap III (j'espère, avec la généralité qui convient...)” about the graded comparison that lifts bijectivity modulo the defining ideal. `ega_fr/EGA_chap0_ega0-19.tex`, 0.19.7.1.4, gives the corresponding square with $\operatorname{gr}_0(N)\otimes\operatorname{gr}(A)\to\operatorname{gr}_0(M)\otimes\operatorname{gr}(A)$ above $\operatorname{gr}(N)\to\operatorname{gr}(M)$, and uses flatness of the target $M$ to make the right vertical map bijective. This identifies the manuscript's specific missing comparison step and also explains why its visible correction from $B_i$ to $C_i$ matters; the author's tentative Chapter III location is still a historical claim, with no supplied register entry reviewing it.

## MPL_22+23_002-016#26 (same folder; 22: 11): A03 — unpursued implication; 22/011, Lemma 4.3 and Corollary 4.4

The lemma's map is exactly $m\otimes(p_i)_i\mapsto(m\otimes p_i)_i$, and the insertion “de type fini” on the two free modules is what makes the cokernel presentation commute with the product. The supplied context's `EGA_chap0_ega0-19.tex`, 0.19.1.13–15, similarly uses finite presentation to control Hom and local left inverses, while 0.19.2 develops the subsequent formally projective machinery; the present sheet adds a direct tensor-product argument. For the inverse map at the free stage, $A^n\otimes\prod_iP_i\simeq(\prod_iP_i)^n\simeq\prod_iP_i^n$, and passing to cokernels supplies the map asserted on the sheet, so this linkage rests on an explicit comparison rather than a terminological identification.

## MPL_22+23_002-016#27 (same folder; 22: 11): A04 — unproved claim; 22/011, Corollary 4.5, final paragraph

“On voit facilement” leaves the product decomposition of the countable strict system implicit. For the system on this page, chosen sections $s_n:P_n\to P_{n+1}$ of its surjective transition maps give the explicit coordinates $(x_n)_n\mapsto(x_0,(x_{n+1}-s_nx_n)_n)$, with inverse recursively defined by $x_{n+1}=s_nx_n+k_n$, thus identifying the limit with $P_0\times\prod_n\ker(P_{n+1}\to P_n)$; each kernel is a direct summand of the corresponding projective module. Context search finds the countable-limit discussion in `EGA_chap0_ega0-13.tex`, 0.13.2, and the countable topological comparison in `EGA_chap0_ega0-19.tex`, 0.19.1.8, but not this exact product formula; the note supplies the omitted map without claiming a new result.

## MPL_22+23_002-016#28 (same folder; 22: 12): A05 — reading question; 22/012, Theorem 4.6(ii), numbered conditions 1–4

The frozen text reads “$B$ est formellement simple,” “$B$ satisfait la condition P,” and “Les $B_i$ sont plats,” although these concern the already assumed $B$ and condition 4 concerns $u:B\to C$. The literal list is tested by $A=\mathbb Q[\epsilon]/(\epsilon^2)$, $I=(\epsilon)$, $B=A$, $C=\mathbb Q$, and $u$ the quotient: $u_0$ is the identity, the first three $B$-conditions hold, and $u$ kills the nonzero element $\epsilon$. The context comparison `EGA_chap0_ega0-19.tex`, 0.19.7.1.5, explicitly separates a formally smooth source from a flat target, so $C$ in some of the numbered conditions is a mathematical reading question suggested after freeze; no replacement has been made in the transcription.

## MPL_22+23_002-016#29 (same folder; 22: 13, 16-17): A06 — unpursued implication / terminology history; 22/013, Definition 4.7, and 22/017, Corollary 4.12

The draft calls its general complete, P, formally simple algebra an “algèbre ... de Cohen,” while `EGA_chap0_ega0-19.tex`, 0.19.8.1, applies that name to the complete flat local algebra whose closed fibre is a separable field. The concrete algebra $k[[t]]$ over $k$ appears within the draft's construction on 22/016, whereas its closed-fibre map $k[[t]]\otimes_k k\xrightarrow{\sim}k[[t]]$ leaves the nonunit $t$ and the nonzero ideal $(t)$ visible; the published-context definition's field-fibre case is exactly the additional $r(B)=r(A)B$ case singled out on 22/017. This exhibits how the draft's constructions map into the later arrangement and preserves the change of terminology without silently substituting the later definition.

## MPL_22+23_002-016#30 (same folder; 22: 14): A07 — unproved claim; 22/014, first half

The sentence about completed base change ends “c'est une trivialité,” without recording the hypotheses that keep the completed tensor product inside the intended noetherian/local class. `EGA_chap0_ega0-19.tex`, 0.19.7.1.2, supplies the actual comparison $E/\mathfrak m^hE\simeq(B/\mathfrak m^h)\otimes_A C$ and explicitly assumes a finite residue-field module plus completeness before deriving noetherianity and flatness of $E=B\widehat\otimes_A C$. The manuscript therefore offers a base-change instruction for its broader draft notion, while the context provides a precise case and the maps a verification must track; there is no matching reviewed register entry.

## MPL_22+23_002-016#32 (same folder; 22: 15): A09 — unproved claim / reading question; 22/015, central proof

“On constate aussitôt” suppresses the flatness step for the quotients by powers of the lifted regular parameters, and the source moves from the inserted label $I_n$ to $B/J_n$. `EGA_chap0_ega0-19.tex`, 0.19.7.1.1, spells out $\mathfrak J_m=\sum_i x_i^mB$, the cofinality of these ideals, and the regular-sequence input 0.15.1.16 and 0.15.1.20 before proving freeness over the artinian base. This is a close proof-level continuation of the manuscript's argument; $I_n/J_n$ remains a source notation question, with the concrete context quotient recorded only here.

## MPL_22+23_002-016#33 (same folder; 22: 15-16): A10 — withdrawn in the same text / self-flagged attribution; 22/015, cancelled bottom paragraph, continuing 22/016 top

The cancelled passage says “L'hypothèse faite est très probablement inutile” and attributes to Serre a report that Mac-Lane proved the converse without finite radicial multiplicity, asking the recipient to “regardes cela.” In `EGA_chap0_ega0-19.tex`, 0.19.6.1 and 0.19.7.1, the separability and flatness arguments are presented in the later formal-smoothness organization, while the passage's bibliographic report remains a struck drafting note. The manuscript supports a record of an expectation and a requested check, not a certification that its stated Mac-Lane reference proves every draft claim; the attribution has no matching reviewed RESULTS_STATE entry.

## MPL_22+23_002-016#34 (same folder; 22: 17-18): A11 — withdrawn in the same text; 22/017, middle paragraph, and 22/018, lower half

“Je me répens un peu de la définition 4.7.” leads to a proposed replacement of completeness for $B$'s own topology by completeness for the $IB$-adic topology, and the next page proposes retaining 4.13 and its existence/uniqueness content while reducing the surrounding terminology. `EGA_chap0_ega0-19.tex`, 0.19.7.1.5 and 0.19.7.3(i), make exactly the base-ideal completeness condition explicit in the uniqueness comparison $u:B\to B'$, and separately discuss the existence question under weakened completeness. These pages add the author's editorial reason for the reorganization and the specific definitions and claims that would have to be adjusted.

## MPL_22+23_002-016#35 (same folder; 22: 16-18): A12 — unpursued implication; 22/016–018, Corollaries 4.10–4.13

The draft's proof uses a finite free radicial base extension $A\to A'$ to obtain a separable residue extension, constructs a model, compares it with $B'$, and descends flatness. The later proof in `EGA_chap0_ega0-19.tex`, 0.19.7.1.3–6, retains the model-and-comparison mechanism through $B\otimes_A k\simeq B'\otimes_A k$ and the lifted isomorphism $B\simeq B'$, with a more general construction of the complete regular model. Thus the sheets document the route through the finite-radicial-multiplicity hypothesis and the subsequent effort to remove it; the context comparison gives exact maps and proof locations, not a new theorem attributed to this draft.

## codex:K22-01#1 (same folder; 22: 2-4): Steps the pages themselves mark as unverified

| Scan | Words or mark | What they refer to |
|---|---|---|
| 2 | « séries formelles ?? » | A pencil question beside Proposition 2, which asserts closedness of the singular locus for an affine algebra. The endings of the two words are faint. |
| 3 | « ce qui nous paraît être une lacune dans la démonstration donnée par Lang » | Jouanolou says the preceding separability assertion fills an apparent gap in the cited proof of Proposition 5. |
| 3 | « faux si on ne suppose pas A → B injectif ?? » | A slanting pencil objection to the lemma about a localization of a finite algebra. The middle of « suppose » is indistinct. |
| 4 | « C ⊃ A !!! », « faux » | The first is connected to the algebra C in the conclusion. The second has a line to the circled h₁ in the assertion that the two conditions are stable under localization. |
| 4 | « ? » | Beside the application of Proposition 7 to « localités analytiques », which is underlined. |
| 6 | « !? » | Beside the printed conclusion « B n’est pas ramifié sur A ». |
| 10 | « j’ai oublié d’introduire un système fondamental d’idéaux ouverts » | The writer calls attention to missing setup for the indexed quotients. The closure condition has its own interlinear addition. |
| 10 | « sauf erreur figure déjà en lemme quelque part au Chap III (j’espère, avec la généralité qui convient, et bien entendu modulé ...) » | The writer believes a lemma for the last implication already exists, and expresses uncertainty about its exact location and generality. |
| 13 | « On peut certainement améliorer la rédaction de la démonstration, évitant certaines redites » | A reservation about the exposition of the preceding proof. The subsequent suggestion to place the result in a lemma concerns the arrangement of the statements. |
| 14 | « dont nous ignorons s’il existe toujours une solution, faute de savoir caractériser la structure des algèbres de Cohen » | The general existence problem after reduction to a square-zero ideal. A particular case is announced immediately afterwards. |
| 15 | « il faudrait le préciser dans …7. » | The parenthesis about the usual topologies in the local criterion calls for a clarification of the definition. The leading section digit is overwritten. |
| 15 | « il y a un … corollaire dans la platitude supérieure » | A reference relied on in the proof about the quotients B/Jₙ. The typed word « lemme » has been crossed out. |
| 15 | « L’hypothèse faite est très probablement inutile » and « que tu regardes cela et donnes le résultat complet dans 2.3. » | In a cancelled NB, the writer asks a reader to check the removal of the radicial-multiplicity hypothesis and names Serre and Mac-Lane. |
| 16 | « réduction inutile dans le cas “…” du NB » | A lower-right note keyed to « séparable ». The quoted word identifying the case is unresolved. |

## work:K22-01#1 (same folder; 22: 2-16): What the pages do

**Scan 2, first offprint, Proposition 1.** For a regular equicharacteristic local ring with flat D(A) and a reduced quotient A/𝔞, the proposition relates regularity of the quotient to the vanishing of a first Tor group and to vanishing in all positive degrees. The A inside D(A) in the two Tor expressions carries a pen stroke referring to A/a in the margin. If D(A) is free, a fourth condition is freeness of D(A/𝔞).

**Scan 2, Corollaries 1–3.** The first corollary gives a freeness criterion for regularity of a reduced localization of a quotient of a convergent-series algebra in positive characteristic, with (k : kᵖ) finite. The second gives the criterion for a reduced « localité ». The third assumes analytic reducedness and finite type of the separated module D′(A), and uses its freeness.

**Scan 2, Propositions 2 and 3.** The note passes from regularity tests to the closedness of the singular locus. Proposition 2 concerns affine algebras over a regular equicharacteristic base with free D(A). Proposition 3 concerns schemes of finite type over a regular group scheme over a perfect field. The closing notation reserves L with subscript A for the residue field and K with subscript A for the fraction field of a domain.

**Scan 3, first lemma and sequence.** The kernel of the canonical map from the completed base change of D(A) to D(Â) lies in an intersection, taken over M for which D(A)/M is finite as an A-module. A decomposition called « semi-fini au sens de Suzuki » yields an exact sequence. The displayed middle term is printed simply (Â).

**Scan 3, Proposition 4 and its application.** For an analytically integral « localité », the fraction field of the completion is separable over the original fraction field. The following paragraph gives an analogous assertion for convergent series under the stated characteristic and finiteness assumptions.

**Scan 3, Proposition 5.** For A = k{T} over a complete algebraically closed valued field, the field K with subscript A is called « quasialgébriquement clos (C¹) ». The paragraph before the statement connects it with a difficulty in Lang's argument.

**Scan 3, Proposition 6.** A special case concerning series and rational function fields is combined with the structure theorem of Cohen. If a regular local ring contains k and its residue field is separable over k, the proposition concludes separability of its fraction field over k.

**Scans 3–4, reduction lemma and theorem.** A lemma treats a local domain obtained by localizing a finite A-algebra at a prime over the maximal ideal. The subsequent theorem gives analytic reducedness for the indicated integral localizations over a regular local A satisfying either a characteristic-zero condition on its fraction field or freeness of D(A). Pencil notes query injectivity in the lemma and the localization argument used for the theorem.

**Scan 4, two corollaries of the reduction theorem.** The first, attributed to Chevalley, treats integral localities. The second concerns integral localizations of quotients of a convergent-series algebra over a field with the stated condition (k : kᵖ) < +∞. The text invokes normalization lemmas.

**Scans 4–5, Proposition 7 and the end of the offprint.** A separability hypothesis on the completion of an analytically integral local ring is used to assert that the integral closure in a finite extension of its fraction field is a finite A-module. Applications to localities, analytic localities and regular Hopf algebras follow. The text then draws an analytic-normality conclusion and gives eleven references. Scan 5 contains the printer's imprint.

**Scan 6, second offprint, local notation and exact sequences.** A unit-preserving monomorphism A → B is accompanied by the relative module D with subscript A. The note introduces the residue fields, the ranks of the maximal ideals and the field invariant {L : K}. It writes two local exact sequences, one for separable residue extension and one with a denominator involving the intersection with A[Bᵖ].

**Scans 6–7, definition and local structure.** The note calls B « quasi-séparable » when $D_A(B)=0$. The property can be tested at maximal ideals. In the separable-residue case it implies relation (R) and a condition on the residue fields. Finite generation of the maximal ideal simplifies (R). In positive characteristic the note gives (S), again with a converse under finite generation of the module of differentials.

**Scan 7, global structure.** For a noetherian quasi-separable algebra over a field, the text gives product descriptions in characteristic zero and under extra residue-field hypotheses in positive characteristic. For a general quasi-separable algebra it discusses maximality of primes, algebraicity of the residue fields and absolute flatness of the quotient by the nilradical.

**Scan 7, theorem on free differentials.** In the local integral setting, with $D_A(B)$ finite and the stated field and rank invariants finite, freeness is equivalent to a dimension formula. There are separate denominators for the separable and other residue-field cases. The note then gives the formulas when A is a field and when B is unramified over A.

**Scan 8, first corollary.** For a locality over K whose residue and fraction fields are separable over K, freeness of D with subscript K is equivalent to regularity.

**Scan 8, Proposition 1 and its corollary.** The displayed equality compares the difference of the ranks of the maximal ideals with the difference of two field invariants. Together with the other hypotheses it gives a homological dimension at most one for $D_A(B)$. A corollary uses the preceding regular-local criterion. The L subscripts in the prose hypothesis and in the display appear in different orders.

**Scans 8–9, Proposition 2 and the separated quotient.** Freeness with the specified rank dim A + {Lₐ : K} implies regularity under the given noetherian and separability assumptions. The module D′ is formed by dividing by the intersection of all powers of the maximal ideal times the module. Proposition 2 is asserted again after that substitution. Six references close the article, followed on scan 9 by the imprint.

**Scan 10, comparison of topological algebras.** The fragment starts with closure assumptions and introduces the indexed quotients of B and C. It compares an isomorphism of topological algebras with bijectivity conditions on the modules and their associated graded objects, together with homeomorphism assertions on the zeroth quotients. Pencil ovals, arrows and a transposition change the arrangement of the conditions.

**Scan 10, argument and square.** Inverse limits account for the passage between a map and its quotient maps. Nilpotence on the quotient rings accounts for finite filtrations. The final flatness argument refers to a lemma the writer hopes is already available. A handwritten square has gr B and gr C across the top and graded objects tensored with B₀ and C₀ across the bottom. Two arrows are labelled surj and two bij.

**Scan 11, Lemma 4.3.** Tensoring the product P of a family Pᵢ with a finitely presented module M gives the product of the tensors. The written proof uses a presentation by finite free modules and exactness of products, reducing to M = Aⁿ.

**Scan 11, Corollary 4.4.** When finite-type modules over A are finitely presented, products of flat A-modules are flat. The proof tests a monomorphism between finite-type modules and invokes the preceding lemma.

**Scan 11, Corollary 4.5.** An inverse limit of a strict projective system of projective A-modules admitting a countable cofinal system is flat under the preceding assumption on A. The proof identifies the limit with a product of projective modules. Earlier formulations with extra finite-type and countability language are struck through.

**Scan 12, Theorem 4.6.** With a preadmissible base A, noetherian quotients Aᵢ and the revised hypotheses on B, the theorem first asserts formal simplicity. The added condition b) concerns B₀ over A₀. Given an isomorphism on zeroth quotients, the second part produces a continuous lift to C and lists equivalent conditions involving formal simplicity, P, flatness of indexed modules and topological isomorphism. The typewritten B's in the numbered conditions have been retained.

**Scans 12–13, proof of Theorem 4.6.** The proof cites earlier results for several implications, lifts the inverse of the residue-level map, and applies the comparison lemma with the two rings exchanged. A replacement sentence on scan 13 supplies the last implications involving condition 5). The writer then proposes simplifying the exposition by restricting to noetherian hypotheses.

**Scan 13, Definition 4.7.** For a continuous homomorphism of noetherian preadic rings, a topological Cohen algebra is specified by separated completeness, condition P and formal simplicity. The added wording expresses the last condition on the reduction modulo an ideal of definition.

**Scans 13–14, Corollary 4.8.** For a fixed residue algebra B₀ over A₀, an existing Cohen lift is unique up to an isomorphism compatible with the specified reductions. For an adic B with that reduction the conditions include being a Cohen algebra, formal simplicity, P, flatness, and flatness on every quotient by Iⁿ⁺¹. The opening of scan 14 continues the list from scan 13.

**Scan 14, flatness, base change and the existence question.** The equivalence of conditions 3) and 3 bis) is referred to « la platitude supérieure ». The next paragraph calls stability under base change by completed tensor products a triviality. The existence discussion reduces the problem to a discrete base with a square-zero ideal, records that the general problem is open for the writer, and announces a special case.

**Scans 14–15, cancelled theorem and replacement Corollary 4.9.** A hatched draft theorem includes residue fields k and K and a separability condition. The surviving end is « pour sa topolo- ». The replacement sets out a local criterion. With the usual topologies, being a Cohen algebra is compared with flatness over A, completeness and the Cohen property, or formal simplicity, of the closed fibre over k.

**Scan 15, proof of the local criterion.** The argument reduces to the Artinian base case, lifts a regular system of parameters of B₀, and considers ideals generated by the componentwise powers. It asserts flatness of the quotients B/Jₙ and then projectivity. Two pen passages and a longer typed NB carry cancellations. The NB discusses the radicial-multiplicity assumption and requests a check of a cited result.

**Scan 16, Corollary 4.10.** A separable residue extension K/k and a complete local Cohen k-algebra B₀ give existence and uniqueness up to isomorphism of a Cohen A-algebra lifting B₀. The argument writes B₀ as a power-series ring and separates B₀ = K from B₀ = k[[T₁,…,Tₙ]]. One case invokes a result of 0 with subscript III; the other gives the lift using Â.

**Scan 16, Corollary 4.11.** Under the local conditions cited as « 3.9. » and a handwritten finite radicial-multiplicity qualification, a further equivalent condition is completeness and formal simplicity over A. To obtain flatness the proof changes the base by a finite-type free local extension with a suitable radicial residue extension, uses the separable existence case upstairs, and concludes flatness downstairs. A marginal qualification is linked to the separability step.

## work:K22-01#2 (same folder; 22: 2-16): Statements left without proof

These are explicit assertions for which the scanned passage gives a statement, a reference or a brief deduction. The lemmas and corollaries whose arguments are actually written on scans 10–16 are described in the preceding section.

| Scans | Words identifying the assertion | What is supplied here |
|---|---|---|
| 2 | « Les assertions suivantes sont équivalentes » and « (d) … est libre » | Proposition 1 and its three corollaries are stated. The corollaries end with freeness or regularity tests. |
| 2 | « le lieu singulier … est fermé » and « En particulier » | Propositions 2–3 are stated, with the latter presented as an application. |
| 3 | « Le noyau … est contenu dans l’intersection » and « la suite canonique … est exacte » | The completion lemma is stated. The exact sequence is attributed to that lemma and semi-finiteness. |
| 3 | « est séparable sur », « est quasialgébriquement clos », « est aussi séparable sur » | Propositions 4–6 have explanations of their dependencies, with no detailed proof of the separability or C¹ assertion. |
| 3–4 | « peut être considéré comme classique », « On en déduit » and « stables par localisation » | A finite-algebra lemma and the reduction theorem are given. The localization assertion is questioned in pencil. |
| 4 | « De l’existence de lemmes de normalisation … on déduit » | The two corollaries are deductions by reference, including Chevalley's statement. |
| 4 | « la fermeture intégrale … est un A-module de type fini » and « D’après le lemme 2 » | Proposition 7 and its applications are stated. A numbered reference supports the final normality conclusion. |
| 6 | « deux suites exactes établies … par Berger et Kunz » | The sequences are taken from that work. Locality of quasi-separability is stated as « et seulement en ce cas ». |
| 6–7 | « la réciproque étant vraie » and « Globalement » | The local assertions (R), (S), their finite-generation qualifications, and both groups of global structure assertions are given without proofs here. |
| 7 | « il y a équivalence entre » and « De plus, l’égalité (ii) a s’écrit » | The freeness/dimension theorem and its two specializations are stated. |
| 8 | « il y a équivalence entre », « de dimension homologique finie », « A est local régulier » | The regularity corollary, the homological bound and its corollary, and Proposition 2 are stated. |
| 8 | « la proposition 2 est encore vraie, lorsqu’on y substitue » | The assertion about the separated module is appended without proof. |
| 10 | « ce qui est immédiat et sauf erreur figure déjà en lemme » | The last graded implication is accompanied by a square and an imprecise chapter reference. |
| 11 | « on voit facilement que … P est isomorphe à un produit » | This intermediate identification is invoked inside the proof of Corollary 4.5. |
| 12–13 | « grâce à 3.1. », « en vertu de 1.7. », « en vertu de 3.5. » | The invoked earlier results are not stated in full in this excerpt. The proof of the current theorem is present. |
| 14 | « contenue en effet … dans la platitude supérieure » and « c’est une trivialité » | The comparison with quotient-flatness and stability under completed base change are invoked without a separate proof. |
| 15–16 | « il y a un … corollaire dans la platitude supérieure », « on utilise le résultat général de 0 » | The results cited for the quotient modules and for the residue-field case of existence lie outside the excerpt. |

## work:K22-01#3 (same folder; 22: 2-16): Questions and conjectures

| Scan | Words on the sheet | Issue |
|---|---|---|
| 2 | « séries formelles ?? » | The pencil note queries the formal-series case beside the closed-singular-locus assertion. |
| 3 | « ce qui nous paraît être une lacune dans la démonstration donnée par Lang » | The writer of the offprint proposes to complete an argument. |
| 3–4 | « faux si on ne suppose pas A → B injectif ?? », « C ⊃ A !!! », « faux », « ? » | The pencil reader challenges a hypothesis in the local algebra lemma, the continuation into the theorem, stability under localization and an application to analytic localities. |
| 6 | « !? » | The pencil reader flags the interpretation of the final equality as unramifiedness. |
| 10 | « sauf erreur … quelque part au Chap III (j’espère, avec la généralité qui convient …) » | Uncertainty about the existence and precise scope of an earlier lemma. |
| 13 | « On peut certainement améliorer la rédaction », « plus raisonnable de réléguer … en lemme » | Suggestions about the proof and which assertion should be given theorem status. |
| 14 | « dont nous ignorons s’il existe toujours une solution » | Existence of a lift in the general square-zero case. This is a question on the sheet, with a subsequent positive result in a special case. |
| 15 | « il faudrait le préciser » and, in the cancelled NB, « L’hypothèse faite est très probablement inutile » | The first concerns the topologies. The second proposes eliminating a hypothesis and asks the reader to check it. |
| 16 | « réduction inutile dans le cas … du NB » | A marginal qualification on the base-change proof. The exact adjective is doubtful. |

## work:K22-01#4 (same folder; 22: 2-16): Slips

Confidence here concerns the proposed correction. Readings that rest on erased or overwritten ink are assigned low confidence.

| Scan and location | As transcribed → suggested form | Evidence and confidence |
|---|---|---|
| 2, Prop. 1 | « tel A/a soit réduit » → « tel que A/a soit réduit » | The printed line has no que between tel and the quotient. High. |
| 3, exact sequence | (Â) → D(Â) | The canonical map immediately above names D(Â) as its target. The display lacks the D. High. |
| 4, references 1, 6 | « Math., Z. » → « Math. Z. » and « Locals rings » → « Local rings » | The same journal reference on scan 8 has the shorter punctuation. An s is clearly printed on the English adjective. High for the comma, medium for the title as inferred from its wording. |
| 6, conclusion of (i) | O → 0 | The large oval contrasts with the short zero just to its right. The paragraph distinguishes characteristics zero and p > 0. High for the intended value. |
| 7, global assertion on primes | A g / g A g → A with subscript g, modulo g times that localization | The two g's following A stand at normal height. The statement calls this expression the residue field. Medium. |
| 8, Prop. 1 | Lₐ separable over Lᵦ → Lᵦ separable over Lₐ | The direction in the local setup and the immediately following formula favour the reversal. High. |
| 10, opening | TC → IC | The handwritten top note and a later typed repetition both use IC. High. |
| 11, Cor. 4.4 | « présentationfinie » → « présentation finie » | The word boundary can be compared with the same phrase in the lemma. High. |
| 12, opening and (ii) | « d e définition » → « de définition » and « d'alg̀èbres » → « d'algèbres » | The space within de and the extra grave over g are visible independently of the mathematics. High. |
| 12, (ii), conditions 1–3 | B, B, Bᵢ → possibly C, C, Cᵢ | C is the second algebra and an inverse map out of it is subsequently sought. Several conditions have been revised, and this intervention would change the statement. Low. |
| 13, opening and end of definition paragraph | « d'algébres » → « d'algèbres » and « réléguer » → « reléguer » | A close view shows the acute over e in algébres and the two acutes in réléguer. High. |
| 13, Cor. 4.8 | « soit isomorphisme à » → « soit isomorphe à » | The noun is typed and the earlier comparison uses isomorphe. The initial cell is overwritten. Low. |
| 15, proof | « élement » → « élément » | The e following l lacks the accent visible on the initial e. High. |
| 15, cancelled NB | « d'oeuil » → « d'œil » | The line has the extra u. It is part of a cancelled paragraph. Low. |
| 16, Cor. 4.11 | « Sous les conditions de 3.9. » → probably « 4.9. » | Several corresponding headings have a changed leading digit. This could also preserve an intentional reference to the older numbering. Low. |

## work:K22-01#5 (same folder; 22: 2-16): Pointers

| Scans | Words on the sheet | Referent given there |
|---|---|---|
| 2–4 | « Nakai, Suzuki et Mount », « Kunz », « Suzuki … Mount », « au sens de Suzuki » | Differential criteria and semi-finiteness. The first bibliography names Kunz, Mount, Nakai, Nakai et Suzuki, Suzuki, and Berger et Kunz. |
| 3 | « démonstration donnée par Lang », « théorème de structure de Cohen » | Lang's argument for the C¹ assertion and Cohen's structure theorem. The Lang reference on scan 4 is Ann. Math. 55 (1952), pp. 373–390. |
| 4 | « pour les séries convergentes, voir (5) », « (Chevalley) », « connu (Nagata) » | Normalization, the first reduction corollary and a pencilled attribution beside Proposition 7. Reference (5) is Mount. Nagata is listed under both an English book title and « On the closedness of singular loci ». |
| 4 | « lemme 2 (p. 314, chap. 8, § 13) de (11) » | Zariski et Samuel, Commutative Algebra. The bibliography also includes Godement's Séminaire Cartan-Chevalley. |
| 6–8 | « établies … par Berger et Kunz », « relativement parfait (2) », « absolument plat (3) », « cf. géométrie formelle » | The exact sequences, two references to Bourbaki and the closing application. Scan 8 also lists Godement, Nakai, and Nakai et Suzuki. René Garnier is named as presenter of each printed note, on scans 2 and 6. |
| 10 | « cf rectification à 0 » with 7.2.4. below it, « quelque part au Chap III », « Cf diagramme » | A rectification for inverse limits, a possible earlier lemma and the square at the foot of the sheet. |
| 11–13 | « le lemme 3 », « grâce à 3.1. », « en vertu de 1.7. », « en vertu de 3.5. », « Le lemme …2. (i) et (iii) » | Internal references in the flatness and lifting arguments. Several leading digits have been rewritten elsewhere. |
| 13–15 | « en vertu de 3.1. », « dès après 3.7. », « les résultats du Nº2 », « cf 2.… », « la platitude supérieure » | Internal references in the definition, base-change observation and local proof. The last digit in the handwritten cf reference is uncertain. |
| 15, cancelled NB | « Serre vient de me dire que Mac-Lane a prouvé la réciproque de 2.3. » | The writer names « Note on a relative structure of p-adic fields », Ann Math t.41, 1940, « page 751 -753 », and asks the addressee to check the result. |
| 16 | « théorème de structure …4. », « grâce au critère …9. 2) », « résultat général de 0 » with subscript III and interlinear « 10.3.1. » | References used to construct the lift in the two cases. The proof of the next corollary again cites 0 with subscript III, the existence theorem and the equivalence of 0) and 1). |

## work:K22-01#6 (same folder; 22: 2-16): Remarks of the model

**M1 · Model, high confidence.** The finite free case used in the proof of Lemma 4.3 on scan 11 checks directly for a fixed finite rank n. Both sides of its comparison map keep n coordinates for each member of the family. This check covers the reduction case M = Aⁿ.

**M2 · Model, high confidence.** The forward implication from flatness in 3) to the quotient-flatness in 3 bis) on scan 14 agrees with base change along A → A/Iⁿ⁺¹. The converse is the substantial direction referred to « la platitude supérieure ». Only the forward implication was checked here.

**M3 · Model, low confidence.** The pencil objection on scans 3–4 may connect the finite-algebra lemma's injectivity question with the later note « C ⊃ A !!! ». The two annotations concern compatible hypotheses. The pages contain no written counterexample and the verb in the first note is partly compressed.

**M4 · Model, low confidence.** The added fifth condition on scan 12 and the swapped B,C in the proof give a reason to consider a C-reading for the *intended* subject of some earlier conditions. The typed text says B. The revisions leave the intended final formulation unsettled.

**M5 · Model, low confidence.** On scan 15, proof line at « voisinages », the frozen reading is Iₙ with Jₙ as an alternative. The typed quotient on the next line uses Jₙ. The equality of the intended ideals is plausible, but the pen letter's pronounced crossbars make its spelling a reading question.

**M6 · Model, low confidence, reading question.** On scan 2, right margin beside Corollary 2 (page fragment L32), the frozen article in « contenu dans le critère jacobien » is le. On enlargement its first stroke makes a low loop. It could also read ce. Either article fits the phrase.

# H0D6: his open questions 1-4 on formally simple and Cohen algebras (cote 22, scans 14, 20-21)

- its entries on these pages: codex:K22-02#1, work:K22-02#1, work:K22-02#2, work:K22-02#3, work:K22-02#4, work:K22-02#5, work:K22-02#6, MPL_22+23_002-016#36, MPL_22+23_002-016#37, MPL_22+23_002-016#38, MPL_22+23_002-016#39, MPL_22+23_002-016#40
- in the archive: 3 entries; 22: 14,17-30,20,21

## MPL_22+23_002-016#31 (same folder; 22: 14): A08 — conjecture / self-flagged open problem; 22/014, middle paragraph

After reducing to $I^2=0$, the author writes “nous ignorons s'il existe toujours une solution” to lifting a prescribed Cohen algebra $B_0$. The complete-local lifting problem is treated in the supplied `EGA_chap0_ega0-19.tex`, 0.19.7.2, by an explicit $A_0$-isomorphism $B\otimes_A A_0\xrightarrow{\sim}B_0$, while 0.19.7.3(i) retains a further question about weakening completeness to the base-ideal topology. The sheet adds an earlier formulation of that obstruction problem, and the completed case and the weakened-completeness question must be compared through those two different completion maps rather than assigned one undifferentiated “open” status.

# H0D7: derivations, p-bases and infinite support (cote 22, scans 22-25)

- its entries on these pages: codex:K22-02#1, work:K22-02#1, work:K22-02#2, work:K22-02#3, work:K22-02#4, work:K22-02#5, work:K22-02#6, MPL_22+23_002-016#41, MPL_22+23_002-016#42, MPL_22+23_002-016#43, MPL_22+23_002-016#47, MPL_22+23_002-016#44, MPL_22+23_002-016#45, MPL_22+23_002-016#52, MPL_22+23_002-016#46
- in the archive: 3 entries; 22: 17-30,22,23,24,24-25,25

# H0D9: the counterexample on 22/027-029 and EGA 0_IV 22.5.10(i)

- its entries on these pages: codex:K22-02#1, work:K22-02#1, work:K22-02#2, work:K22-02#3, work:K22-02#4, work:K22-02#5, work:K22-02#6, MPL_22+23_002-016#48, MPL_22+23_002-016#49, MPL_22+23_002-016#50, MPL_22+23_002-016#53, MPL_22+23_002-016#51
- in the archive: 3 entries; 22: 17-30,27,27-29,29

# H0D4: trace and norm for finite morphisms; separated quotient; divisor/idele compatibility (reused typescripts, cote 22)

- its entries on these pages: MPL_22+23_002-016#19, MPL_22+23_002-016#20, MPL_22+23_002-016#21
- in the archive: 3 entries; 22: 2-4,2-16

## MPL_22+23_002-016#18 (same folder; 22: 8): O12. The separated quotient as an explicit morphism

**Kind: unpursued implication / unproved claim. Location: 22/008, concluding paragraph, “il vaut mieux séparer.”** The printed construction is the quotient map \(q:D_A(B)\to D'_A(B)=D_A(B)/\bigcap_n\mathfrak n^nD_A(B)\); the map \(x\mapsto(x\bmod\mathfrak n^nD_A(B))_n\) into \(\varprojlim_nD_A(B)/\mathfrak n^nD_A(B)\) has precisely that intersection as kernel, hence induces an injection of \(D'_A(B)\) into the inverse limit. This explicit factorisation is the comparison with the completed differential module in the context, and the offprint's final assertion that Proposition 2 survives substitution of \(D'_K(A)\) still needs its own rank/regularity argument. **Context / state:** `EGA_chap0_ega0-20.tex`, 20.7.14–20.7.16; `EGA_chap0_ega0-21.tex`, 21.9; no matching settled register entry.

## MPL_22+23_002-016#23 (same folder; 22: 7): O17. A context-specified link to the planned intersection chapter

**Kind: unpursued implication. Location: 22/007, lower rank identities, compared with context 0.21.7.5.** The rank expression \(\{K_b:K_a\}-\{L_b:L_a\}\) in the offprint is a concrete comparison point for the context's differential/imperfection dimension calculations. In `EGA_chap0_ega0-21.tex`, 21.7.5 explicitly identifies the first member of (21.7.1.1) with the Euler–Poincaré characteristic of \(K_\bullet(C/B/A)\) for \(C=L,B=K,A=P\), then announces generalized characteristics of complexes in the chapter on intersections and Riemann–Roch; the exact complexes and field maps must be compared before equating a particular offprint rank formula with that characteristic. **Context / state:** `EGA_chap0_ega0-21.tex`, 21.7.1 and 21.7.5; EGA I introduction p. 6, chapter XI; **WG2 §2.1 #2** remains an unchecked planning item, with no settled comparison claimed.
