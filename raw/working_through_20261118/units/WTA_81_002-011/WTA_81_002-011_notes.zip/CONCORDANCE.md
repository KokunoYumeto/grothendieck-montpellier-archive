# The concordance of WT_81_002-011

For every object (the sweep's tag) that the notes on these pages are about, the entries on the same object elsewhere in the archive, nearest first (the same folder, then the same topic, then other topics), with their text.

# H01B: immersions of the disc and of the circle (cote 81)

- its entries on these pages: codex:J81-01#2, codex:J81-01#1, codex:J81-02#2
- in the archive: 12 entries; 81

## codex:J81-02#1 (same folder; 81: 12-18): Steps marked as unverified

| Scan | Place | Manuscript words or signs |
|---|---|---|
| 11 | upper central display | ? above ≃ in P(X × Z) ≃ Hom(…) |

Scans 12–18: none.

## codex:J81-04#1 (same folder; 81: 30): Steps marked as unverified

- **030**, lower paragraph. “Le cas où certains des ensembles $U_s,E_a$ pourraient être vides est à examiner avec plus de soin”. The wording singles out the case of empty sets for further examination.

## codex:J81-04#2 (same folder; 81: 27-30, 32-33): Title sheets, dates and page counts

- Scan 32 carries the slanted “Version II”, the heading “Décompositions n-aires d'un espace topologique” and the opening “1.1.”. Scan 33 carries “1.2.” above “Deux décompositions binaires”.
- Dates, authorial page numerals, separate title sheets and total page counts on these seven scans: none. The faint lower-corner numerals on scans 27–30 and 32–34 are 26–29 and 31–33, respectively.

## codex:J81-05#1 (same folder; 81: 37, 39): Steps the pages themselves mark as unverified

- **Scan 37.** “Il reste à voir que l’on n’a pas une inclusion Σ₁⁻ ⊂ Σ₂⁻ ou inclusion inverse”. The writer then invokes “le diagramme (14)” and ends “ce que l’on a exclu”.
- **Scan 39.** “il faut vérifier la transitivité de cette relation — c’est immédiat”, in the slanted note beside (26).

## codex:J81-05#2 (same folder; 81: 35-41): Title sheets, dates and page counts

- **Scan 41.** The upper-right title is in two lines, “relations d'equiv. / non panachées”. The i in relations, the abbreviation and the final ending are uncertain. Other title sheets in scans 35–40: none. Dates, stated page counts or typescript pagination in scans 35–41: none.

## codex:J81-06#1 (same folder; 81: 45, 47-48): Steps marked as unverified

- Scan 45. “Intuition” introduces the proposed correspondence from an “ens. bicircularisé avec partition non panachée” to one with a “partition … de degré 2”. The heading “Structure à étudier” introduces this question.
- Scan 47. The slanted word “faux” stands beside “Montrons dans ce cas … Σ est … connu …”. It marks the reconstruction claim at the foot of the page.
- Scan 48. The NB says “il n’est pas vrai que la connaissance de Σ̂* redonne Σ, exemple”. It is followed by the three-chord drawing. Four diagonal strokes cancel the attempted statement at the foot.

## codex:J81-06#2 (same folder; 81: 42-48): Title sheets, dates and page counts

Title sheets, written dates and page counts on scans 42–48: none. The pencil numerals 41–47 are archive sheet numbers.

- Scan 45. The working sheet has the underlined headings “Structure à étudier” and “Intuition”.

## codex:J81-07#1 (same folder; 81: 52): Steps marked as unverified

- Scan 52. A possible handwritten question mark precedes « les deux extrémités » in « ceux qui contiennent ? les deux extrémités ». Its punctuation is uncertain.

## codex:J81-07#2 (same folder; 81: 49-55): Title sheets, dates and page counts

- Scan 49. The underlined opening heading reads « Segments R saturés », with R added above the line.
- Scan 52. The internal heading reads « Partitions non panachées de I ».
- Scans 49–55. Title sheets, dates, stated page counts and authorial page numbers: none. The small pencil numbers at the lower left run from 48 on scan 49 to 54 on scan 55. Each is recorded in its page file as an archive sheet number.
