# The nodes of WT_81_002-011

- `NOTES_ON_THESE_PAGES.md`, `NOTES_INDEX.tsv`: the 3 entries that cite these pages (0 from Pro's notes, 0 from Work's math notes, 3 from Codex's notes); `files/`: the whole files they come from.
- `CONCORDANCE.tsv`, `CONCORDANCE.md`: 9 entries on the same objects elsewhere.
- `OBJECTS.tsv`: the sweep's global rows of these 1 objects (their tags are the handbook's draft tags); `THEMES.tsv`, their themes; `LINKS.tsv`, the sweep's links among them.
- `CHECKS.tsv`: 0 rows of the check register (results_register/CHECK_REGISTER.tsv) about these entries, items and objects: who checked what, how, with what result.
