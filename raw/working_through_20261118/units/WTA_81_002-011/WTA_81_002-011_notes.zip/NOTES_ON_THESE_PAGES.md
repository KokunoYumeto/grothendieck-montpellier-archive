# The notes on WT_81_002-011

Every note entry that cites a page of this range, in page order, in full as it stands in its file, with the placement of horizontal sweep 1 (Claude Opus 5.5 at effort max, 18 Nov 2026): the object, its item and the object's tag.

## codex:J81-01#2: Title sheets, dates and page counts

- written by: GPT-6 Astra at reasoning effort max (Codex web), notes of the folder J81-01
- file: `files/J81-01_notes.md`, line 10
- pages: 81: 2-3
- kind: Codex stage-A notes unit: Title sheets, dates and page counts
- the sweep's object: immersions of the disc and of the circle (cote 81) (title sheets, dates and page counts) (item SA01-29, tag H01B; basis index-row; fidelity not checked)

- **Scan 2.** “0 Cartes sphériques en général” is the sole title on the sheet. The first sign can also be read O. The pencilled archive numeral is 1.
- **Scan 3.** The opening heading reads “Carte sphérique (orientée) avec repère (dans cat. isotopique)”. The parenthetic insertion and ending of the last word are uncertain.
- **Dates and authorial page counts.** None. The small archive sheet numerals on scans 2, 3, 4, 5, 6, 7, 8 and 10 read 1, 2, 3, 4, 5, 6, 7 and 9 respectively.

## codex:J81-01#1: Steps marked as unverified

- written by: GPT-6 Astra at reasoning effort max (Codex web), notes of the folder J81-01
- file: `files/J81-01_notes.md`, line 3
- pages: 81: 3, 8, 10
- kind: Codex stage-A notes unit: Steps marked as unverified
- the sweep's object: immersions of the disc and of the circle (cote 81) (steps marked as unverified) (item SA01-29, tag H01B; basis index-row; fidelity not checked)

- **Scan 3.** The question begins “Mais peut-on avoir P′(z)=0” and ends “sans avoir P(z)=Q(z) ?”. Between them the hand gives Q′(z)=0 and inserts “avec P′(z)=Q′(z)”. The paragraph beginning “Prenons p.ex.” takes up the question.
- **Scan 8.** The writer places a question mark after each coprimality expression, first for b₀ and b″ (“alors … ?”), then for a₀ and a″. The relation on the paper is a shallow bowl above a small 1.
- **Scan 8.** “Je suppose désormais que ζ=0” introduces an assumption. The letter read ζ also admits δ. The ruled line begins “Je fais l’hypothése suivante” and gives “si q premier et 1≤i<q alors q | C_q^i” (q below C and i above it). The final line qualifies the result with “sous réserve que l’hypothése est vraie”.
- **Scan 10.** A single heavy “?” stands above the overdrawn disk in the middle group of the lowest row. Five other disks carry “OK”. There is no accompanying assertion in words.

## codex:J81-02#2: Title sheets, dates and page counts

- written by: GPT-6 Astra at reasoning effort max (Codex web), notes of the folder J81-02
- file: `files/J81-02_notes.md`, line 11
- pages: 81: 11
- kind: Codex stage-A notes unit: Title sheets, dates and page counts
- the sweep's object: immersions of the disc and of the circle (cote 81) (title sheets, dates and page counts) (item SA01-29, tag H01B; basis index-row; fidelity not checked)

| Scan | Place | Manuscript entry |
|---|---|---|
| 13 | six-column title list | Notes 1, 5, 7, 15, 20, 23. No page counts are identified as such. Two question marks at left accompany arrows in the table. |
| 13 | Notes 1 | A (1976/77), also cancelled above. Découverte de la Méditation[?]. (i) Envol. M 1976 *. |
| 13 | Notes 5 | B (1978/79). Réveil en Cascades. (ii) Vers un plus long Voyage. M 1979. |
| 13 | Notes 7 | C (1979/80). Die Eltern (Les parents). (i) Bild und Wahrheit (Image et Réalité). HS I. |
| 13 | Notes 15 | D (1980). Das Kind (L'enfant). (i) Der Wolf (Le Loup). Sch I. |
| 13 | Notes 20 | E (1981). Der Baumeister (Le Bâtisseur). (i) Spiel- und Sucht (Jeu - et Fringale). Sch VI. |
| 13 | Notes 23 | E (1981). Le Bâtisseur. (iv) Le “Maître”. Sch IX. |
| 14 | upper right | décompositions ⟨et découpages⟩ n-aires d'espaces topologiques. No date or page count. |
| 15 | top-left underlined heading | Version I [?]. No date or page count. |
| 15 | centre, underlined case heading | Cas Card (I) = 2, with overwritten signs. |
| 17 | underlined section heading | Cas particuliers |
| 18 | underlined lemma heading | Lemme |

Title or dated entries on scans 11, 12 and 16: none. Explicit page counts in this sequence: none.
