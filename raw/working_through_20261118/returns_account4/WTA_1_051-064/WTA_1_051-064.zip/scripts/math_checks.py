import numpy as np

# Scan 56: positive diagonal operator with singular values rho_i.
rho = np.array([3.0, 2.0, 0.5])
A = np.diag(rho**2)             # uu* on the singular-vector basis
sqrt_A = np.diag(np.sqrt(np.diag(A)))
assert np.allclose(np.diag(sqrt_A), rho)
assert not np.allclose(np.diag(sqrt_A), rho**2)

# Hadamard equality on a diagonal matrix, and strict inequality on a non-orthogonal pair.
M = np.array([[3.0, 0.0], [0.0, 4.0]])
assert abs(np.linalg.det(M)) == 12.0
assert abs(np.linalg.det(M)) <= np.linalg.norm(M[:,0]) * np.linalg.norm(M[:,1])

# Orthogonal rank-one projections show why a sum of pth powers is not
# bounded by the pth power of the sum when 0<p<1 (a common false variant).
p = 0.5
lhs = 1.0**p + 1.0**p
rhs = (1.0 + 0.0)**p + (0.0 + 1.0)**p
assert lhs == rhs == 2.0
print("sqrt(diag(rho_i^2)) coefficients:", np.diag(sqrt_A).tolist())
print("Hadamard test: determinant 12 <= product of column norms 12")
print("orthogonal rank-one projection test, p=1/2:", lhs, "<=", rhs, "holds with equality")
