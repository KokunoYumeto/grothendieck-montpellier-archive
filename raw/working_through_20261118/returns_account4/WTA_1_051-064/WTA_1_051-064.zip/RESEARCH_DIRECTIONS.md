INCOMPLETE

# Research directions and unresolved checks

1. **Scan 58: exact converse characterization of Hilbert–Schmidt maps.** Source: Corollary 1, scan 58, together with the closed-graph argument. The trace-duality direction is standard, but the precise quantified condition and the two topologies in the manuscript have not been matched against the preceding chapter's definitions. State reached: the sufficient direction follows from the Hilbert–Schmidt/trace-class product inequality; the converse proof in the page uses the closed graph theorem and a representing vector. Next: retrieve the preceding section's definitions of \(L^1(E)\), its operator-induced topology, and the precise quantifier on \(v\), then independently verify closedness and continuity.

2. **Scan 51: locally compact measure hypotheses.** Source: Theorem 1 and Corollary 2. The algebraic isometry and density argument are standard, but the exact measure regularity and completion convention are not stated on the selected page. Next: inspect the preceding pages and the archive's measure-space conventions.

3. **Scan 64: coefficient \(k_n\).** Source: Corollary 1, scan 64. The determinant inequality proves the needed Hilbert-space bound, but \(k_n\)'s definition is in Chap. 1, § 2, N° 2, Proposition 1, outside the attachments. Next: retrieve that exact definition and verify equality, including its normalization.

4. **Scan 64: continuation of the special case.** Source: final line “En particulier, si \(u_i\) est un”. This is not a claim completed in this range. Next: compare scan 65 in the next range; do not complete the sentence from conjecture.

5. **Editorially unassigned marks.** Sources: scan 54 question mark; scan 55 pale “?”/“!” and “Non !”. No claim is securely attached to these marks. Next: inspect surrounding manuscript context and later revisions before assigning mathematical scope.

No external literature was consulted or cited in this pass. No literature claim is marked verified.
