INCOMPLETE

1. Discrete formal simplicity in the finite-differential case. Source: scans 22–23 and notes A14/A18/A19. Current result: scan 24–25 proves failure when dim_K Ω¹_{K/k}=∞. Next: settle the finite-dimensional case, including finite p-basis in characteristic p and the exact characteristic-zero example; match the definition in EGA 0_IV 19.2.1 and 20.4.9.

2. Universal regularity versus formal simplicity (question 1). Source: scan 20 and note A13. Current result: no complete proof in this session. Next: identify the exact EGA 0_IV 22.5.8 statement, match hypotheses, then prove the local-homomorphism reformulation without enlarging scope.

3. Openness questions. Source: scans 20–21, notes A15–A17. Current result: exact statements still need reconstruction from the handwritten abbreviations and margins. Next: settle localization stability first; then compare the fibrewise locus with Nagata's criterion and the characteristic-zero resolution argument; separately settle openness of the flat locus.

4. General-p differential-kernel counterexample. Source: scans 27 and 29, notes A25–A30. Current result: p=2 specialization proved in PROOFS.tex §2. Next: prove the author's general construction for arbitrary prime p and arbitrary perfect F, calculate the full kernel, and audit the alternate separable-coefficient construction.

5. EGA 0_IV 22.5.10(i) discrepancy. Source: scan 27–29, note A27. Current result: a prior note alleges the printed example is purely transcendental and its claimed nonzero differential kernel vanishes; this session did not independently complete that comparison. Next: open the exact EGA edition and DOI page, recompute the field presentation and map, check errata and later citations, and distinguish source text from any proposed correction.

6. Divisors and idèles. Source: scans 28 and 30, notes O13–O16. Current result: scan-level check confirms the formulae's visible indices, including P|P′ in (38); W's unprimed P is a transcription error. Next: recover formulas (12), (13), (29), (30), all definitions of places/degrees/repartitions/idèles, and prove (31)–(45) including restrictedness, transitivity and the product formula.

7. Documentary EGA-plan and catalogue notes. Source: notes P02–P07 and object H0DH/H0DY. Current result: not audited against all source sheets or external chapter lists. Next: verify every title, date, page sequence, chapter assignment and cross-cote link from the actual title sheets; do not infer missing chapter permutations from cardinalities.
