# Reproducibility note: this session's two completed proofs are written out in PROOFS.tex.
# The field example in §2 was checked by the explicit basis calculations recorded there.
# No OCR was run. Whole-page images and selected full-resolution strips were inspected manually.
# The results archive was deliberately not opened because the check was incomplete.
