INCOMPLETE

# Research directions

## RD-1 — Special rational functions and their critical values
- **Origin:** scan 3, unit 81:2; note `codex:J81-01#1`.
- **Question:** classify or establish existence of rational functions satisfying the manuscript’s normalisations and critical-point conditions, including the exceptional simultaneous-zero case \(P'=Q'=0\).
- **Done:** checked the elementary exceptional case with \(Q=1\), \(P=2T^2-T\), \(z=1/4\). This shows the implication \(f'(z)=0\Rightarrow P(z)=Q(z)\) cannot be justified solely by the displayed factorisation when \(P'(z)=0\).
- **State:** open. No external literature was consulted or cited.
- **Next:** recover the exact definition of “spécial” and surrounding construction from the adjacent pages; then formulate the global critical-value problem with multiplicities and prove or refute existence.

## RD-2 — Cancelled \(e_i,f_i,\delta\) calculation
- **Origin:** scans 4–6, unit 81:4.
- **Question:** whether the displayed algebra forces \(eta=0,lpha=\pm1\), and what the determinant calculation contributes.
- **Done:** independently checked only the standard quotient second-derivative identity. The algebraic derivation cannot be reconstructed without the preceding definitions and product rules.
- **State:** open.
- **Next:** inspect the preceding pages of cote 81 and reconstruct the graded algebra, differential, signs and index ranges before checking associativity and each displayed equality.

## RD-3 — Prime-exponent equation
- **Origin:** scans 7–8, unit 81:7.
- **Question:** the page’s attempted argument under \(a^q+b^q=c^q\), \(q\) prime, and pairwise coprimality.
- **Done:** verified \(b'\mid b^q\). For any prime \(p\ne q\) dividing \(b'\), \(p\nmid a\), and the p-adic valuation of the binomial sum gives \(v_p(b')=qv_p(b)\). Thus \(b'=q^\gamma b_0^q\) with \(q\nmid b_0\), provided the valuation argument is applied to all non-q prime factors. The q-adic valuation is exceptional. The binomial divisibility \(q\mid {q\choose i}\) for \(1\le i<q\) is elementary.
- **State:** open; the argument does not prove the target equation impossible.
- **Next:** isolate the exact q-adic cases and test whether the later relation between \(a',b'\) and the exponents is valid. Do not assume a contradiction from the displayed reductions.

## RD-4 — Disk/chord configurations
- **Origin:** scan 10, unit 81:10.
- **Question:** the unresolved configuration marked “?” among the disk/chord tests.
- **Done:** visual mark located; no definitions available in this range.
- **State:** open/not formally checkable.
- **Next:** recover the definitions and earlier pages that specify the equivalence or admissibility criterion for the drawings.

## RD-5 — Power objects and Hom
- **Origin:** scan 11, unit 81:11.
- **Question:** whether the displayed P/Hom correspondences and diagrams define valid equivalences/inclusions.
- **Done:** identified a question mark above the proposed equivalence and multiple deleted alternatives.
- **State:** open/not formally checkable.
- **Next:** identify the ambient category, power-object functor, exponential objects and all source/target objects from the surrounding folder.
