#!/usr/bin/env python3
"""Reproduce the explicit scan-3 example and the quotient derivative identity."""
import sympy as s
T,z=s.symbols('T z')
P=2*T**2-T
Q=s.Integer(1)
z0=s.Rational(1,4)
assert P.subs(T,0)==0
assert P.subs(T,1)==1
assert s.diff(P,T).subs(T,z0)==0
assert s.diff(Q,T).subs(T,z0)==0
assert P.subs(T,z0)==s.Rational(-1,8)
assert P.subs(T,z0)!=Q
print("scan3: P(0)=0, P(1)=Q(1)=1, deg(Q)<deg(P)")
print("scan3: P'(1/4)=Q'(1/4)=0; P(1/4)=-1/8 != 1=Q(1/4)")
# Symbolic quotient derivative check
p,q=s.symbols('p q', cls=s.Function)
x=s.symbols('x')
expr=s.diff(p(x)/q(x),x,2)
target=(s.diff(p(x),x,2)*q(x)**2-p(x)*q(x)*s.diff(q(x),x,2)
        -2*s.diff(p(x),x)*q(x)*s.diff(q(x),x)
        +2*p(x)*s.diff(q(x),x)**2)/q(x)**3
assert s.simplify(expr-target)==0
print("quotient second derivative: symbolic identity verified")
