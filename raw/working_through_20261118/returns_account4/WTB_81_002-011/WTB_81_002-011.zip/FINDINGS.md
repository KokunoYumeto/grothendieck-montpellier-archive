# Findings — cote 81, scans 2–11

## Unit 81:2 — « 0 Cartes sphériques en général » / carte sphérique orientée

Scan 2 is a sparse title sheet. Scan 3 sets up a rational function \(f=P/Q\) with coprime numerator and denominator, the normalisations \(P(0)=0\), \(P(1)=Q(1)
e0\), and \(\deg Q<\deg P\), followed by a “special” critical-point condition. The page asks whether simultaneous vanishing of \(P'\) and \(Q'\) can occur without \(P=Q\). With \(Q=1\), \(P(T)=2T^2-T\), and \(z=1/4\), one has \(P'(z)=Q'(z)=0\), \(P(z)=-1/8
e1=Q(z)\), so the exceptional case genuinely occurs. The transcription’s visible insertion “avec \(P'(z)=Q'(z)\)” is retained. The broader existence/classification question is not settled.

## Unit 81:4 — algebraic calculations with \(e_i,f_i,\delta\)

Scans 4–6 contain a heavily cancelled algebraic calculation, including a proposed coefficient conclusion \(eta=0,lpha=\pm1\), followed by quotient-derivative calculations and another cancelled calculation involving a determinant and \(\delta\). The multiplication rules and ambient algebraic hypotheses are not supplied in this range, so the coefficient conclusion cannot be checked. The standard second derivative of \(P/Q\) is verified independently, but the overwritten manuscript line on scan 6 still needs crop-level adjudication before assigning each visible term to live or deleted writing.

## Unit 81:7 — number-theoretic argument for a prime exponent

Scans 7–8 assume positive pairwise-coprime integers \(a,b,c\), a prime \(q\), and \(a^q+b^q=c^q\). Writing \(c=a+b'=b+a'\), the page derives \(b'\mid b^q\), then examines the valuations of primes dividing \(b'\). For every prime \(p
e q\) dividing \(b'\), the valuation argument gives \(v_p(b')=qv_p(b)\), hence the non-\(q\) part of \(b'\) is a q-th power. The exceptional prime \(p=q\) is not controlled by that argument. The page then uses a symmetric decomposition and an additional hypothesis on binomial coefficients, which is true for prime \(q\), but the remaining argument does not establish a contradiction. This is not a proof of Fermat’s Last Theorem.

## Unit 81:9 — blank sheet

No legible manuscript content is visible on scan 9. A page file records the archive sheet number only.

## Unit 81:10 — geometric configurations

Scan 10 consists of disk/chord drawings with “OK” labels and one prominent question mark. The note identifying the unresolved lower-middle drawing is confirmed. No definitions or proposition accompany the drawings in this range, so no mathematical verdict beyond the visual status marks is justified.

## Unit 81:11 — power objects and Hom expressions

Scan 11 contains expressions involving \(P(X)\), \(P(X\times Z)\), \(\operatorname{Hom}\), underlined Hom, diagrams and deleted alternatives. A question mark is visibly placed above an equivalence sign. Since the category, objects and notation are not defined here, the equivalence cannot be checked.

## Notes

The two J81-01 entries are anchored to the range and receive verdicts in `NOTES_VERDICTS.tsv`. The J81-02 entry listed as `codex:J81-02#2` describes scans 13–18, outside this range; its page anchor is inconsistent and its contents are not imported.
