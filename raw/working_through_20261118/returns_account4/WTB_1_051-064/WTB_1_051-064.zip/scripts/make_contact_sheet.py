from PIL import Image, ImageDraw
from pathlib import Path
out = Path('work_wtb')
sheet = Image.new('RGB', (1440, 2120), 'white')
draw = ImageDraw.Draw(sheet)
for i, n in enumerate(range(51, 65)):
    im = Image.open(out / f'1_scan{n:03d}.jpg').convert('RGB')
    im.thumbnail((360, 500))
    x, y = (i % 4) * 360, (i // 4) * 530
    sheet.paste(im, (x, y + 25))
    draw.text((x + 5, y + 5), f'Scan {n}', fill='black')
sheet.save('contact.jpg')
