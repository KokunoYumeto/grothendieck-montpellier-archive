No mathematical computation scripts were needed: all finite-dimensional checks and inequalities were established directly in PROOFS.tex. The scalar counterexample for C13 is u=[2], computed by hand.
