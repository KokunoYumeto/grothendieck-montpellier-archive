INCOMPLETE

# Research directions and remaining questions

1. **Scan 64, formula (8): resolve the overwritten scalar and formula label.** Source: work:K1-01#4 (S5) and work:K1-01#6 (R4), scan 64 lines 10–17. Both transcription witnesses disagree or express uncertainty. The displayed norm calculation proves (9) without relying on the scalar, but does not identify the ink. State reached: undecided; the high-resolution whole page and crop were inspected, but the overwritten coefficient remains indistinguishable. Approaches tried: comparison of C and H; inspection of the full scan and enlarged crop; dimensional normalization using the following maps. The normalization alone cannot determine what was written. Next step: obtain a higher-quality archive scan or inspect the physical sheet under raking light.

2. **Earlier-chapter references.** Source: work:K1-01#5. The manuscript points to Chapter 1, §1 and §2, and to N° 1 formulae (8), (17), (22), (25). The supplied context contains the current folder transcription, not those earlier pages. State reached: not checkable from this upload. The standard results used here have been independently proved in `PROOFS.tex`; the exact historical cross-reference locators remain unchecked. Next step: obtain the corresponding earlier chapter pages and verify each locator against the original.

3. **Scope of the pencil marks on scans 54–55.** Source: codex:K1-01#1 and work:K1-01#3. The mark on scan 54 is below a sum; the isolated scan 55 mark may be ? or !, and the separate “Non !” does not name the rejected step. State reached: undecided attribution, not a mathematical conjecture. Next step: inspect the original sheet at higher resolution or in person; do not infer an intended target from the mathematical context.
