# Findings

## Unit 1: scan 51 — vector-valued square-integrable functions
The page closes the identification of the Hilbert tensor product with the vector-valued L² space and gives the sequence-family and product-measure corollaries. The canonical maps are isometries on elementary tensors; density of simple functions and measurable rectangles gives surjectivity (C01). The preceding argument for the first theorem begins before this scan and is not reconstructed as Grothendieck's own text.

## Unit 2: scans 51–53 — tensors to operators
The manuscript sends a rank-one tensor to a rank-one operator, proves the operator norm bound, and identifies the completion with Hilbert–Schmidt operators. Matrix coefficients prove injectivity and the square-summable matrix criterion (C02). No mathematical defect was found in the claims.

## Unit 3: scans 53–55 — composition, adjoints and singular values
The two-sided ideal estimates and adjoint invariance follow from orthonormal-basis sums. Polar decomposition reduces the Hilbert–Schmidt criterion to the compact positive spectral theorem (C03). The scan 54 formula is $h=Vu$; the first transcription C reads $U$ in that occurrence and is corrected (C14).

## Unit 4: scans 55–56 — Fredholm class
The manuscript's Fredholm class is the trace-class class. The trace norm is the sum of singular values, and the rank-one singular-value expansion follows from the spectral theorem and polar decomposition (C04). The claim that the two positive moduli have “the same eigenvalues” must be restricted to nonzero eigenvalues when the source and target dimensions differ (C05). On scan 56 the ink really does give $ho_i^2$ in the displayed square-root expansion; this is an authorial mathematical slip, not a transcription error. The correct coefficient is $ho_i$ (C13).

## Unit 5: scans 56–57 — trace of a product
The product of two Hilbert–Schmidt operators is trace class with the stated norm bound. The trace pairing gives the Hilbert–Schmidt inner product, and finite-rank trace cyclicity extends by continuity (C06). The target in the proof is $L^1(E,G)$; the page's formula reference and finite-rank argument concern (24).

## Unit 6: scan 58 — converse criteria
The trace duality formula characterizes the Hilbert–Schmidt norm. The converse criterion uses the closed graph theorem on the map $v\mapsto vu$ and Riesz representation in the Hilbert–Schmidt space (C07). The factorization of a trace-class operator into two Hilbert–Schmidt factors with equal norms is obtained from the square root of its modulus (C08).

## Unit 7: scans 59–60 — Hilbert tensor products
The n-fold tensor product carries the product inner product; permutation and associativity are unitary, and the tensor product of bounded maps has norm bounded by the product of their norms (C09). In the two-factor reduction, the ink reads $A_1:E_1	o F_1$, not $E_1	o E_2$; the target type and image both confirm this correction (C15).

## Unit 8: scans 60–62 — exterior Hilbert power
The normalized antisymmetrizer is an orthogonal projection. Scaling the inner product on its range by $n!$ yields the determinant formula for decomposable wedges (C10). The algebraic exterior power is dense in the Hilbert completion.

## Unit 9: scans 62–63 — basis on the slip
The increasing-index wedge vectors form an orthonormal basis: orthonormality follows from the determinant formula, and totality from density of the span of the original basis (C10). The slip's insertion and the exposed supporting sheet are two parts of the same physical sheet; no separate unit is introduced.

## Unit 10: scans 62–64 — determinant bounds
The Gram determinant formula and Hadamard inequality give the wedge norm bound; Cauchy–Schwarz on the exterior power gives the mixed determinant estimate (C11). The coefficient in the factorization formula (8) on scan 64 remains palaeographically undecided; the norm estimate (9) is independently proved (C12).

## Unit 11: scan 64 — exterior products of maps
The exterior product extends to the Hilbert completions and has norm at most the product of the operator norms (C12). The final sentence begins a special case that continues beyond scan 64; no completion is supplied for the missing continuation.

## Overall
All mathematical claims that can be stated precisely from these 14 scans are proved or refuted in `PROOFS.tex`. The explicit page-level questions are pencil marks, not formulated mathematical problems; their scope is not inferable. The only unresolved item in this package is the exact overwritten scalar and formula label in scan 64 (8). Earlier chapter references are not checked because the cited earlier chapter pages are not among the supplied sources. The results archive remains unopened, as required, because the check is not complete while that palaeographical reading remains undecided.
