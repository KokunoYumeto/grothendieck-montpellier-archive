from fractions import Fraction

# Verify the normalized pair used for the scan-3 derivative question.
def P(x):
    return Fraction(1, 2) * x * x + Fraction(1, 2) * x

def dP(x):
    return x + Fraction(1, 2)

z = Fraction(-1, 2)
assert P(0) == 0
assert P(1) == 1
assert dP(z) == 0
assert P(z) == Fraction(-1, 8)
assert P(z) != 1
print("P(0)=0; P(1)=1; P'(-1/2)=0; P(-1/2)=-1/8 != 1: PASS")
