INCOMPLETE

# Research directions

## RD-1 — Discrete-topology formal simplicity and the differential obstruction
Origin: scan 22/020 question 2 and the proposition on 22/024–025; object H0D6/H0D7.
Work done: isolated the claimed no-left-inverse statement for
\(\Omega^1_{K/k}\otimes_K A\to\Omega^1_{A/k}\), where
\(A=K[[t_1,\ldots,t_n]]\), \(n>0\), and
\(\dim_K\Omega^1_{K/k}=\infty\). The finite-support reduction to a
finitely generated intermediate field is recorded in PROOFS.tex.
State reached: open. The manuscript's final coefficientwise derivation formula
requires continuity, which is not stated for the discrete-topology problem.
The continuous-derivation variant has the stated infinite-support
contradiction. No conclusion is drawn for arbitrary algebraic derivations.
Next: investigate derivations of the fraction field of \(K[[t]]\) over
\(K(t)\), and whether a derivation with prescribed restriction on K can
extend to the whole power-series ring with values in the direct-sum module.

## RD-2 — Characteristic-p p-independence counterexample
Origin: scans 22/027–029; object H0D9.
Work done: transcribed the proposed coefficient construction
\(y=\sum_{i=0}^{p-1}a_i x^i\) and its stated conditions.
State reached: open. The algebraic independence of the parameters and the
claimed descriptions of \(K^p\cap k\) and the differential kernel have
not been checked from first principles.
Next: reconstruct K as a field extension of k, compute p-bases of k and K,
and calculate the map \(\Omega^1_k\otimes_k K\to\Omega^1_K\) directly.

## RD-3 — Four questions on formal simplicity, openness and flatness
Origin: scans 22/020–021; object H0D6.
Work done: separated the four numbered questions and preserved the margin
qualifications in CLAIMS_STATUS.tsv.
State reached: open; no exact literature result was opened and matched.
Next: compare each question with the exact statements in EGA 0_IV §§19–22
and EGA IV §§16–17, then search the cited literature with hypotheses matched.

## RD-4 — Reused trace/norm typescript
Origin: scans 22/030 and 22/028; object H0D4.
Work done: identified internal manuscript pagination 26 then 27 and transcribed
the displayed identities (31)–(45) from the available readings.
State reached: open; formulas (12) and (13), on which the text relies, are
outside the supplied range. No proof of all identities is claimed.
Next: locate the preceding typescript pages and check the local trace/norm
decompositions and transitivity identities.
