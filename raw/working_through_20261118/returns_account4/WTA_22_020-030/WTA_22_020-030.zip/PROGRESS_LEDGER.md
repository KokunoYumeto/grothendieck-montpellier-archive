# Progress ledger — WTA_22_020-030

Main question: scan 22/020 question 2, passage from formal simplicity for the
usual topology to the discrete topology.

Review time: 2026-11-18T20:13:52Z.
Movement: one key proof gap identified in the proposed derivation argument.
The no-left-inverse proposition is not counted as proved because the
coefficientwise formula assumes continuity, not supplied by the statement.

| Item | Current status | Strongest gate / state |
|---|---|---|
| C20.1 | open | Exact equivalence with universal regularity not checked against a theorem. |
| C20.2 | open | Reduction to differential splitting obstruction for power-series algebras; continuity gap unresolved. |
| C20.3 | open | Localisation/resolution remarks transcribed; openness not proved. |
| C20.4 | open | Generic-flatness-style reduction recorded; openness not proved. |
| C22.1 | open | Finite-support reduction valid; coefficientwise derivation step unproved absent continuity. |
| C27.1 | open | Explicit characteristic-p construction transcribed; p-basis verification outstanding. |
| C28.1 | open | Identities (31)–(45) transcribed; prior formulas and hypotheses missing. |

The package is INCOMPLETE. No three-hour review or two-consecutive-no-movement
stop condition was reached. No claim is presented as settled unless explicitly
stated in CLAIMS_STATUS.tsv.
