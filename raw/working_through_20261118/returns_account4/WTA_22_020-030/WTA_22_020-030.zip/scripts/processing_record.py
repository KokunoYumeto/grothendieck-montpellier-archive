# Reproducibility record for WTA_22_020-030 partial package.
# Inputs were extracted from the six supplied ZIP archives (excluding results.zip).
# Whole-page JPEGs 22_scan020.jpg through 22_scan030.jpg were assembled into a visual montage.
# Textual witnesses used: first/MPL_22+23_002-016 and second/K22-02.
# Deliverables were authored manually; no OCR was run.
