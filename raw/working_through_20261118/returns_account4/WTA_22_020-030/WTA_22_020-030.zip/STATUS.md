# Package status

This is a partial, explicitly incomplete research package. It is not a completed companion edition.
The whole-page images were inspected as a montage, and the first and second transcription witnesses
were compared textually. The required crop-first decisions, all scan checks, all abbreviation
expansions, complete line-keyed notes, full audit of 36 note entries, complete mathematics of the
characteristic-p counterexample, and exact literature verification remain unfinished.

The only mathematical proof file records a genuine obstruction in the proposed proof of the
differential no-left-inverse proposition: the coefficientwise formula for arbitrary derivations
requires continuity. The proposition is therefore left open rather than reported as proved.

The results archive was deliberately not opened because the units are not complete, as required.
