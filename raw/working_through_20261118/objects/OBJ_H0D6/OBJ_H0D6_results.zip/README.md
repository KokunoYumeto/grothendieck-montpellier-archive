# Our results that cite the folders of OBJ_H0D6

The statements of our research runs (results_register/REGISTER.tsv, built 18 Nov 2026 by script from each run's newest results table) whose `his_places` cite these folders and pages: 0 rows. The status is the run's own claim unless `check_events` records a check. Open this only after the entry is written.
