# The context of OBJ_H0D6

- `topics/<SA>_TOPIC.md`: the catalogue of each topic the entries come from (cotes, titles, what is transcribed and by which route).
- `OBJECTS_NEARBY.tsv`: the other objects of the same topics, and those the sweep linked to this one or put in the same theme, with their tags: the links of the entry are made to these tags.
- `ega_fr/ega0-19-fr.tex`: EGA 0_IV §19, formally smooth algebras and Cohen rings (French, our edition)
- `ega_fr/ega0-19b-fr.tex`: EGA 0_IV §19, continued (French, our edition)
- `ega_fr/ega0-20-fr.tex`: EGA 0_IV §20, derivations and differentials (French, our edition)
- `ega_fr/ega0-21-fr.tex`: EGA 0_IV §21, differentials in rings of characteristic p (French, our edition)
- `ega_fr/ega0-22-fr.tex`: EGA 0_IV §22, differential criteria of smoothness and regularity (French, our edition)
- `ega_fr/ega0-23-fr.tex`: EGA 0_IV §23, Japanese rings (French, our edition)
- `ega_fr/ega4-16-fr.tex`: EGA IV §16, differential invariants; differentially smooth morphisms (French, our edition)
- `ega_fr/ega4-17-fr.tex`: EGA IV §17, smooth, unramified and étale morphisms (French, our edition)
