# The entries of OBJ_H0D6

- `ENTRIES.md`: every entry in full.
- `ENTRIES.tsv`: the index.
- `OBJECT.tsv`: the global row of each object (GLOBAL_OBJECTS.tsv) and its items in the topics (OBJECTS.tsv of each topic).
- `CHECKS.tsv`: 0 rows of our check register (results_register/CHECK_REGISTER.tsv) about these entries, items and objects: who checked what, how, with what result.
