# OBJ_H0D6: the note entries
13 entries about this object, in page order. Each entry is given in full as it stands in its file. The placement lines are the sweep's (horizontal sweep 1, Claude Opus 5.5 at effort max, 18 Nov 2026).

## MPL_22+23_002-016#31: A08 — conjecture / self-flagged open problem; 22/014, middle paragraph

- object: H0D6, item SA23-18 of topic SA23
- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `results_register/horizontal/inputs/SA23/pro/MPL_22+23_002-016_notes.md`, line 180
- pages it is about: 22: 14
- kind: self-flagged / conjecture
- the sweep's placement: his open questions 1-4 on formally simple and Cohen algebras -- 22/014, middle paragraph; basis index-row; fidelity not checked

After reducing to $I^2=0$, the author writes “nous ignorons s'il existe toujours une solution” to lifting a prescribed Cohen algebra $B_0$. The complete-local lifting problem is treated in the supplied `EGA_chap0_ega0-19.tex`, 0.19.7.2, by an explicit $A_0$-isomorphism $B\otimes_A A_0\xrightarrow{\sim}B_0$, while 0.19.7.3(i) retains a further question about weakening completeness to the base-ideal topology. The sheet adds an earlier formulation of that obstruction problem, and the completed case and the weakened-completeness question must be compared through those two different completion maps rather than assigned one undifferentiated “open” status.

## codex:K22-02#1: 

- object: H0D6, item SA23-18 of topic SA23
- written by: GPT-6 Astra at reasoning effort max (Codex web), notes of the folder K22-02
- file: `results_register/horizontal/inputs/SA23/codex/K22-02_notes.md`, line 0
- pages it is about: 22: 17-30
- kind: his marks of doubt and unfinished steps
- the sweep's placement: Cohen algebras, his questions, derivations and the counterexample (cote 22, scans 17-30) -- his marks of doubt and unfinished steps; basis index-row; fidelity not checked

(the entry's text was not found in its file)

## work:K22-02#1: What the pages do

- object: H0D6, item SA23-18 of topic SA23
- written by: GPT-6.2 Astra at reasoning effort max (ChatGPT Work), math notes of the folder K22-02
- file: `grothendieck_archive_transcription_20261110/codex_web_20261113/returns/K22-02/out/K22-02_mathnotes.md`, line 3
- pages it is about: 22: 17-30
- kind: summary of the pages
- the sweep's placement: Cohen algebras, his questions, derivations and the counterexample (cote 22, scans 17-30) -- summary of the pages; basis index-row; fidelity not checked

**Cohen algebras, scan 17.** Corollary 4.12 concerns a local homomorphism of noetherian local rings with r(B)=r(A)B and residue extension K/k. It puts three descriptions of B side by side: complete and formally simple over A, complete and flat with separable K/k, and a Cohen algebra over A. It adds existence over a prescribed separable residue extension and uniqueness up to A-algebra isomorphism.

**Completeness and editorial choices, scans 17–18.** The author considers replacing completeness for B’s own topology by completeness for the IB-adic topology. He identifies earlier numbers requiring changes and leaves the decision to the addressee. The next sheet proposes reordering existence, descent and uniqueness.

**A fibre criterion, scan 18.** Corollary 4.13 compares formal simplicity with flatness and universal regularity of the fibre B⊗ₐk. The hypothesis on the residue extension is finite “multiplicité radicielle”; a handwritten “ou” introduces the radical condition. The argument passes to the completion and appeals to earlier numbered results.

**Open questions about topology, scans 20 and 22–23.** The first question asks whether universal regularity implies formal simplicity. The second asks whether the topology can be changed from the usual one to the discrete one. A later sheet treats a presentation by formal power series in positive characteristic using a finite p-basis. The characteristic-zero discussion tests k[[t]] and turns to differentials.

**Open loci, scans 20–21.** Question 3 concerns the points of Spec B whose fibre local ring is formally simple over the residue field. There is a separate question about localization, an appeal to Nagata and a discussion of resolution of singularities. Question 4 asks for openness of the flat locus. Its reduction singles out a pair of primes and an open subset after forming the primed rings. Some of the qualifications are in rapidly written diagonal notes.

**A proposed obstruction, scans 23–25.** The map from differentials of the coefficient field, tensored up to the power-series ring, is tested for a left inverse. Scan 24 states a proposition for K/k with an infinite-dimensional differential module and a positive number of variables. The proposed derivation is reduced to the case Dtᵢ=0. Scan 25 expands into components indexed by a basis and proposes a series whose components would not have finite support.

**A field example, scans 27 and 29.** The square starts with k′=k∩Kᵖ. The writer compares p-independence over that intersection with p-independence after passage to K, and records a possible failure of injectivity for a map of differentials. Below the square he builds fields from x, y and coefficients aᵢ. The two defining lines give a=xᵖ and express a₀ using y and the terms with positive index. Scan 29 compares two coefficient expansions, then revises the conditions on the generators.

**Extension and norm of divisors, scan 30.** Formula (31) extends a place with its ramification multiplicities. Formula (34) uses the residue-degree factors for the norm. The typescript relates both operations to principal divisors and towers, then records the two degree identities (38) under its product-formula assumptions.

**Extension, trace and norm of repartitions, scans 30 and 28.** The last paragraph of typescript page 26 (scan 30) continues on typescript page 27 (scan 28). The local entries of an extension are specified first. Formula (40) defines trace by a sum of local traces and norm by a product of local norms. The text then identifies their restrictions to principal repartitions and the effect on idèles.

**Product topology, scan 28.** Section 6 introduces a family of topological groups and open distinguished subgroups. The last sentence starts to describe a fundamental system of neighbourhoods of the identity and breaks off at “for-”.

## work:K22-02#2: Statements left without proof

- object: H0D6, item SA23-18 of topic SA23
- written by: GPT-6.2 Astra at reasoning effort max (ChatGPT Work), math notes of the folder K22-02
- file: `grothendieck_archive_transcription_20261110/codex_web_20261113/returns/K22-02/out/K22-02_mathnotes.md`, line 25
- pages it is about: 22: 17-30
- kind: unproved claims
- the sweep's placement: Cohen algebras, his questions, derivations and the counterexample (cote 22, scans 17-30) -- unproved claims; basis index-row; fidelity not checked

| Scan | Statement and the writer’s words | Extent of the argument on these sheets |
| --- | --- | --- |
| 17 | “Conditions équivalentes”; “il existe une algèbre de Cohen B sur A … et B est unique à isomorphisme de A-algèbres près.” | The introductory “En particulier” presents this as a consequence of earlier material. |
| 18 | “les conditions (i) et (ii) étant invariantes par changement de B en [B avec chapeau]”; “formellement simple = … régulier en vertu de …” | Completion and an earlier result are invoked. The writer also proposes proving existence by descent and comparing with a B-type. |
| 21 | “OK. en caractéristique 0 pour les bons anneaux, grâce à la résolution des singularités.” | A justification is named. The long margin also introduces a further condition on openness or constructibility. |
| 22 | “En la complétant par les tᵢ, on trouve une p-base de A sur k”; “Donc dans ce cas on gagne.” | The construction and a tensor expression are written down. The reference “Diff.” follows. |
| 24–25 | “Il faut prouver que l’hom … n’a pas d’inverse à gauche”; “Il reste à prouver …”; “il suffit alors de prendre f=∑aₙtⁿ.” | A reduction and proposed construction are present. The final series is followed by dots; no concluding verification appears. See R25 below. |
| 27 | “il peut arriver que le noyau … ne soit pas engendré sur K par les dx⊗1 …”; “On peut prendre un exemple où il est de dim 1”. | The kernel statement introduces an example. Its dimension assertion appears in the slanted note; a dimension computation is not written there. |
| 29 | “a′ᵢ=aᵢ, donc aᵢ∈k=F(x,y), absurde”; “Conditions essentielles”. | The author uses the uniqueness of the coefficients in the stipulated presentation and lists variants of the data. |
| 30 | “Il est clair que … est un isomorphisme croissant”; “En vertu de (29)”; “D’autre part (30) montre que l’on a”; “on voit que” before (35). | Formulas (32) and (36) concern principal divisors, (33) and (37) towers, and (38) the two degree identities. Formulas (29) and (30) themselves are outside these fourteen scans. C30.35 below concerns (35) only. |
| 28 | “Enfin une formule évidente de transitivité”; “On a enfin les formules suivantes (que l’on vérifie comme l’âne qui trotte)”; “formules de transitivité”. | In (39) the divisor operation commutes with extension. The typescript states linearity of trace, multiplicativity of norm on idèles, and the identities (41)–(44) for scalars, extended elements and the divisor of a norm. The final transitivity item is verbal. |

## work:K22-02#3: Questions and conjectures

- object: H0D6, item SA23-18 of topic SA23
- written by: GPT-6.2 Astra at reasoning effort max (ChatGPT Work), math notes of the folder K22-02
- file: `grothendieck_archive_transcription_20261110/codex_web_20261113/returns/K22-02/out/K22-02_mathnotes.md`, line 39
- pages it is about: 22: 17-30
- kind: questions and conjectures
- the sweep's placement: Cohen algebras, his questions, derivations and the counterexample (cote 22, scans 17-30) -- questions and conjectures; basis index-row; fidelity not checked

- **Scan 17.** “Je t’en laisse donc le choix” applies to the change of completeness hypothesis. On scan 18, “peut-être plus service” introduces the proposed alternative exposition.
- **Scan 20, point 1.** “Est-il vrai que A … simple sur k si A est … régulier sur k” is followed by its proposed consequence for a local homomorphism. The short marginal answer is “OK”.
- **Scans 20 and 22, point 2.** “Est-il vrai … pour sa topologie discrète? Cas où A est complète?” On 22 the question returns with “???”. Scan 20 suggests that “la réponse soit affirmative en car p>0, négative en car 0”, then considers the relative case over Λ. The margin has “Faux, cf …”, “Je suis pessimiste”, and a qualified “Peut-être y-a-t-il de l’espoir …”.
- **Scans 20–21, point 3.** “est-il ouvert?” concerns the locus in the fibres. The next page asks whether the relevant set is “stable par localisation?” and mentions residual extensions of finite degree. A slanted passage asks for a locus to be “ouvert (ou au moins constructible)”.
- **Scan 21, point 4.** “Lieu des pts de Spec B en lesquels B est plat sur A est-il ouvert?” The writer follows with “vérifier que … ∃ un ouvert non vide de Spec B′”.
- **Scan 23.** “Je présume que si dim A>0, A n’est jamais … simple sur k pour sa topologie discrète.” The text also says “je doute qu’il y ait …” relative to the prime field and asks whether the differential map “admet un inverse à gauche?”. The abbreviation in the conjecture is uncertain.
- **Scans 27 and 29.** “peut ne être pas injectif” and “il peut arriver” introduce a proposed counterexample. The second sheet compares presentations and gives “Conditions essentielles”.

## work:K22-02#4: Slips

- object: H0D6, item SA23-18 of topic SA23
- written by: GPT-6.2 Astra at reasoning effort max (ChatGPT Work), math notes of the folder K22-02
- file: `grothendieck_archive_transcription_20261110/codex_web_20261113/returns/K22-02/out/K22-02_mathnotes.md`, line 49
- pages it is about: 22: 17-30
- kind: slips
- the sweep's placement: Cohen algebras, his questions, derivations and the counterexample (cote 22, scans 17-30) -- slips; basis index-row; fidelity not checked

| ID | Scan | Written → apparently intended | Confidence and reason |
| --- | --- | --- | --- |
| S17a | 17, line 3 | tel with s struck → tels | Low. The surviving word is followed by que and the preceding nouns are plural. The deleted s could be part of a change the author did not finish. |
| S17b | 17, line 10 | je me répens → je me repens | High. The verb has a clearly typed acute accent on the first e. |
| S17c | 17, line 14 | des réajustement analogues → des réajustements analogues | High. The last typed t is followed by a space before analogues. No s is visible. |
| S18 | 18, near the foot | lesdémontre → les démontre | High. The d and the preceding s are one normal typewriter pitch apart. |
| S28 | 28, paragraph below heading 6 | une famille se sous-groupes → une famille de sous-groupes | High for the separately typed word se. Its two letters are clear; the overprint is on the following word. The parallel preceding phrase has de. |
| S30 | 30, product-formula paragraph | P∣P → P∣P′ under the second displayed-in-prose sum of e(P)f(P) | High. The earlier version following (34) has a prime on the second P; the later line has two unprimed P’s and no covered or struck mark at that spot. |

## work:K22-02#5: Pointers

- object: H0D6, item SA23-18 of topic SA23
- written by: GPT-6.2 Astra at reasoning effort max (ChatGPT Work), math notes of the folder K22-02
- file: `grothendieck_archive_transcription_20261110/codex_web_20261113/returns/K22-02/out/K22-02_mathnotes.md`, line 60
- pages it is about: 22: 17-30
- kind: pointers
- the sweep's placement: Cohen algebras, his questions, derivations and the counterexample (cote 22, scans 17-30) -- pointers; basis index-row; fidelity not checked

| Scan | Words or reference | Referent on these pages |
| --- | --- | --- |
| 17 | “définition … .7”, “.2., … .6. et la suite”, “dans … .9. à … .12.” | Proposed alterations to an earlier treatment. The initial section numeral is corrected in pen. “Cohen” identifies the named algebras. |
| 18 | “(cf 2.6.)”, “contenu dans … .11.” with “resp. 3.12.” above, “en vertu de … .6.”, “par descente comme dans … .11.” | Earlier criteria and the descent argument. The margin proposes keeping 4.1 in N°1 and mentioning 4.6 in a remark. |
| 21 | “Cf IV 2.10.1”; “critère jacobien de Nagata et Th. de Nagata” | The former is attached by a line to the localization question. The latter accompanies a complete local algebra over a field. |
| 22, 26 | “[cf … Diff. …]”; “Différentielles” on the cancelled cover | The abbreviation is an internal pointer. The cover offers a possible expansion; it does not establish the precise text intended. |
| 29 | “cf le NB marginal” | Points back to a marginal note in the field example. |
| 30 | “En vertu de (29)”, “(30) montre”, “en vertu de (30)” | Previous numbered statements of the divisor typescript. |
| 28 | “D’après les formules (12) et (13) (§ 2,n°2)” | Earlier trace and norm rules used to identify the restrictions to principal repartitions. |

## work:K22-02#6: Remarks of the model

- object: H0D6, item SA23-18 of topic SA23
- written by: GPT-6.2 Astra at reasoning effort max (ChatGPT Work), math notes of the folder K22-02
- file: `grothendieck_archive_transcription_20261110/codex_web_20261113/returns/K22-02/out/K22-02_mathnotes.md`, line 72
- pages it is about: 22: 17-30
- kind: model remarks
- the sweep's placement: Cohen algebras, his questions, derivations and the counterexample (cote 22, scans 17-30) -- model remarks; basis index-row; fidelity not checked

- **R25, medium.** The condition that the individual coefficient differentials be nonzero, taken alone, permits repeating a single coefficient. All the resulting differentials can then occupy the same finite set of basis positions. The distinction matters because scan 25 asks for infinitely many nonzero components. **Low confidence** that a step was inadvertently omitted: the more specific component conditions are crossed out, and the manuscript ends with dots.
- **C30.35, high.** Using the definitions (31) and (34) on a single place P′ gives the coefficient ∑e(P)f(P) at P′. The sheet identifies this sum with n, which recovers (35) by additivity. This checks the displayed consequence conditional on the local degree sum used on the page.
- **Reading question, scan 20, relative version of point 2.** The frozen reading has “sur” followed by a cancelled group and then Λ. There appears to be a separate small **de** immediately before Λ. It may be a live word outside the cancelled group. The final text retains the frozen boundary.
- **Reading question, scan 27, start of the field example.** The frozen text gives “Voici un exemple”. The group after “un” has a long join and a tall final stroke. An abbreviated **contre-ex.** is also plausible. This word was outside the marked span before Voici.
- **Reading question, scan 29, after the cancelled explanatory sentence.** The frozen line has “p-indép. sur F”. A small oval below and to the right of F might be an index **0**, or the lead-in to the hooked addition. The field later in the same paragraph is written with a plain double-stem F.

## MPL_22+23_002-016#36: A13 — conjecture / source question subsequently matched in context; 22/020, question 1

- object: H0D6, item SA23-18 of topic SA23
- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `results_register/horizontal/inputs/SA23/pro/MPL_22+23_002-016_notes.md`, line 200
- pages it is about: 22: 20
- kind: conjecture
- the sweep's placement: his open questions 1-4 on formally simple and Cohen algebras -- 22/020, question 1; basis index-row; fidelity not checked

“Est-il vrai” asks for the converse from universal regularity to formal simplicity, and the nearby “OK” is itself only a short annotation. The supplied `EGA_chap0_ega0-22.tex`, 0.22.5.8, identifies the two tests through the maps $A\to A\otimes_k k'$ for finite extensions with $k'^p\subset k$, proving the implication the question asks about for the preadic topology. This is a direct context match to the field-base question; the bracketed general local-homomorphism formulation on the sheet additionally uses flatness and fibre comparison as organized in `EGA_chap0_ega0-19.tex`, 0.19.7.1, so the scope of “OK” should remain attached to its actual position.

## MPL_22+23_002-016#37: A14 — conjecture / self-flagged; 22/020, question 2 and heavily doubtful margin

- object: H0D6, item SA23-18 of topic SA23
- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `results_register/horizontal/inputs/SA23/pro/MPL_22+23_002-016_notes.md`, line 204
- pages it is about: 22: 20, 22
- kind: self-flagged / conjecture
- the sweep's placement: his open questions 1-4 on formally simple and Cohen algebras -- 22/020, question 2 and heavily doubtful margin; basis index-row; fidelity not checked

The author asks whether formal simplicity for the ordinary local topology persists for the discrete topology and writes “Il est possible que la réponse soit affirmative en car $p>0$, négative en car 0.” The margin begins “Faux” but the continuation and its attachment contain many frozen doubts, so it cannot certify a precise withdrawn general statement without further reading evidence. The relevant concrete comparisons are `EGA_chap0_ega0-19.tex`, 0.19.3.1 and 0.19.3.8 (the lifting problems under change of topology), and `EGA_chap0_ega0-22.tex`, 0.22.6.7 (the finite-type field-algebra case), while 22/022–025 adds the author's own finite-$p$-base case and infinite-differential obstruction.

## MPL_22+23_002-016#38: A15 — conjecture; 22/020 bottom–021 upper half, question 3

- object: H0D6, item SA23-18 of topic SA23
- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `results_register/horizontal/inputs/SA23/pro/MPL_22+23_002-016_notes.md`, line 208
- pages it is about: 22: 20
- kind: conjecture
- the sweep's placement: his open questions 1-4 on formally simple and Cohen algebras -- 22/020 bottom–021 upper half, question 3; basis index-row; fidelity not checked

“Lieu ... est-il ouvert?” concerns the local formal-simplicity locus in the fibres of a flat noetherian map, followed by “bons anneaux,” Nagata, and resolution-of-singularities annotations. `EGA_chap0_ega0-22.tex`, 0.22.5.10(ii), repeats the openness question for the locus $\{\mathfrak p:A_{\mathfrak p}\text{ formally smooth over }k\}$, and 0.22.6.7 gives a finite-type/separable-field case via the determinant $\det(D_j(f_i))$ defining a neighbourhood. The sheet extends the enquiry to the displayed relative fibre rings $B\otimes_A\kappa(\mathfrak p)$; its difficult marginal qualifications remain reading questions, not a proof of the entire relative assertion.

## MPL_22+23_002-016#39: A16 — unproved claim; 22/021, “stable par localisation ?” and margins

- object: H0D6, item SA23-18 of topic SA23
- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `results_register/horizontal/inputs/SA23/pro/MPL_22+23_002-016_notes.md`, line 212
- pages it is about: 22: 21
- kind: unproved claim
- the sweep's placement: his open questions 1-4 on formally simple and Cohen algebras -- 22/021, “stable par localisation ?” and margins; his term: stable par localisation ?; basis index-row; fidelity not checked

The localization question has an exact map-level counterpart in `EGA_chap0_ega0-22.tex`, 0.22.5.9: $A_{\mathfrak p}\otimes_k k'$ is a localization of $A\otimes_k k'$, so the geometric-regularity test of 0.22.5.8 travels through that localization. This verifies the field-base localization mechanism associated with the manuscript's question, while its two marginal conditions about generization and neighbourhoods concern the further passage from stability to openness. The tentative reference “Cf IV 2.10.1|2.40.1” remains unresolved in the frozen text, and the supplied IV contents alone cannot adjudicate its digits.

## MPL_22+23_002-016#40: A17 — conjecture / unproved reduction; 22/021, question 4, lower half

- object: H0D6, item SA23-18 of topic SA23
- written by: GPT-6 Astra (ChatGPT Pro mode), notes of the transcription package MPL_22+23_002-016
- file: `results_register/horizontal/inputs/SA23/pro/MPL_22+23_002-016_notes.md`, line 216
- pages it is about: 22: 21
- kind: conjecture
- the sweep's placement: his open questions 1-4 on formally simple and Cohen algebras -- 22/021, question 4, lower half; basis index-row; fidelity not checked

The author asks whether the flat locus of an arbitrary noetherian ring map $A\to B$ is open and reduces the enquiry to finding a nonempty flat open after $A'=A/\mathfrak p\subset B'=B/\mathfrak q$ and passage to $K'=\operatorname{Frac}(A')$. Context search finds local flatness comparison in `EGA_chap0_ega0-19.tex`, 0.19.7.1, and completed base change in 0.19.7.1.2, but no supplied proof of this full arbitrary-noetherian-map openness reduction. The exact quotient and localization maps written here are therefore a separate research item; a finite-type generic-flatness argument requires its own finite-type input, which this question does not write down.
