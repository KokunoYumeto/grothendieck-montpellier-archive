# The pages of OBJ_H0D6

- `PASSAGES.md`: every page the entries cite, with every reading on disk and witness H.
- `page_map.tsv`: per page, the readings, Hua's state (`text`, `desc` = only a description, `nothing`) and the image attached, if any.
- `transcriptions/cote_<C>.tex`: the whole folder, each page in the reading a pass starts from, with a comment naming it.
- `PREAMBLE.tex`: our macros.
