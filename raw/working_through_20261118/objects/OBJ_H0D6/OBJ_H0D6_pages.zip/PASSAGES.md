# OBJ_H0D6: the passages the entries cite

For each page: the reading a pass starts from (the Claude second pass where one exists, else the first reading), then the other readings on disk, then the text of witness H (the Commutator project of Michel Hua, github.com/Commutator-IO/grothendieck-project, commit `aef7db2`, an AI transcription by Claude Opus 5 and Claude Opus 5.5; their page n is our scan n + 1; a witness only, in their macros). All are AI readings of the same scans; the scan decides.

## cote 22, scan 14 (cited by 1 entry)

**Pro first pass** `MPL_22+23_002-016` (GPT-6 Astra (ChatGPT Pro mode), 16 Nov 2026):

```latex
\scanpage{14}
\mspage{28}

1) $B$ est formellement simple sur $A$

2) $B$ satisfait la condition P \quad 3) $B$ est plat sur $A$ \quad 3 bis) Pour tout
entier $n\geq0$, $B_n=B/I^{n+1}B$ est plat sur $A_n=A/I^{n+1}$. \deleted{4)}

Il reste seulement à montrer l'équivalence de 3) et 3 bis), qui est
contenue en effet (moyennant les hypothèses noethériennes faites) dans
la platitude supérieure.

\deleted{Le résultat précédent} Il conviendrait de noter aussi \inserted{dès après 3.7.} que ``algèbre de
Cohen'' est une notion stable par extension de la base via produits tensoriels complétés: c'est une trivialité.

Le résultat \inserted{4.}8. montre l'intérêt qu'il y a, $A,I$ et $B_0$ étant donnés,
de disposer d'un \uline{théorème d'existence} pour une algèbre de Cohen $B$ sur $A$
se réduisant suivant $B_0$. On notera que la construction habituelle de
proche en proche nous ramène \deleted{au cas où $A$ est discr}(remplaçant $A$ par des $A_i$
et $I$ par des puissances) au cas où $I$ est de carré nul, (donc où $A$ est
discret). On obtient alors un problème de nature essentiellement infinitésimale,
dont nous ignorons s'il existe toujours une solution, faute de
savoir caractériser la structure des algèbres de Cohen $B_0$ sur l'anneau
discret $A_0$. Cependant, nous obtenons \inserted{(4.10.)} un théorème d'existence dans
un cas particulier intéressant, en utilisant les résultats du N°2. Notons
d'abord

\deleted{\uline{Théorème} \deleted{3.9.} Soit $A$ \deleted{$B$ un homomorphisme} un anneau local noethérien,
\deleted{et de corps} résiduel $k$, et soit $B_0$ une $k$-algèbre,
\deleted{qui soit un satisfasse}
\deleted{qui soit}
\deleted{aux conditions suivantes: $B_0$ est} un anneau local noethérien, \deleted{et complet,}
\inserted{de} \deleted{son corps} résiduel $K$
\deleted{est de degré de multiplicité radicielle finie sur $k$}
\deleted{(ce qui est le cas} une extension séparable de $k$, $B_0$ est (pour sa topolo-}

\uline{Corollaire} \inserted{4.}9. Soit $A\longrightarrow B$ un homomorphisme local d'anneaux locaux noethériens,
\deleted{tel que l'extension résiduelle $k(B)/k(A)$ soit à multiplicité}

\mspage{13}
```

**Work second reading** `K22-01` (GPT-6.2 Astra at reasoning effort max (ChatGPT Work), 18 Nov 2026):

```latex
\scanpage{14}
\mspage{\handwritten{28}}

1) $\mathrm B$ est formellement simple sur $\mathrm A$

\deleted{\unsure{3}}2) $\mathrm B$ satisfait la condition $\mathrm P$\quad 3) $\mathrm B$ est plat sur $\mathrm A$\quad 3 bis) Pour tout entier $n\handwritten{\geq}0$, $\mathrm B_n=\mathrm B/\mathrm I^{n+1}\mathrm B$ est plat sur $\mathrm A_n=\mathrm A/\mathrm I^{n+1}$. \deleted{4)}

Il reste seulement à montrer l'équivalence de 3) et 3 bis), qui est contenue en effet (moyennant les hypothèses noethériennes faites) dans la platitude supérieure.

\deleted{Le résultat précédent} Il conviendrait de noter aussi\inserted{ dès après 3.7.} que ``algèbre de Cohen'' est une notion stable par extension de la base via produits tensoriels complétés: c'est une trivialité.

Le résultat \deleted{\unsure{3}}\handwritten{4}.8. montre l'intérêt qu'il y a, $\mathrm A,\mathrm I$ et $\mathrm B_{\unsure{0|o}}$ étant donnés, de disposer d'un \uline{théorème d'existence} pour une algèbre de Cohen $\mathrm B$ sur $\mathrm A$ se réduisant suivant $\mathrm B_0$. On notera que la construction habituelle de proche en proche nous ramène \deleted{au cas où $\mathrm A$ est discr}(remplaçant $\mathrm A$ par des $\mathrm A_i$ et $\mathrm I$ par des puissances) au cas où $\mathrm I$ est de carré nul,(donc où $\mathrm A$ est discret). On obtient alors un problème de nature essentiellement infinitésimale, dont nous ignorons s'il existe toujours une solution, faute de savoir caractériser la structure des algèbres de Cohen $\mathrm B_0$ sur l'anneau discret $\mathrm A_0$. Cependant, nous obtenons \inserted{\handwritten{(\deleted{\unsure{3}}\unsure{4|3}.10.)}} un théorème d'existence dans un cas particulier intéressant, en utilisant les résultats du N\textsuperscript{\uline{o}}2\deleted{\unsure{,}}. Notons \inserted{d'abord}

\deleted{\uline{Théorème} 3.9. Soit $\mathrm A$ \deleted{$\mathrm B$ un homomorphisme} un anneau local noethérien, \deleted{et de corps} résiduel $k$, et soit $\mathrm B_0$ une $k$-algèbre, \deleted{qui soit \unsure{u|n} satisfasse} \inserted{\deleted{qui} soit} \deleted{aux conditions suivantes: $\mathrm B_0$ est} un anneau local noethérien, \deleted{et complet,} \inserted{de} \deleted{son corps} résiduel $\mathrm K$ \deleted{est de degré de multiplicité radicielle finie sur $k$ (ce qui est le cas} une extension séparable de $k$, $\mathrm B_0$ est (pour sa topolo-}

\uline{Corollaire} \deleted{3}\handwritten{4}.9. Soit $\mathrm A\handwritten{\to}\mathrm B$ un homomorphisme local d'anneaux locaux noethériens, \deleted{tel que l'extension résiduelle $k(\mathrm B)/k(\mathrm A)$ soit à multiplicité}
% archive sheet number: 13
```

**Witness H** (`batch-01.fr.tex`):

```latex
\page{13}\note{sa page 28}

\begin{enumerate}
  \item[1)] $B$ est formellement simple sur $A$
  \item[2)] $B$ satisfait la condition P
  \item[3)] $B$ est plat sur $A$
  \item[3 bis)] Pour tout entier $n \geqslant 0$, $B_n = B/I^{n+1}B$ est plat
    sur $A_n = A/I^{n+1}$. \struck{4)}
\end{enumerate}

Il reste seulement à montrer l'équivalence de 3) et 3 bis), qui est contenue
en effet (moyennant les hypothèses nœthériennes faites) dans la platitude
supérieure.

\struck{Le résultat précédent} Il conviendrait de noter \struck{aussi}
\add{dès après 3.7.} que ``algèbre de Cohen'' est une notion stable par
extension de la base via produits tensoriels complétés : c'est une trivialité.

Le résultat 3.8. montre l'intérêt qu'il y a, $A$, $I$ et $B_0$ étant donnés,
de disposer d'un \emph{théorème d'existence} pour une algèbre de Cohen $B$ sur
$A$ se réduisant suivant $B_0$. On notera que la construction habituelle de
proche en proche nous ramène \struck{au cas où $A$ est discret} (remplaçant
$A$ par des $A_i$ et $I$ par des puissances) au cas où $I$ est de carré nul,
(donc où $A$ est discret). On obtient alors un problème de nature
essentiellement infinitésimale, dont nous ignorons s'il existe toujours une
solution, faute de savoir caractériser la structure des algèbres de Cohen
$B_0$ sur l'anneau discret $A_0$. Cependant, nous obtenons \add{(3.10.)} un
théorème d'existence dans un cas particulier intéressant, en utilisant les
résultats du Nº2. Notons d'abord

\struck{Théorème 3.9. Soit $A$ un anneau local nœthérien, de corps résiduel
$k$, et soit $B_0$ une $k$-algèbre, qui soit un anneau local nœthérien, de
corps résiduel $K$ une extension séparable de $k$, $B_0$ est (pour sa topolo-}
\note{passage barré de six lignes par de grands traits diagonaux à l'encre, et
où la machine avait déjà biffé de x plusieurs fragments : « homomorphisme »,
« qui satisfasse aux conditions suivantes : $B_0$ est », « et complet »,
« est de degré de multiplicité radicielle finie sur $k$ (i.e.\ qui est le
corps\ldots) ». Il est remplacé par le corollaire qui suit.}

\textbf{Corollaire 3.9.} Soit $A \to B$ un homomorphisme local d'anneaux
locaux nœthériens, \struck{tel que l'extension résiduelle $k(B)/k(A)$ soit à
multiplicité}
```

## cote 22, scan 17 (cited by 7 entries)

**Pro first pass** `MPL_22+23_002-016` (GPT-6 Astra (ChatGPT Pro mode), 16 Nov 2026):

```latex
\scanpage{17}
\mspage{31}

En particulier, on obtient:

\uline{Corollaire} \inserted{4.}12. Soient $A\longrightarrow B$ un homomorphisme local d'anneaux locaux
noethériens, tel\deleted{s} que $\underline{r}(B)=\underline{r}(A)B$ et \deleted{que l'extens} soit $K/k$ l'extension
résiduelle. Conditions équivalentes: 1) $B$ est complet et formellement
simple sur $A$. 2) $B$ est \unsure{complet}, plat sur $A$, et $K/k$ est séparable.
3) $B$ est une algèbre de Cohen sur $A$. De plus, une extension séparable
$K$ de $k$ étant donnée, il existe une algèbre de Cohen $B$ sur $A$ se réduisant
suivant $K$, et $B$ est unique à isomorphisme de $A$-algèbres près.

La rédaction commence à faire un peu touffu, j'espère que tu pourras
la rendre plus lisible. D'ailleurs, je me répens un peu de la définition
\inserted{4.}7. telle quelle, il n'est pas vraiment naturel de supposer $B$ séparée
et complète pour sa topologie propre, mais simplement pour sa topologie
$IB$-adique (ce qui est moins fort); mais une telle modification demanderait
des réajustement analogues pour \inserted{4.}2., \inserted{4.}6. et la suite. Je t'en laisse
donc le choix, pensant que le choix adopté n'aura pas de grande importance
pratique pour la suite : dans \inserted{4.}9. à \inserted{4.}12. cela obligera simplement à
supprimer à certains endroits le mot ``complet'',
\inserted{ou \unsure{è|à} le remplacer par un autre \unsure{comple}}
\deleted{\deleted{en particulier ``Cohen'' deviendra} synonyme dans le contexte des anneaux locaux noethériens de
\deleted{``formellement} simple'', -- sous réserve de l'embêtante hypothèse de
\deleted{multiplicité} radicielle. \deleted{Il est vrai} Ce serait plutôt un avantage, \deleted{mais}
\deleted{il est vrai par contre que cela ne s'harmoniserait plus} de plus les
\deleted{anneaux de Cohen} sont}

\deleted{\uline{Corollaire \unsure{4.13}} $A\unsure{\longrightarrow|\text{---}} B$ hom loc. d'anneaux locaux
noeth, munis de leurs topologies naturelles. On
suppose $k(B)/k(A)$ à mult. \unsure{insép.} finie. Alors
Condit. \unsure{équivalentes}}

\mspage{16}
```

**Work second reading** `K22-02` (GPT-6.2 Astra at reasoning effort max (ChatGPT Work), 18 Nov 2026):

```latex
\cotefile{22}
\scanpage{17}
\mspage{31}

En particulier, on obtient:

\uline{Corollaire} \deleted{3}\handwritten{4}.12. Soient $A\handwritten{\to}B$ un homomorphisme local d'anneaux locaux noethériens, tel\deleted{s} que $\underline{r}(B)=\underline{r}(A)B$ et \deleted{que l'extens} soit $K/k$ l'extension résiduelle. Conditions équivalentes: 1) $B$ est complet et formellement simple sur $A$. 2) $B$ est \deleted{\unsure{pl|p}}complet, plat sur $A$, et $K/k$ est séparable. \handwritten{3}) $B$ est une algèbre de Cohen sur $A$. De plus, une extension séparable $K$ de $k$ étant donnée, il existe une \deleted{\unsure{q|a}}algèbre de Cohen $B$ sur $A$ se réduisant suivant $K$, et $B$ est unique à isomorphisme de $A$-algèbres près.

La rédaction commence à faire un peu touffu, j'espère que tu pourras la rendre plus lisible. D'ailleurs, je me répens un peu de la définition \deleted{3}\handwritten{4}.7. telle quelle, il n'est pas vrai\deleted{\unsure{m|me}}ment naturel de supposer $B$ séparée et complète pour sa topologie propre, mais simplement pour sa topologie $IB$-adique (ce qui est moins fort); mais une telle modification demanderait des réajustement analogues pour \deleted{3}\handwritten{4}.2., \deleted{3}\handwritten{4}.6. et la suite. Je t'en laisse donc le choix, pensant que le choix adopté n'aura pas de grande importance pratique pour la suite : dans \deleted{3}\handwritten{4}.9. à \deleted{3}\handwritten{4}.12. cela obligera simplement à supprimer à certains endroits le mot \textquotedbl{}complet\textquotedbl{},\inserted{ou \deleted{\unsure{e|a}}\unsure{à|è|ă} le remplacer par un autre comple\unsure{t|\,}} \deleted{\deleted{en particulier \unsure{\textquotedbl{}Cohen\textquotedbl{}|Cohen} deviendra} synonyme dans le contexte des anneaux locaux noethériens de \deleted{\textquotedbl{}formellement} simple\textquotedbl{} , - sous réserve de l'embêtante hypothèse de \deleted{multiplicité} radicielle. \deleted{Il est vrai} Ce serait plutôt un avantage, \deleted{mais il est vrai par contre que cela ne s'harmoniserait plus} de plus les \deleted{anneaux de Cohen} sont}

\handwritten{\deleted{\uline{Corollaire \unsure{4.13|3.13}} $A\to B$ hom. loc. d'anneaux locaux noeth, munis de leurs topologies résiduelles. On suppose $k(B)/k(A)$ à mult. dép. finie. Alors conditions \unsure{équivalentes|équival.}}}
% archive sheet number: 16
```

**Witness H** (`batch-01.fr.tex`):

```latex
\page{16}\note{sa page 31}

En particulier, on obtient :

\textbf{Corollaire 3.12.} Soient $A \to B$ un homomorphisme local d'anneaux
locaux nœthériens, tels que $r(B) = r(A)B$ et \struck{que l'extens} soit
$K/k$ l'extension résiduelle. Conditions équivalentes : 1) $B$ est complet et
formellement simple sur $A$. 2) $B$ est complet, plat sur $A$, et $K/k$ est
séparable. 3) $B$ est une algèbre de Cohen sur $A$. De plus, une extension
séparable $K$ de $k$ étant donnée, il existe une algèbre de Cohen $B$ sur $A$
se réduisant suivant $K$, et $B$ est unique à isomorphisme de $A$-algèbres
près.

La rédaction commence à faire un peu touffu, j'espère que tu pourras la rendre
plus lisible. D'ailleurs, je me repens un peu de la définition 3.7. telle
quelle, il n'est pas vraiment naturel de supposer $B$ séparée et complète pour
sa topologie propre, mais simplement pour sa topologie $IB$-adique (ce qui est
moins fort) ; mais une telle modification demanderait des réajustements
analogues pour 3.2., 3.6. et la suite. Je t'en laisse donc le choix, pensant
que le choix adopté n'aura pas de grande importance pratique pour la suite :
dans 3.9. à 3.12. cela obligera simplement à supprimer à certains endroits le
mot ``complet'', \add{ou à le remplacer par un autre complet}
\struck{\struck{en particulier ``Cohen'' deviendra} synonyme dans le contexte
des anneaux locaux nœthériens de ``\struck{formellement} simple'', --- sous
réserve de l'embêtante hypothèse de \struck{multiplicité} radicielle.
\struck{Il est vrai} Ce serait plutôt un avantage, \struck{mais il est vrai
par contre que cela ne s'harmoniserait plus} de plus les \struck{anneaux de
Cohen sont}}
\note{tout le passage qui suit « complet », est enfermé dans un cadre et barré
à la main de grands traits diagonaux ; la machine y avait déjà biffé de x les
mots signalés.}

\add{\struck{Corollaire 3.13. $A \to B$ hom.\ local d'anneaux locaux nœth.,
\ill{} de corps \ill{} \uncertain{Cohen-Macaulay}. \ill{} $k(B)/k(A)$ à mult.\
deg.\ finie. Alors condit.\ équivalentes}}
\note{le bas du feuillet porte, sur quatre lignes et dans une écriture très
rapide, un début de « Corollaire 3.13 » manuscrit, aussitôt annulé par cinq
grandes boucles. C'est le premier jet du corollaire que le feuillet suivant
reprend au propre.}
```

## cote 22, scan 18 (cited by 7 entries)

**Pro first pass** `MPL_22+23_002-016` (GPT-6 Astra (ChatGPT Pro mode), 16 Nov 2026):

```latex
\scanpage{18}
\mspage{32}

\margin{\figure{\begin{tikzpicture}\draw (.2,0)--(0,0)--(0,5)--(.2,5);\end{tikzpicture}}}
\uline{Corollaire} \inserted{4.}13. Soit $A\longrightarrow B$ un homomorphisme local d'anneaux locaux
noethériens, on suppose $k(B)/k(A)$ à multiplicité radicielle finie
(par exemple une extension séparable, ou de type fini),
\inserted{ou $\underline{r}(B)=\underline{r}(A)B$.} \deleted{Conditions} On
munit $A$ et $B$ de leurs topologies habituelles. Alors les conditions suivantes
sont équivalentes: (i) $B$ est formellement simple sur $A$ (ii) $B$ est
plat sur $A$, et $B_0=B\otimes_A k\deleted{\unsure{A}}$ est une algèbre universellement régulière sur
$k$ (cf 2.6.).

En effet, les conditions (i) et (ii) étant invariantes par changement
de $B$ en $\widehat{B}$, on est ramené au cas où $B$ est complet, où cela est contenu
dans \inserted{4.}11. \inserted{resp. \unsure{3.12.|4.12.}} compte tenu que pour $B_0$, formellement simple = universellement
régulier en vertu de \inserted{3.}6.

Du point de vue pratique, les résultats du présent numéro consistent
essentiellement en \inserted{4.}13., \deleted{l'existence}\deleted{et} l'\uline{unicité} \deleted{de $B$} (moyennant les conditions
de \inserted{4.}13.) du $B$ correspondant à un $B_0$ donné, sous réserve que $B$ soit
complet pour la topologie $\underline{r}(A)$-adique (cette \deleted{unici} unicité étant un
corollaire immédiat d'ailleurs, puisqu'on dispose pour $B$ des deux propriétés
complémentaires formellement simple + plat),
\inserted{et enfin l'\uline{existence} moyennant la séparabilité de $K/k$.}
A force de dévissage et
de généralité, cette substance n'apparait pas assez clairement, et la
terminologie ``algèbre de Cohen'' introduite concurremment à ``formellement
simple'' risque \deleted{peut-être} d'embrouiller \inserted{plutôt} les idées (d'autant plus que nous
n'utiliserons plus jamais que ``formellement simple'' ). Aussi le présent
numéro rendra peut-être plus service si on commence à énoncer simplement
\inserted{4.}13. en théorème, avec le corollaire bien senti précédent, et qu'on
les démontre simultanément en deux pages ou trois, \deleted{avec} en laissant de
côté tout le fatras anneaux admissibles, algèbres de Cohen etc. Commencer
par l'existence d'un $B$ satisfaisant à la fois (i) et (ii) si $K/k$ est
séparable, se ramener à ce cas pour \inserted{4.}13. par descente comme dans \inserted{4.}11.
prouver \inserted{4.}13. alors par comparaison du $B$-type avec le $B$ donné, ce qui
donne en même temps l'unicité, et un point c'est tout.

\margin{(garder cependant 4.1. \uuline{au \unsure{N°1}})
On peut signaler 4.6. en remarque, pour réserver l'avenir.}
\margin{\figure{\begin{tikzpicture}\draw (0,0)--(0,5);\draw (.06,0)--(.06,5);\end{tikzpicture}}}

\mspage{17}
```

**Work second reading** `K22-02` (GPT-6.2 Astra at reasoning effort max (ChatGPT Work), 18 Nov 2026):

```latex
\scanpage{18}
\mspage{32}

\uline{Corollaire} \deleted{3}\handwritten{4}.13. Soit $A\handwritten{\to}B$ un homomorphisme local d'anneaux locaux noethériens, on suppose $k(B)/k(A)$ à multiplicité radicielle finie (par exemple une extension séparable, ou de type fini)\handwritten{,} \deleted{Conditions}\handwritten{\inserted{\uline{ou} $\underline{r}(B)=\underline{r}(A)B$.}} On munit $A$ et $B$ de leurs topologies habituelles. Alors les conditions suivantes sont \deleted{\unsure{e|é}}équivalentes: (i) $B$ est formellement simple sur $A$ (ii) $B$ est plat sur $A$, et $B_{\unsure{o|0}}=B\otimes_A k\deleted{\unsure{A|(}}$ est une algèbre universellement régulière sur $k$ (cf 2.6.) .

En effet, les conditions (i) et (ii) étant invariantes par changement de $B$ en $\overset{\handwritten{\deleted{\unsure{\wedge|\sim}}\,\wedge}}{B}$, on est ramené au cas où $B$ est complet, où cela est contenu dans \deleted{3}\handwritten{4}.11. \handwritten{\inserted{resp. 3.12.}} compte tenu que pour $B_o$, formellement simple = \unsure{universellemen|universellement} régulier en vertu de \deleted{2}\handwritten{3}.6.

Du point de vue pratique, les résultats du présent numéro consistent essentiellement en \deleted{3}\handwritten{4}.13. \deleted{l'existence}, \deleted{et} l'\uline{unicité} \deleted{de $B$} (moyennant les conditions de \deleted{3}\handwritten{4}.13.) du $B$ correspondant à un $B_o$ donné, sous réserve que $B$ soit complet pour la topologie $\underline{r}(A)$-adique (cette \deleted{ceci} unicité étant un corollaire immédiat d'ailleurs, puisqu'on dispose \deleted{\unsure{p|b}}pour $B$ des deux propriétés complémentaires formellement simple + plat), \inserted{et enfin l'\uline{existence} moyennant la séparabilité de $K/k$ .} A force de dévissage et de généralité, cette substance n'apparait pas assez clairement, et la terminologie \textquotedbl{}algèbre de Cohen\textquotedbl{} introduite concur\deleted{\unsure{r|e}}emment à \textquotedbl{}formellement simple\textquotedbl{} risque \deleted{peut-être} d'embrouiller \handwritten{\inserted{plutôt}} les idées (d'autant plus que nous n'utiliserons plus jamais que \textquotedbl{}formellement simple\textquotedbl{} ). Aussi le présent numéro rendra peut-être plus service si on commence à énoncer simplement \deleted{3}\handwritten{4}.13. en théorème, avec le corollaire bien senti précédent, et qu'on
% slanted
\margin{\handwritten{(garder cependant 4.1. \uuline{au N\textsuperscript{o}1})}}lesdémontre simultanément en deux pages ou trois, \deleted{avec} en laissant de côté tout le fatras anneaux admissibles, algèbres de Cohen etc.
% slanted
\margin{\handwritten{On peut signaler 4.6. en remarque, pour réserver l'avenir.}}Commencer par l'existence d'un $B$ satisfaisant à la fois (i) et (ii) si $K/k$ est séparable, se ramener à ce cas pour \deleted{3}\handwritten{4}.13. par descente comme dans \deleted{3}\handwritten{4}.11. prouver \deleted{3}\handwritten{4}.13. alors par comparaison du $B$-type avec le $B$ donné, ce qui donne en même temps l'unicité, et un point c'est tout.
% archive sheet number: 17
```

**Witness H** (`batch-01.fr.tex`):

```latex
\page{17}\note{sa page 32}

\textbf{Corollaire 3.13.} Soit $A \to B$ un homomorphisme local d'anneaux
locaux nœthériens, on suppose $k(B)/k(A)$ à multiplicité radicielle finie
(par exemple une extension séparable, ou de type fini), \add{ou
$r(B) = r(A)B$.} \struck{Conditions} On munit $A$ et $B$ de leurs topologies
habituelles. Alors les conditions suivantes sont équivalentes : (i) $B$ est
formellement simple sur $A$ (ii) $B$ est plat sur $A$, et
$B_0 = B \otimes_A k$ est une algèbre universellement régulière sur $k$
(cf 2.6.).

En effet, les conditions (i) et (ii) étant invariantes par changement de $B$
en $\hat{B}$, on est ramené au cas où $B$ est complet, où cela est contenu
dans 3.11. \add{resp.\ 2.12.} compte tenu que pour $B_0$, formellement simple
$=$ universellement régulier en vertu de \struck{3}\add{2}.6.

Du point de vue pratique, les résultats du présent numéro consistent
essentiellement en 3.13., \struck{et l'existence} l'unicité \struck{de B}
(moyennant les conditions de 3.13.) du $B$ correspondant à un $B_0$ donné,
sous réserve que $B$ soit complet pour la topologie $r(A)$-adique (cette
\struck{\ill{}} unicité étant un corollaire immédiat d'ailleurs, puisqu'on
dispose pour $B$ des deux propriétés complémentaires formellement simple $+$
plat), \add{et enfin l'existence moyennant la séparabilité de $K/k$.} À force
de dévissage et de généralité, cette substance n'apparait pas assez
clairement, et la terminologie ``algèbre de Cohen'' introduite concurremment à
``formellement simple'' risque \struck{\ill{}} \add{plutôt} d'embrouiller les
idées (d'autant plus que nous n'utiliserons plus jamais que ``formellement
simple''). Aussi le présent numéro rendra peut-être plus service si on
commence à énoncer simplement 3.13. en théorème, avec le corollaire bien senti
précédent, et qu'on les démontre simultanément en deux pages ou trois,
\struck{avec} en laissant de côté tout le fatras anneaux admissibles, algèbres
de Cohen etc. Commencer par l'existence d'un $B$ satisfaisant à la fois (i) et
(ii) si $K/k$ est séparable, se ramener à ce cas pour 3.13. par descente comme
dans 3.11. prouver 3.13. alors par comparaison du $B$-type avec le $B$ donné,
ce qui donne en même temps l'unicité, et un point c'est tout.

\marginal{(garder cependant \uncertain{4.1.} au Nº3. On peut signaler
\uncertain{4.6.} en remarque, pour réserver l'avenir.)}
\note{les deux renvois de la note marginale ont leur premier chiffre repassé,
comme les numéros du tapuscrit.}
\note{écrit verticalement dans la marge de gauche, sur quatre lignes, en
regard du dernier alinéa.}

\section{Questions ouvertes}

\note{Le feuillet 18 est une couverture : une feuille par ailleurs nue,
portant en haut à droite, de sa main, le seul mot « Questions ». Il ne reçoit
pas de \texttt{page} ; les deux feuillets manuscrits qu'il
enveloppe suivent. Ceux-ci sont d'une écriture rapide et fine, et la prose de
liaison ne se laisse lire qu'en partie : ce qui suit garde les énoncés et
laisse \ill{} partout où la feuille ne porte pas de lecture sûre.}
```

## cote 22, scan 19 (cited by 7 entries)

**Pro first pass** `MPL_22+23_002-016` (GPT-6 Astra (ChatGPT Pro mode), 16 Nov 2026):

```latex
\scanpage{19}

Questions

\mspage{18}
```

**Work second reading** `K22-02` (GPT-6.2 Astra at reasoning effort max (ChatGPT Work), 18 Nov 2026):

```latex
\scanpage{19}

\unsure{Questions|Question}
% archive sheet number: 18
```

## cote 22, scan 20 (cited by 10 entries)

**Pro first pass** `MPL_22+23_002-016` (GPT-6 Astra (ChatGPT Pro mode), 16 Nov 2026):

```latex
\scanpage{20}

Questions ouvertes

1) Soit $A$ algèbre locale noethérienne sur $k$. Est-il vrai
que $A$ form$^t$ simple sur $k$ si $A$ est univ$^t$ régulière
sur $k$ [i.e., pour hom local $A\longrightarrow B$ d'anneaux
locaux noethériens, équivalence entre ``f$^t$ simple''
et ``univ. régulière'' \deleted{\unsure{sur}} sur $A$].

\margin{\unsure{OK}}

2) Soit $A$ algèbre locale noethérienne sur $k$, f$^t$
simple sur $k$ (pour sa topologie habituelle).
Est-il vrai que $A$ est f$^t$ simple pour sa topologie
discrète? \unsure{Cas où} $A$ est complet ? (Il est
possible que la réponse soit affirmative en
car $p>0$, négative en car 0). -- On peut
généraliser \unsure{au cas où on}. $A$ plat sur $\Lambda$,
\inserted{$A$ et} $\Lambda$ anneaux noethériens: si les
\unsure{localisés} de $A$ sont f$^t$ simples sur ceux de $\Lambda$
pour leur topologie habituelle, $A$ est-il f$^t$.
simple sur $\Lambda$ pour sa top. discrète.

\margin{Faux, \unsure{cf.} \unsure{valuation}
\unsure{$\checkmark$} \uline{\unsure{vrai;}} \uline{\unsure{possibilité}}
Peut-être \unsure{y a-t-il} \unsure{de l'espoir} \unsure{si on}
\unsure{on passe aux} extensions de $B$ \unsure{h.}
\deleted{\unsure{qui}} \unsure{qui sont}
en \unsure{anneaux} \uline{$\unsure{VA}$}
\unsure{(anneaux} à \unsure{résidu fini}).
\unsure{pas} \unsure{universelle} en \unsure{type fini}.}
\margin{\figure{\begin{tikzpicture}\draw[->] (1.6,.2)--(0,0);\draw (0,.05)--(.3,.15);\end{tikzpicture}}}

3) $B$ \deleted{\unsure{libre}} \inserted{plat.} sur $A$, $A$ et $B$ noethériens.
Lieu des $\unsure{p}$ de $\operatorname{Spec}B$ dont l'anneau
local dans la fibre sur $\operatorname{Spec}A$ est f$^t$ simple
sur le corps résiduel en $A$, est-il ouvert?
\deleted{[NB. \unsure{Même}} (Si $B$ n'est pas plat sur $A$,

\mspage{19}
```

**Work second reading** `K22-02` (GPT-6.2 Astra at reasoning effort max (ChatGPT Work), 18 Nov 2026):

```latex
\scanpage{20}

Questions ouvertes

1) Soit $A$ algèbre locale noethérienne sur $k$. Est-il vrai que $A$ form\textsuperscript{t} simple sur $k$ si $A$ est \unsure{univ\textsuperscript{t}|univ\textsuperscript{st}|univers\textsuperscript{t}} régulier sur $k$ \margin{OK} [d'où, pour hom. local $A\longrightarrow B$ d'anneaux locaux noethériens, équivalence entre ``f\textsuperscript{t} simple'' et ``univ\textsuperscript{t} régulier'' \deleted{\unsure{sur}} sur $A$].

2) Soit $A$ algèbre locale noethérienne sur $k$, f\textsuperscript{t} simple sur $k$ (pour sa topologie habituelle). Est-il vrai que $A$ est f\textsuperscript{t} simple pour sa topologie discrète? Cas où $A$ est complète? (Il est possible que la réponse soit affirmative en car $p>0$, négative en car $0$).

% slanted
\margin{Faux, cf \unsure{valuation|valuations}} \margin{\uline{Je suis} \uline{pessimiste}}

- On peut généraliser au cas où \unsure{on.|on a} $A$ plat sur $\Lambda$, $A$ et $\Lambda$ anneaux noethériens: si les localisés de $A$ sont f\textsuperscript{t} simples sur \deleted{\unsure{ceux}} $\Lambda$ pour leur topologie habituelle, $A$ est-il ft. simple sur $\Lambda$ pour sa top. discrète.

% slanted
\margin{Peut-être y-a-t-il de l'espoir si on se borne aux extensions de \unsure{B/k|B.k.|B} \deleted{\unsure{à|en} \unsure{qui}} qui sont des anneaux \uline{\unsure{excell\textsuperscript{ts}|exlg}} (\unsure{ann\textsuperscript{x}|anneaux} à \unsure{noyaux|noyau} des modules de type fini) \ldots}

3) $B$ \deleted{\unsure{Alg|plt|plat}} \inserted{\unsure{plate|plat.}} sur $A$, $A$ et $B$ noethériens. Lieu des \unsure{pt|pts} de $\operatorname{Spec}\unsure{B|D}$ dont l'anneau local dans \unsure{la|sa} fibre sur $\operatorname{Spec} A$ est f\textsuperscript{t} simple sur le corps résiduel en $A$, est-il ouvert? \deleted{[N.B: \unsure{même au|Lieu en}} [Si $B$ n'est pas plat sur $A$,
% archive sheet number: 19
```

**Witness H** (`batch-01.fr.tex`):

```latex
\page{19}

Questions ouvertes

\begin{enumerate}
  \item[1)] Soit $A$ algèbre locale nœthérienne sur $k$. Est-il vrai
    que $A$ formellement simple sur $k$ si $A$ est univers\supplied{ellement}
    régulière sur $k$ [déf., pour hom.\ local $A \to B$ d'anneaux locaux
    nœthériens, équivalence entre « ft simple » et « univers\supplied{ellement}
    régulier » sur $A$ ].
  \item[2)] Soit $A$ algèbre locale nœthérienne sur $k$, ft
    simple sur $k$ (pour sa topologie habituelle).
    Est-il vrai que $A$ est ft simple pour sa topologie
    discrète ? Ou : $A$ est complète ? (Il est possible que la
    \uncertain{réponse} soit affirmative en \uncertain{car.\ $p > 0$},
    négative en car.\ $0$). --- On peut \uncertain{se demander} \ill{}
    \uncertain{aussi} : $A$ plat sur $\Lambda$, $A$ et $\Lambda$ anneaux
    nœthériens : si les \ill{} de $A$ sont ft simples sur ceux de $\Lambda$
    pour leurs topologies habituelles, $A$ est-il ft.\ simple sur $\Lambda$
    pour sa top.\ discrète.
  \item[3)] $B$ \add{\uncertain{de t.\ f.}} plat sur $A$, $A$ et $B$
    nœthériens. L'ensemble des \uncertain{pts} de $\mathrm{Spec}\,B$ dans
    l'anneau local desquels la fibre sur $\mathrm{Spec}\,A$ est ft simple
    sur le corps résiduel de $A$, est-il ouvert ?
    \struck{\ill{}} [ Si $B$ n'est pas plat sur $A$,
\end{enumerate}
\marginal{OK}
\note{en marge de gauche, en regard de la question 1).}

\marginal{\ill{}}
\note{un long bloc de sa main court en oblique, de bas en haut, dans toute la
marge de gauche du feuillet, sur une douzaine de lignes ; c'est un ajout
postérieur au corps de la page. Il n'a pas pu être lu. On y distingue
seulement, dans les premières lignes, « Faut-il \ldots\ valuation
\uncertain{discrète} \ldots\ vraiment \uncertain{nécessaire} ? Peut-être
\ldots\ », puis plus bas un $B$ isolé et une formule « $\Lambda = VA$ ».}
```

## cote 22, scan 21 (cited by 9 entries)

**Pro first pass** `MPL_22+23_002-016` (GPT-6 Astra (ChatGPT Pro mode), 16 Nov 2026):

```latex
\scanpage{21}

\unsure{l'ens|lieu} des $p$ de $\operatorname{Spec}A$ où $B$ l'est est-il
ouvert? ]. Il \unsure{faudra|faut} supposer que $A$ et $B$
sont des ``bons anneaux''.

En particulier, l'\unsure{énoncé précédent} est-il
\deleted{$A,B$ \unsure{sont locaux}, $A\unsure{\longrightarrow|\text{---}}B$}
stable par localisation ?
\margin{Cf IV \unsure{2.10.1|2.40.1}}
\figure{\begin{tikzpicture}\draw (0,0)--(.65,0) to[out=0,in=-90] (.8,.15)--(.8,.6)--(4,.6);\end{tikzpicture}}

\margin{On est ramené au cas où $A$ est \uline{intègre}; à \unsure{prouver}
(a) si $x\in U$, \unsure{pour} \unsure{tte} \unsure{générisation}
\unsure{au dessus de} $\unsure{x}$, $\unsure{x\longrightarrow y}$, $y\in U$.
(b) \deleted{Si $x\in U$, \unsure{son} \unsure{adhérence} \unsure{est} \unsure{contenue dans}}
\deleted{Si $x\in U$} $\unsure{U}$ est \unsure{dense en} $\unsure{\overline{\{y\}}}$,
\unsure{alors} \unsure{il} contient un \unsure{voisinage} de $\unsure{x}$
\unsure{dans} $\unsure{\overline{\{x\}}}$ \unsure{qui est dans} $U$.}
\margin{\figure{\begin{tikzpicture}\draw[<->] (0,1)--(-.05,.5)--(0,0);\end{tikzpicture}}}

Le cas d'extensions résiduelles finies.
cf critère jacobien de Nagata et
th. de Nagata pour une algèbre locale noeth
complète sur un \uline{corps}.

OK. en caractéristique 0 pour les \uline{bons
anneaux}, grâce à la \uline{résolution des
singularités}.

\margin{Pour (b), dans le cas d'un bon anneau,
on est ramené au cas où $B$ est \uline{régulier}. \unsure{Alors},
\unsure{a)} \unsure{reste une} \unsure{hypothèse de}
la résolution des singularités, et
\unsure{pour a)} \unsure{se résout par} \uline{l'affirmative}.
\unsure{En réalité}, il se résout par l'affirmative
pour les bons anneaux, \uline{en \unsure{caractéristique} \unsure{entière|quelconque}},
\uline{\unsure{pourvu qu'on sache}}
\unsure{que le} \unsure{lieu où} un $f$ sur $X$
est \unsure{géométriquement} \unsure{régulier}
est \uline{ouvert} (au \unsure{moins} \unsure{au-dessus de} $k$).}

4) $A\unsure{\text{---}|\longrightarrow}B$ hom d'anneaux
noeth. Lieu des $\unsure{q|p}$ de
$\operatorname{Spec}B$ en lesquels $B$ est plat
sur $A$ est-il ouvert?
[Ceci revient à vérifier
que pour $\forall p\in\operatorname{Spec}A$,
et $\forall q$ au dessus de $p$,
maximal parmi \unsure{ceux-là|ceux-ci},
posant $A'=A/p$, $B'=B/q$
\inserted{$A'\subset B'$ intègres}
[\unsure{donc} $B'\otimes_{A'}K'$ \unsure{est un corps}]
$\exists$ un ouvert non vide de $\operatorname{Spec}B'$
en \unsure{lesquels|lequel} $B'$ est plat sur $A'$.
\figure{\begin{tikzpicture}\draw (0,.2) to[out=110,in=180] (.25,.42)--(3,.45) to[out=0,in=50] (3.1,.1) to[out=230,in=-20] (2.6,-.04)--(.3,-.05) to[out=180,in=-110] (0,.2);\end{tikzpicture}}

\begin{center}
M. DUFOUR\\
VARITYPISTE\\
131, RUE LECOURBE\\
PARIS XV$^{\mathrm e}$\\
\figure{\begin{tikzpicture}\fill (0,0) rectangle (.12,.12);\end{tikzpicture}}\\
C. C. P. Paris \unsure{14.143.34|14.143-34}\\
R. M. 140.029
\end{center}

\mspage{20}
```

**Work second reading** `K22-02` (GPT-6.2 Astra at reasoning effort max (ChatGPT Work), 18 Nov 2026):

```latex
\scanpage{21}

l'ens des pts de $\operatorname{Spec} B$ où $B$ l'est est-il ouvert ?]. Il faut supposer que $A$ et $B$ sont des ``bons anneaux''. 

Tout d'abord, l'ens \unsure{précédent} est il \deleted{si $A$, $B$ sont locaux, $A\to B$ \unsure{local}} stable par localisation? \inserted{Cf IV 2.10.1}

% slanted
\margin{Ce qui est connu au cas où $A$ est \uline{intègre}, \unsure{primitivement|primitivem\textsuperscript{t}|prenons} \unsure{ou|que} (a) si $x\in U$, son $\unsure{Hc|H_0}$ primitive \unsure{au dessus du|au-dessus du} pt gén. de $y$ est $\in U$ \deleted{(b) Si $x\in U$, son \unsure{et constituant|il est} \unsure{gén.} Soit $x\in U$} (b) Soit $x$ le pt gén. de $y$, alors il existe un voisinage de $x$ ds $\bar{x}$ \deleted{qui} est dans $U$.}

% slanted
\diagram{\begin{tikzcd}[ampersand replacement=\&] x \arrow[d] \\ y \end{tikzcd}}

Cas d'extensions résiduelles finies. Aussi critère jacobien de Nagata et Th. de Nagata pour une algèbre locale noeth complète sur un \uline{corps}.

OK. en caractéristique $0$ pour les \uline{bons anneaux}, grâce à \uline{la résolution des singularités}.

% slanted
\margin{Pour (b), dans le cas d'un bon anneau, on est ramené au cas où $B$ est \uline{régulier}. Dans ce cas-ci on dispose de la résolution des singularités, et alors on le résout par l'\uline{affirmative}. \unsure{Concl.|Com.} : \unsure{le|b}, il se résout par l'affirmative pour les bons anneaux, \uline{en car. résiduelle nulle}, \deleted{\unsure{car cela}} \uline{pourvu qu'on sache} que le lieu où une $f$ sur $X$ est transversalement régulière est \uline{ouvert} (ou au moins constructible).}

4) $A\unsure{-|\to}B$ hom d'anneaux noeth. Lieu des pts de $\operatorname{Spec} B$ en lesquels $B$ est plat sur $A$ est-il ouvert? [\unsure{Ce est|Ceci est} \unsure{inconnu|inconnu.}: vérifier que pour $\forall\,\mathfrak{p}\in\operatorname{Spec} A$, et $\forall$ pt $\mathfrak{q}$ au dessus de $\mathfrak{p}$, maximal pour \unsure{ceci|cela}, posant $A'=A/\mathfrak{p}$, $B'=B/\mathfrak{q}$ \inserted{$A'\subset B'$, intègres} [dans $B'\otimes_{A'}K'$ \unsure{-|- -}] $\exists$ un ouvert non vide de $\operatorname{Spec} B'$ sur lequel $B'$ est plat sur $A'$.

% letterhead
M. DUFOUR\\
VARITYPISTE\\
131, RUE LECOURBE\\
PARIS XV\textsuperscript{e}\\
$\blacksquare$\\
C. C. P. Paris 14.143-34\\
R. M. 140.029
% archive sheet number: 20
```

**Witness H** (`batch-01.fr.tex`):

```latex
\page{20}

l'ensemble des \uncertain{pts} de $\mathrm{Spec}\,B$ où $B$ \ill{}
est-il ouvert ? ]. Il faudr\supplied{ait} supposer que $A$ et $B$
sont des « bons anneaux ».

\struck{l'ensemble \ill{} est \ill{} si $A$, $B$ sont locaux, $A \to B$}
localisation ?
\marginal{Cf IV 2.10.1}
\note{la ligne barrée et la mention « Cf IV 2.10.1 » sont réunies par un
crochet tracé à l'encre ; c'est le seul renvoi précis à un autre chapitre que
portent ces deux feuillets.}

\ill{} d'extension résiduelle finie.

\ill{} critère jacobien de Nagata et Th.\ de Nagata pour une algèbre locale
nœth.\ complète sur un \emph{corps}.

OK.\ en caractéristique $0$ pour les \emph{bons anneaux}, grâce à :
\emph{la résolution des singularités}.

\begin{enumerate}
  \item[4)] $A \to B$ hom.\ d'anneaux nœth. L'ensemble des \uncertain{pts}
    de $\mathrm{Spec}\,B$ en lesquels $B$ \ill{} sur $A$ est-il ouvert ?
    [ \ill{} : supposons que pour tout $\mathfrak{p} \in \mathrm{Spec}\,A$,
    et tout \ill{} au-dessus de $\mathfrak{p}$, \ill{} maximal pour \ill{},
    posant $A' = A_{\mathfrak{p}}$, $B' = B_{\mathfrak{P}}$ ($A' \subset B'$
    intègres) [donc $B \otimes_{A'} k'$] $\exists$ un ouvert non vide de
    $\mathrm{Spec}\,B'$ en lesquels $B'$ est plat sur $A'$. ]
\end{enumerate}
\note{la question 4) est tracée dans la moitié droite du feuillet, en colonne
étroite, et ses dernières lignes chevauchent l'en-tête imprimé du papier ;
elles ne se lisent que par fragments. L'indice de $B_{\mathfrak{P}}$ est
repassé et douteux.}

\marginal{\ill{}}
\note{comme au feuillet précédent, un bloc écrit en oblique occupe toute la
marge de gauche, plus dense encore : une vingtaine de lignes, avec au moins
trois renvois numérotés (1), (2), (3) et des passages soulignés. Il n'a pas pu
être lu.}

\end{document}
```

## cote 22, scan 22 (cited by 8 entries)

**Pro first pass** `MPL_22+23_002-016` (GPT-6 Astra (ChatGPT Pro mode), 16 Nov 2026):

```latex
\scanpage{22}

\deleted{M. DUFOUR\\
VARITYPISTE\\
131, RUE LECOURBE\\
PARIS XV$^{\mathrm e}$\\
\figure{\begin{tikzpicture}\fill (0,0) rectangle (.12,.12);\end{tikzpicture}}\\
C. C. P. Paris 14.143-34\\
R. M. 140.029}
\figure{\begin{tikzpicture}\draw (0,1.6)--(.7,0);\draw (1.1,1.5)--(1.7,.65);\draw (1.8,1.5)--(1.95,1.05);\end{tikzpicture}}

$A$ algèbre \inserted{locale noeth. complète,}
f$^t$ simple sur $k$ pour sa
topologie habituelle, alors $A$
est-il f$^t$ simple sur $\unsure{K|k}$ pour sa
topologie discrète ???.
\figure{\begin{tikzpicture}\draw (0,0)--(0,.5) to[out=90,in=180] (.2,.7)--(2.6,.7) to[out=0,in=10] (2.55,.8);\end{tikzpicture}}

\deleted{1°) Cas $p>0$}
On se \unsure{ramènera|ramène} au cas où $k$ est le
corps premier (plus gén. un corps \uline{parfait})
\inserted{\unsure{ou même} où $K/k$ est séparable, $K$ \unsure{le c. résiduel}}

\deleted{\unsure{1°)} \uline{Cas $\unsure{p>0|p=0}$}}
\unsure{Alors on a.}
$A\simeq K[[t_1,\ldots,t_n]]$, $K/k$
une extension \uline{séparable}.
\deleted{$\unsure{K}$ est form$^t$ simple sur
$k$, il suffira que $A$ le soit sur $K$.}
\deleted{$\unsure{K}$}

\unsure{1°)} \uline{Cas $p>0$}

Supposons que $K/k$ a une $p$-base
\uline{finie}, i.e.
\margin{$\Omega_{K/k}$ est fini sur $K$.}

\deleted{Si $K$ est parfait, alors}
\deleted{Alors $A$ est un anneau}

\deleted{$A$, ayant une $p$-base \inserted{$(t_1,\ldots,t_n)$},
sur $K$, est f$^t$ simple sur $K$.}
\deleted{\unsure{ayant une $p$-base},}
\deleted{\unsure{Il suffit} de connaître une
$p$-base de $A$ sur $k$. Il en existe si
$K$ est fini sur $K^p$, on prend une $p$-base
$(x_1\unsure{\text{--}|,}\,x_{\unsure{m|n}})$ de $K$, et y adjoint $t_1,\ldots,t_n$.}
\figure{\begin{tikzpicture}[x=.5cm,y=.5cm]
\draw (0,3.1)--(3.4,3.2) to[out=-40,in=180] (4.5,2.7)--(8.2,2.8);
\draw (0,3)--(.15,2)--(1.8,2) to[out=0,in=-90] (2,2.2)--(2,2.8)--(5,2.65);
\draw (.4,2.7) to[out=-65,in=195] (2.4,.8) to[out=15,in=-125] (3.4,3.4) to[out=55,in=160] (4.3,2.75);
\draw (3.8,2.6) to[out=-65,in=195] (5.3,.8) to[out=15,in=-130] (6.5,3.25);
\draw (6.5,2.7) to[out=-100,in=130] (7.6,.7);
\draw (.15,2)--(.3,.2) to[out=-80,in=180] (.7,0)--(8.3,.1);
\end{tikzpicture}}

En la complétant par les $t_i$, on trouve
une $p$-base de $A$ sur $k$, et $K(A^p)=K\otimes_{K^p}A^p$.
[cf ``\unsure{Diff.}'']. Donc dans ce cas \unsure{on gagne}.

\mspage{21}
```

**Work second reading** `K22-02` (GPT-6.2 Astra at reasoning effort max (ChatGPT Work), 18 Nov 2026):

```latex
\scanpage{22}

% letterhead
\deleted{M. DUFOUR\\
VARITYPISTE\\
131, RUE LECOURBE\\
PARIS XV\textsuperscript{e}\\
$\blacksquare$\\
C. C. P. Paris 14.143-34\\
R. M. 140.029}

$A$ algèbre \inserted{locale noeth. complète,} f\textsuperscript{t} simple sur $k$ pour sa topologie habituelle, alors $A$ est-il f\textsuperscript{t} simple sur $\deleted{\unsure{A|K}}k$ pour sa topologie discrète ???

\deleted{1\textsuperscript{o}) Cas $p>0$} \unsure{On va|On} examiner le cas où $k$ est le corps premier (plus gén. un corps \uline{parfait}), où \unsure{=|ou} où $K/k$ est séparable, $K/k$ l'ex. résiduelle

\deleted{1\textsuperscript{o}) \uline{Cas $p>0$}} Alors \unsure{on a|on}. $A\simeq K[[t_1,\ldots,t_n]]$, $K/k$ une extension \uline{séparable}. \deleted{$K$ est form\textsuperscript{t} simple sur $k$, il suffirait que $A$ le soit sur $K$.}

1\textsuperscript{o}) \uline{Cas $p>0$} \deleted{Alors $A$ est un anneau} \deleted{Si $K$ est parfait, alors} Supposons que $K/k$ ait une $p$-base \uline{finie}, i.e. \margin{$\Omega^{\unsure{1|\vphantom{1}}}_{K/k}$ est fini sur $K$.} \deleted{$A$, ayant une $p$-base \inserted{$(t_1,\ldots,t_n)$} sur $K$, est f\textsuperscript{t} simple sur $K$. \inserted{Comme $K$ est parfait,} il suffit de connaître une $p$-base de $A$ sur $k$. Il en existe si $K$ est fini sur $K^p$, on prend une $p$-base $(x_1\ldots x_n)$ de $K$, et y adjoint $t_1,\ldots,t_n$.} En la complétant par les $t_i$, on trouve une $p$-base de $A$ sur $k$, et $k(A^p)\simeq k\otimes_{k^p}A^p$. [cf ``Diff.'']. Donc dans ce cas on gagne.
% archive sheet number: 21
```

**Witness H** (`batch-02.fr.tex`):

```latex
\page{21}
\uncertain{loc. noeth. complets},
\note{écrit en interligne au-dessus de la première ligne, avec un trait qui
le fait entrer dans le crochet}
$A$ \ill{} [\,\struck{$A$} \uncertain{f. lisse} sur $k$ pour la topologie
habituelle, alors $A$ est-il \ill{} \uncertain{f. lisse} sur \struck{$A$}
pour la topologie discrète ???

1°) \emph{Cas $p > 0$}
\note{le $>$ est net ; le même cas revient plus bas comme 3°), et ce premier
titre paraît abandonné}
On se ramène au cas où $k$ est le corps premier \ill{} \ill{} un corps
\struck{\uncertain{parfait}}, \ill{} \ill{} \ill{} $K/k$ est séparable,
$K/k$ l'ex.\ considérée.

2°) \struck{\emph{Cas $p \geq 0$}} Alors on a $A \simeq K[[t_1,\dots,t_n]]$,
$K/k$ une extension séparable. \struck{$K$ \ill{} \uncertain{formellement
lisse} sur $k$, il suffit que $A$ le soit sur $K$.}

Supposons que $K/k$ \uncertain{ait} une p-base
\struck{si $K$ est parfait, alors}

3°) \emph{Cas $p > 0$}. \struck{Alors $A$ est un \ill{}}
\uncertain{fini}, i.e.\
\marginal{$\Omega_{K/k}$ \uncertain{est} fini sur $K$.}
$A$, ayant une p-base $(t_1,\dots,t_n)$ sur $K$, \ill{} \struck{$A$ \ill{}}
\struck{\uncertain{choisissons} \ill{} \ill{}} \ill{} \ill{} \ill{} sur $K$.
\note{le passage est remanié par des traits qui déplacent des groupes de mots ;
l'ordre retenu est celui que ces traits indiquent}
p-base de $A$ sur $k$. Il en \uncertain{existe} si
$K$ est fini sur $K^{p}$, on prend une p-base $(x_1,\dots,x_n)$ de $K$, et on
y ajoute $t_1,\dots,t_n$. \uncertain{Vu} la complétion pour les $t_i$, on
trouve une p-base de $A$ sur $k$, et $k(A^{p}) \simeq \uncertain{K}
\otimes_{K^{p}} A^{p}$.
\note{le terme après $\simeq$ est écrit par-dessus un autre et ne se lit pas
avec certitude}
[cf. « Diff »]. Donc dans ce cas \ill{} \ill{}
\note{le renvoi vise le feuillet de couverture « Différentielles » qui ouvre la
section suivante, quatre pages plus loin}
```

## cote 22, scan 23 (cited by 7 entries)

**Pro first pass** `MPL_22+23_002-016` (GPT-6 Astra (ChatGPT Pro mode), 16 Nov 2026):

```latex
\scanpage{23}

\deleted{\unsure{2°}}) \uline{Cas contraire}. Je suis pessimiste.

2°) Cas $p=0$. Par contre $k[[t]]$ sur $k$,
($k=\mathbb Q$, ou $k=\mathbb C\ldots$). Je présume que
si $\dim A\unsure{\geq|>}0$, $A$ n'est jamais \unsure{for}$^t$ simple
sur $k$ pour sa topologie discrète.

Dans les cas défavorables, je doute qu'il
y ait \unsure{un} ``\unsure{form}$^t$ simple contenant un corps
premier'' [si $k$ n'est pas alg. sur le sien].

$\Omega_k\otimes_k A\longrightarrow\Omega_A$
admet un inverse à gauche ?

\deleted{Supposons $k$ \unsure{le degré de} $\unsure{\Omega_k|\Omega^-_k}$}
\[
k=\mathbb Q\bigl((x_i)_{i\in I}\bigr)
\qquad \deleted{\unsure{k=\mathbb Q}}
\]
\[
A=k[[\unsure{t|u}]],\qquad
\Omega_k\otimes_k A\simeq A^{(I)}
\unsure{=}\deleted{\prod}\inserted{\unsure{\bigoplus_{i\in I}}}
A\,d_{/\mathbb Q}x_i,
\]
on cherche $A\unsure{\mathrel{\overset{D}{\text{---}}}|\xrightarrow{D}}\Omega_k\otimes_k A$, qui soit
donné sur $k$ par $D(x_i)=d_{/\mathbb Q}x_i$.
Or s'il y a un tel $D$, alors $Dt$ est combinaison lin.
finie de certains $d_{/\mathbb Q}x_i$, $i\in J$, et \unsure{remplaçant}
$\mathbb Q$ par $k_0=\mathbb Q\bigl((x_i)_{\unsure{i\in J}}\bigr)$,
on peut supposer que
$dt=0$.
\deleted{$D(\sum a_i t^i)=$}

\mspage{22}
```

**Work second reading** `K22-02` (GPT-6.2 Astra at reasoning effort max (ChatGPT Work), 18 Nov 2026):

```latex
\scanpage{23}

\deleted{2\textsuperscript{o}}) \uline{Cas contraire}. Je suis pessimiste.

2\textsuperscript{o}) Cas $p=0$: Par exemple $k[[t]]$ sur $k$, ($k=\mathbb{Q}$, ou $k=\mathbb{C}\ldots$). Je présume que si $\dim A>0$, $A$ n'est jamais f\unsure{or\textsuperscript{t}|orm\textsuperscript{t}} simple sur $k$ pour sa topologie discrète.

Dans les cas défavorables, je doute qu'il y ait \deleted{\unsure{un|encore}} ``form\textsuperscript{t} simple \unsure{relativem\textsuperscript{t}|relativement|naturellement} au corps premier'' [Si $k$ n'est pas alg. sur le dit].

\[ \Omega^1_k\otimes_k A\longrightarrow\Omega^1_A\quad \text{admet un inverse à gauche?} \]

\deleted{Supposons $k$ de \unsure{degré|degré de} $\Omega_k^{\unsure{-|1|\vphantom{1}}}$} $k=\deleted{\unsure{k_0|k}}\mathbb{Q}((x_i)_{i\in I}\deleted{\unsure{i\in|i}})$ \deleted{$k=\mathbb{Q}$}

$A=k[[t]]$, $\Omega^1_k\otimes_k A\simeq A^{(I)}=\deleted{\unsure{\sum_{i\in I}|\bigoplus_{i\in I}}}\unsure{\sum|\bigoplus|\prod_i} A\, d_{/\mathbb{Q}}x_i$, on cherche $A\overset{D}{\unsure{-|\longrightarrow}}\Omega^1_k\otimes_k A$, qui soit donné sur $k$ par $D(x_i)=d_{/\mathbb{Q}}x_i$. \deleted{\unsure{Or|Car}} s'il y a une telle $D$, alors $D(t)$ est combinaison lin. finie de certains $d_{/\mathbb{Q}}x_i$, $i\in J$, et remplaçant $\mathbb{Q}$ par $k_0=\mathbb{Q}\cdot((x_i)_{i\in J})\deleted{\unsure{q|k}}$, on peut supposer \unsure{après|alors|que} $dt=0$. \deleted{$D\bigl(\sum a_it^i\bigr)=$}
% archive sheet number: 22
```

**Witness H** (`batch-02.fr.tex`):

```latex
\page{22}
\struck{3°)} 2°) \emph{Cas contraire}. Je suis pessimiste.

1°) \emph{Cas $p = 0$}. \ill{} \ill{} $k[[t]]$ sur $k$,
($k = \mathbf{Q}$, ou $k = \mathbf{C} \dots$). Je présume que si
dim $A > 0$, $A$ n'est jamais formellement lisse sur $k$ pour la topologie
discrète.

Donc, dans les cas défavorables, je doute qu'il y ait \struck{\ill{}}
« \ill{} naturellement un corps premier » [Cf.\ le \ill{} \ill{} \ill{}
\uncertain{top.}\ sur le dit].

\[
  \Omega^{1}_{k} \otimes_{k} A \longrightarrow \Omega^{1}_{A}
\]
\uncertain{devrait} être un \ill{} ? \uncertain{pourquoi} ?

\emph{Supposons} \struck{$k$ \ill{} \ill{} $\Omega_{k}$} \quad
$k = \mathbf{Q}((x_i))_{i \in I}$ \quad \struck{$k_0 = \mathbf{Q}$}

$A = k[[t]]$, \quad
$\Omega_{k} \otimes_{k} A \simeq A^{(I)} \subsetneq \prod_{i} A\, d_{/\mathbf{Q}} x_i$,
\note{le symbole de produit est écrit par-dessus une rature}
on \uncertain{cherche}
$A \xrightarrow{\;D\;} \Omega_{k} \otimes_{k} A$, qui soit
donnée sur $k$ par
\[
  D(x_i) = d_{/\mathbf{Q}}\, x_i .
\]
\uncertain{Or} s'il y a une telle $D$, alors $D(t)$ est une combinaison
linéaire finie de certains $d_{/\mathbf{Q}}\, x_i$, $i \in J$, et remplaçant
$\mathbf{Q}$ par $k_0 = \mathbf{Q}((x_i : i \in J))$, on peut supposer que
$dt = 0$. \struck{$D(\sum a_i t^{i}) =$}
```

## cote 22, scan 24 (cited by 7 entries)

**Pro first pass** `MPL_22+23_002-016` (GPT-6 Astra (ChatGPT Pro mode), 16 Nov 2026):

```latex
\scanpage{24}

\uline{Proposition}. Soient $k$ un corps, $K$ une extension
telle que $\Omega_{K/k}$ soit de dim infinie sur
$K$, et $A\inserted{=K[[t_1,\ldots,t_n]]}$ une algèbre de séries formelles
sur $K$, avec $n>0$. Alors $A$, muni de sa
topologie \uline{discrète}, n'est pas f$^t$ simple sur $K$
\unsure{relativement} à $k$, et à fortiori n'est pas f$^t$ simple sur $k$.
\margin{\figure{\begin{tikzpicture}\draw (0,2.7) to[out=-90,in=105] (.3,0);\end{tikzpicture}}}

Il faut prouver que l'hom
\[
\Omega_{K/k}\otimes_K A\unsure{\text{---}|\longrightarrow}\Omega_{A/k}
\]
n'a pas d'inverse à gauche, i.e. qu'il
n'existe pas de dérivation
\[
D:A\unsure{\text{---}|\longrightarrow}\Omega_{K/k}\otimes_K A
\]
qui sur $K$ induise $d_{K/k}\otimes_K\unsure{1_A}$. Or
si on avait une telle $D$, alors les
$D(t_i)$ \unsure{seront|seraient} dans un sous-module
$V\otimes_K A$, $V\subset\Omega_{K/k}$ de dim finie, donc
il existerait une \unsure{coextension|extension} de \uline{type fini}
$k'$ de $k$, telle que les $Dt_i$ soient dans
$\operatorname{Im}\Omega_{k'/k}\otimes_{k'}A$, donc leurs images dans
$\Omega_{K/k'}\otimes_K A$ \unsure{seront|seraient} nulles. \unsure{Donc quitte}
à remplacer $k$ par $k'$, [ce qui
ne change pas \unsure{l'hyp. !}] on peut supposer

\deleted{M. DUFOUR\\
VARITYPISTE\\
131, RUE LECOURBE\\
PARIS XV$^{\mathrm e}$\\
\figure{\begin{tikzpicture}\fill (0,0) rectangle (.12,.12);\end{tikzpicture}}\\
C. C. P. Paris 14.143-34\\
R. M. 140.029}
\figure{\begin{tikzpicture}\draw (0,2.4)--(.85,0);\draw (.8,2.4)--(1.5,.3);\end{tikzpicture}}

\mspage{23}
```

**Work second reading** `K22-02` (GPT-6.2 Astra at reasoning effort max (ChatGPT Work), 18 Nov 2026):

```latex
\scanpage{24}

\uline{Proposition}. Soient $k$ un corps, $K$ une extension telle que $\Omega^{\unsure{1|\vphantom{1}}}_{K/k}$ soit de dim\textsuperscript{n} infinie sur $K$, et $A\inserted{=K[[t_1,\ldots,t_n]]}$ une algèbre de séries formelles sur $K$, avec $n>0$. Alors $A$, muni de sa topologie \uline{discrète}, n'est pas f\textsuperscript{t} simple sur $K$ relativement à $k$, et à fortiori n'est pas f\textsuperscript{t} simple sur $\unsure{k|K}$.

Il faut prouver que l'hom

\[ \Omega^1_{K/k}\otimes_K A\unsure{-|\longrightarrow}\Omega^1_{A/k} \]

n'a pas d'inverse à gauche, i.e. qu'il n'existe pas de dérivation

\[ D:A\unsure{-|\longrightarrow}\Omega^1_{K/k}\otimes_K A \]

qui sur $K$ induise $d_{K/k}\otimes_K\deleted{\unsure{A|1}}1_{\unsure{A|A.}}$. Or

Si on avait une telle $D$, alors les $D(t_i)$ seraient dans un sous-module $V\otimes_K A$, $V\subset\Omega_{K/k}$ de dim finie, donc il existerait une extension de \uline{type fini} $k'$ de $k$, telle que les $Dt_i$ soient dans $\operatorname{Im}\Omega_{\unsure{K'|k'}/k}\otimes_{K'}A$, donc leurs images dans $\Omega_{K/k'}\otimes_K A$ seraient \unsure{nulle|nulles}. Donc [quitte à remplacer $k$ par $k'$, ce qui ne change pas l'hyp.:] on peut supposer

% letterhead
\deleted{M. DUFOUR\\
VARITYPISTE\\
131, RUE LECOURBE\\
PARIS XV\textsuperscript{e}\\
$\blacksquare$\\
C. C. P. Paris 14.143-34\\
R. M. 140.029}
% archive sheet number: 23
```

**Witness H** (`batch-02.fr.tex`):

```latex
\page{23}
\emph{Proposition.} Soient $k$ un corps, $K$ une extension telle que
$\Omega_{K/k}$ soit de dim.\ infinie sur $K$, et
$A$ \add{$= K[[t_1,\dots,t_n]]$} une \uncertain{algèbre} de séries formelles
sur $K$, avec $n > 0$. Alors $A$, muni de la topologie \emph{discrète},
n'\uncertain{est} pas \uncertain{f.\ lisse} sur $K$ relativement à $k$, et
a fortiori n'\uncertain{est} pas \uncertain{f.\ lisse} sur $k$.
\note{l'énoncé est marqué d'un trait vertical dans la marge gauche ; « infinie »
est net, et c'est bien l'hypothèse du contre-exemple de la page précédente,
$k = \mathbf{Q}((x_i))_{i \in I}$}

Je vais prouver que l'homomorphisme
\[
  \Omega_{K/k} \otimes_{K} A \longrightarrow \Omega_{A/k}
\]
n'a pas d'\uncertain{inverse} à gauche, i.e.\ qu'il n'existe pas de
dérivation
\[
  D : A \longrightarrow \Omega_{K/k} \otimes_{K} A
\]
qui sur $K$ induise $d_{K/k} \otimes_{K} A$. \struck{$A$} Or s'il existait
une telle $D$, alors les $D(t_i)$ seraient dans un \uncertain{sous-module}
$V \otimes_{K} A$, $V \subset \Omega_{K/k}$ de dim.\ finie, donc il
existerait \ill{} \ill{} de \emph{type fini} $K'$ de $k$, \uncertain{telle}
que les $D t_i$ soient dans \emph{Im}
$\Omega_{K'/k} \otimes_{K'} A$, donc \ill{} \struck{\ill{}}
$\Omega_{K/k} \otimes_{K} A$ \ill{} \ill{}. \struck{$D$ \ill{}}
\ill{} \ill{} $K'$ sur $k$ ; \ill{} \ill{} un \ill{} \ill{}
\uncertain{l'hypo.!}] — \ill{} \ill{}
```

## cote 22, scan 25 (cited by 7 entries)

**Pro first pass** `MPL_22+23_002-016` (GPT-6 Astra (ChatGPT Pro mode), 16 Nov 2026):

```latex
\scanpage{25}

les $Dt_i=0$. \deleted{\unsure{Alors}} Prenons une
\uline{base} de $\Omega_{K/k}$ sur $K$, \unsure{soit} $(\omega_i)_{i\in I}$,
donc $\Omega_{K/k}\otimes_K A\simeq A^{(I)}\subset A^I$. En tant
que dérivation dans $A^I$, $D$ est donnée
par ses composantes $D_i$, qui sont
\unsure{uniq}$^t$ déterminées
\[
D_i\Bigl(\sum_\lambda a_\lambda t^\lambda\Bigr)
=\sum_\lambda \unsure{d^i_{K/k}|d_{K/k}^{\,i}}(a_\lambda)t^\lambda
\]
Il reste à prouver qu'on peut trouver
des $f=\sum a_\lambda t^\lambda$ telles que les
\[
\bigl(D_i(\unsure{f|\varphi})\bigr)_{i\in I}\notin A^{(I)}.
\]
\deleted{Il suffit}
\inserted{Choisissons}
\deleted{pour ceci \unsure{que} \inserted{\unsure{pour avoir}} \unsure{les}
$D_i(a_\lambda)$ \unsure{pour} $\unsure{\forall}$}
\deleted{de \unsure{trouver}}
une \uline{suite infinie} $i_0,i_1,\ldots,i_n$
d'indices distincts de $I$, \deleted{telle que} pour $\unsure{\forall}$
\deleted{$D_{i_n}(a_n)\ne0$}
\unsure{n} il existe $a_n\in K$ tel que
\deleted{$\unsure{D_{i_n}(a_n)\ne0}$},
\deleted{\unsure{(ceci est possible}}
$d_{K/k}a_n^{\unsure{i_n}}\ne0$, il suffit alors de
prendre $f=\sum a_nt^n$. .\,.\,.\,.\,.

\mspage{24}
```

**Work second reading** `K22-02` (GPT-6.2 Astra at reasoning effort max (ChatGPT Work), 18 Nov 2026):

```latex
\scanpage{25}

les $Dt_i=0$. \deleted{\unsure{Donc|On}} Prenons une \uline{base} de $\Omega^1_{K/k}$ sur $K$, \unsure{ou soit|on en} $(\omega_i)_{i\in I}$ donc $\Omega^1_{K/k}\otimes_K A\simeq A^{(I)}\subset A^I$. En tant que dérivation dans $A^I$, $D$ est donnée par ses composantes $D_i$, qui sont uniquement déterminées

\[ D_{\unsure{i|\vphantom{i}}}\left(\sum_\lambda a_\lambda t^\lambda\right)=\sum_\lambda\deleted{\unsure{D|d|D_i}}d_{K/k}(a_\lambda)t^\lambda \]

Il reste à prouver qu'on peut trouver des $f=\unsure{\sum|(}a_\lambda t^\lambda$ telles que les $(D_i(f))_{i\in I}\notin A^{(I)}$. \deleted{Il suffit} \inserted{Choisissons} \deleted{pour ceci} \inserted{pour ceci} \deleted{que les $D_i(a_{\unsure{n|\lambda}})$ pour tt} \deleted{de trouver} une \uline{suite infinie} $i_0,i_1,\ldots i_n$ d'indices distincts de $I$, \deleted{tels que} pour tt $n$ il existe $a_n\in K$ tel que \deleted{$D_{i_n}(a_n)\ne0$} \deleted{$D_{\unsure{i_n|n}}(a_n)=0$}, \deleted{Or ceci est possible} $d_{K/k}\deleted{\unsure{a^n|a_n}}a_n\ne0$, il suffit alors de prendre $f=\sum a_n t^n$. \ldots\ldots
% archive sheet number: 24
```

**Witness H** (`batch-02.fr.tex`):

```latex
\page{24}
\uncertain{ou} $D t_i = 0$. \struck{\ill{}} Prenons une
\emph{base} de $\Omega_{K/k}$ sur $K$, \ill{} \ill{} $(\omega_i)_{i \in I}$,
donc $\Omega_{K/k} \otimes_{K} A = A^{(I)} \subset A^{I}$. En tant que
dérivation dans $A^{I}$, $D$ est donnée par ses composantes $D_i$, qui sont
uniquement déterminées
\[
  D_i\Big(\sum_{\lambda} a_{\lambda} t^{\lambda}\Big)
  \;=\; \sum_{\lambda} d_{K/k}(a_{\lambda})\, t^{\lambda} .
\]
\note{le $d_{K/k}$ du membre de droite est écrit par-dessus un $D_i$}

Je \uncertain{veux} \ill{} \ill{} qu'il y a \uncertain{un}
$f = \sum a_{\lambda} t^{\lambda}$ tel que les
$(D_i(f))_{i \in I} \notin A^{(I)}$.
\struck{Je \uncertain{suffit}} \add{Choisissons}
\struck{\ill{} \ill{} \ill{} $D_i(a_{\lambda})$ \uncertain{Prenons}
\ill{}} \struck{\ill{} \ill{}} une \emph{suite infinie}
$i_0, i_1, \dots, i_n, \dots$ d'éléments distincts de $I$,
\struck{telle que} \uncertain{pour tout} $n$,
\struck{$D_{i_n}(a_n) \neq 0$}
(il existe $a_n \in K$ tel que \struck{$D_{i_n}(a_n) \neq 0$,}
$d_{K/k}\, a_n \neq 0$), \struck{\uncertain{Ce} \ill{} est possible}
il suffit alors de prendre
\[
  f = \sum a_n t^{n} . \qquad \dots
\]
\note{le feuillet s'arrête sur cette construction : la suite du contre-exemple
n'est pas sur la page}

\section{Différentielles}
\note{le mot est de sa main, souligné, seul en haut à droite du feuillet 25,
autrement blanc : c'est une couverture pour ce qui suit, et c'est à elle que
renvoie le « cf. "Diff" » du feuillet 21. Le feuillet ne porte rien d'autre et
ne reçoit pas de \texttt{page}}
```

## cote 22, scan 26 (cited by 7 entries)

**Pro first pass** `MPL_22+23_002-016` (GPT-6 Astra (ChatGPT Pro mode), 16 Nov 2026):

```latex
\scanpage{26}

\deleted{Différentielles}

\mspage{25}
```

**Work second reading** `K22-02` (GPT-6.2 Astra at reasoning effort max (ChatGPT Work), 18 Nov 2026):

```latex
\scanpage{26}

\deleted{Différentielles}
% archive sheet number: 25
```

## cote 22, scan 27 (cited by 7 entries)

**Pro first pass** `MPL_22+23_002-016` (GPT-6 Astra (ChatGPT Pro mode), 16 Nov 2026):

```latex
\scanpage{27}

\uline{Remarque}. Soient
\diagram{\begin{tikzcd}[ampersand replacement=\&]
k \arrow[r] \arrow[d,dash] \& K \arrow[d,dash] \\
k'=k\cap K^p \arrow[r,dash] \& K^p
\end{tikzcd}}
alors deux éléments $\unsure{x},y$ de $k$ peuvent être
$p$-indépendants \inserted{dans $\unsure{k|K}$ sur}
\deleted{\unsure{sur $k$}} $k\cap K^p$, et non
\inserted{dans $K$} sur $K^p$,
i.e. $d_{k/k'}x$ et $d_{k/k'}y$ peuvent être lin. indépendants,
sans que $d_{K/K^p}x$ et $d_{K/K^p}y$ le soient.
\uline{à fortiori}, $\Omega^1_{k/k\cap K^p}\otimes_k K\to\Omega^1_K$
peut n'être pas injectif, ou \deleted{\unsure{encore}} ce qui revient
au même, il peut arriver que le noyau \inserted{$N_{K/k}$}
de $\Omega_k\otimes_k K\unsure{\text{---}|\to}\Omega_K$ ne soit pas engendré sur $K$
par les $dx\otimes1$ $(x\in k\cap K^p)$.
\inserted{\uline{\unsure{qui est} \unsure{évident.} \unsure{(donc}}}

\margin{$\Omega^1_{k\cap K^p/\unsure{k^p}}\otimes_{k\cap K^p}K
\to\Omega^1_k\otimes_k\unsure{K}\to\Omega^1_K$}
\margin{N.B. \deleted{\unsure{Alors}} (\unsure{l'existence|l'assertion}
\unsure{ci-dessus}) \deleted{\unsure{à déterminer}}
\unsure{revient} \deleted{\unsure{pour}} que $N_{K/k}$
\deleted{\unsure{peut}} \unsure{n'être} ``défini sur $k$'' !
On peut \unsure{prendre} un premier \unsure{exemple} où il est
de dim \uline{1} \unsure{déjà}.}
\figure{\begin{tikzpicture}[x=1cm,y=1cm]
\draw (0,0) .. controls (.4,.5) and (.8,-.15) .. (1.2,0)
.. controls (3,.2) and (7,-.25) .. (9.3,.05)
.. controls (10,.2) and (10.8,.1) .. (11,.65);
\draw (10.85,.62)--(11,.65)--(10.94,.49);
\draw (8.2,.4) .. controls (7.65,.8) and (7.9,1.15) .. (8.5,1.18)
--(10.25,1.31);
\end{tikzpicture}}

Voici un contre. Soit $\mathbb F$ le corps premier
[ou un corps parfait quelc.], \uuline{$x,y,a_i$}
\inserted{$(1\le i\le p-1)$} des indéterminées sur $\mathbb F$,
\unsure{on pose} \deleted{$\unsure{\beta=y-\alpha x}$}
\[
\deleted{K^p=\mathbb F(x^p,\unsure{y^p},\unsure{\alpha})
\qquad\text{donc}\quad K=\mathbb F(x,\unsure{y},\unsure{\alpha^{1/p}})}
\]
\deleted{$\unsure{k'}=$}
\[
\left\{\begin{aligned}
a_0&=y-\sum_1^{p-1}a_i x^i\\
a&=x^p
\end{aligned}\right.
\qquad \text{soit}\quad y=\sum_0^{p-1}a_i x^i
\]
\[
K^p=\mathbb F(a,a_0,\unsure{a_1,\ldots,a_{p-1}})
=\deleted{\mathbb F(\unsure{\alpha},x^p,y-\alpha x)}
\inserted{\mathbb F\Bigl(x^p,a_1,\ldots,a_{p-1},y-\sum_1^{p-1}a_i x^i\Bigr)}
\]
\[
\deleted{K=\mathbb F(\alpha^{1/p},x,(y-\alpha x)^{1/p})}
\qquad\text{i.e.}\quad K=\mathbb F(x,a_1^{1/p},\ldots,a_{p-1}^{1/p},(\text{''})^{1/p})
\]
\[
k=\mathbb F(x,y)
\]
\margin{NB $a$ et $(a_i)_{0\le i\le p-1}$ sont alg. ind. sur $\mathbb F$.}
\figure{\begin{tikzpicture}[x=1cm,y=1cm]
\draw (2.8,1.2) .. controls (3.1,1.2) and (2.9,.85) .. (3.12,.8)
.. controls (3.3,.75) and (3.1,.5) .. (3.2,.3)--(2.9,.25);
\draw (.9,.08)--(2.65,.35);
\end{tikzpicture}}
\margin{[N.B. $x,\unsure{z}\in K$, donc $y=\unsure{\alpha x+\beta}\in K$,
donc $\unsure{k}\subset K$}

\mspage{26}
```

**Work second reading** `K22-02` (GPT-6.2 Astra at reasoning effort max (ChatGPT Work), 18 Nov 2026):

```latex
\scanpage{27}

\uline{Remarque} Soient

\diagram{\begin{tikzcd}[ampersand replacement=\&] k \arrow[r,dash] \arrow[d,dash] \& K \arrow[d,dash] \\ k'=k\cap K^p \arrow[r,dash] \& K^p \end{tikzcd}}

alors deux éléments $\deleted{\unsure{z|x}}x,y$ de $k$ peuvent être p-indépendants \inserted{ds $K$ sur} \deleted{\unsure{pour $k$|sur $k$|parfait}} $k\cap K^p$, et non \inserted{dans $K$} sur $K^p$, i.e. $d_{k/k'}x$ et $d_{k/k'}y$ peuvent être lin. indépendants, sans que $d_{K\deleted{\unsure{/|1}}/K^p}x$ et $d_{K/K^p}y$ le soient; \uline{à fortiori}, $\Omega^1_{k/k\cap K^p}\otimes_k K\to\Omega^1_K$ peut ne être pas injectif, ou \deleted{\unsure{encore}} ce qui revient au =, il peut arriver que le noyau \inserted{$N_{K/k}$} de $\Omega^1_k\otimes_k K\unsure{-|\to}\Omega_K$ ne soit pas engendré sur $K$ par les $dx\otimes1$ \inserted{qu'il contient, (i.e. ceux où} $x\in k\cap K^p$).

\margin{$\Omega^1_{k\cap K^p/\unsure{-|\vphantom{k}}}\otimes_{k\cap K^p}K\to\Omega^1_k\otimes_k\deleted{\unsure{k|K}}K\to\Omega^1_K$}

% slanted
\margin{\uline{N.B.} \deleted{\unsure{Alors|Or}} l'existence de $x,y$ comme ci dessus \deleted{\unsure{n'est pas|n'est point}} signifie que $N_{K/k}$ ne \deleted{peut \unsure{être}} \unsure{être|peut être} ``défini sur $k$''! On peut prendre un exemple où il est de dim \uline{1}}

\unsure{et|or} Voici un exemple. Soient $\mathbb{F}$ le corps premier [ou un corps parfait quelconque], $\underline{\underline{x,y,a_i}}\inserted{(1\leq i\leq p-1)}$ \deleted{\unsure{des|deux}} indéterminées sur $\mathbb{F}$, on pose \deleted{$\beta=y-\alpha x$}

\[ \deleted{K^p=\mathbb{F}(x^p,y^p,\unsure{\beta|\beta/\alpha|\alpha})}\qquad\deleted{\text{d'où }K=\unsure{F|\mathbb F}(x,y^{\unsure{1/p|p|\vphantom{p}}},\beta^{1/p})} \]

\[ \deleted{K=}\quad \left\{\begin{aligned} a_0&=y-\sum_{1}^{p-1}a_ix^i\\ a&=x^p\end{aligned}\right. \qquad \text{d'où}\quad y=\sum_{0}^{p-1}\deleted{\unsure{x|a}}\unsure{a_i|a_i^p}x^i \]

\margin{N.B $a$ et les $a_i{}_{1\leq i\leq p-1}$ sont alg. ind. sur $\mathbb F$ \unsure{Alors|dans} \unsure{on|et}}

\[ \begin{aligned}
K^p&=\deleted{\unsure{K|F}}\mathbb{F}(a,a_0,\deleted{\unsure{\beta|a}},\ldots a_{p-1})=\deleted{\unsure{K|\mathbb F}(\alpha,x^p,y-\alpha x)}\\
&\inserted{\mathbb{F}\bigl(x^p,a_1,\ldots a_{p-1},y-\sum_1^{p-1}a_i x^i\bigr)}\\
&\deleted{K=\mathbb{F}(\alpha^{1/p},x,(y-\alpha x)^{1/p})}\quad \text{i.e. } K=\mathbb{F}(x,a_1^{1/p},\ldots a_{p-1}^{1/p},(\ )^{1/p})\\
& k=\mathbb F(x,y)
\end{aligned} \]

\margin{[N.B. $x,\unsure{z|y}\in K$, \unsure{donc|d'où|et} $y=\alpha x+\beta\in K$, donc $k\subset K$}
% archive sheet number: 26
```

**Witness H** (`batch-02.fr.tex`):

```latex
\page{26}
\emph{Remarque} \quad Soient

\begin{tikzcd}
k \arrow[r] \arrow[d, no head] & K \arrow[d, no head] \\
k' = k \cap K^{p} \arrow[r, no head] & K^{p}
\end{tikzcd}

\note{les deux traits verticaux et le trait du bas sont sans pointe sur le
feuillet ; seule la flèche du haut en porte une}

\ill{} deux éléments $x, y$ de $k$ peuvent être p-indépendants
\add{dans $K$ sur} \struck{\uncertain{parfait}} $k \cap K^{p}$, et non
(sur $K^{p}$ \add{dans $K$}),
\note{les ajouts marquent ici, et une fois encore au feuillet 28, des mots de
sa main portés en interligne}
i.e.\ $d_{k/k'}\, x$ et $d_{k/k'}\, y$ peuvent être lin.\ indépendants,
sans que $d_{K/K^{p}}\, x$ et $d_{K/K^{p}}\, y$ le soient ;
\struck{injection},
\[
  \Omega^{1}_{k/k \cap K^{p}} \otimes_{k} K \longrightarrow \Omega^{1}_{K}
\]
peut ne pas être injectif, ou \struck{\ill{}} ce qui revient au même, il peut
arriver que le noyau $N_{K/k}$ de
\[
  \Omega_{k} \otimes_{k} K \longrightarrow \Omega_{K}
\]
ne soit pas engendré \add{dans $K$} par les \add{\ill{} \ill{} \ill{}}
$dx \otimes 1$ \quad ($x \in k \cap K^{p}$).

\marginal{$\Omega^{1}_{k \cap K^{p}} \otimes_{k \cap K^{p}} K \to
\Omega^{1}_{k} \otimes_{k} \struck{K}\, K \to \Omega^{1}_{K}$}
\marginal{N.B. \struck{\ill{}} \ill{} (l'existence \uncertain{ci-dessus})
\struck{\ill{}} \ill{} $N_{K/k}$ \struck{\ill{}} \ill{} \ill{} \ill{}
\ill{} \ill{} \ill{} \ill{} \ill{} \uncertain{de dim.}\ $1$}
\note{la seconde note marginale est écrite en oblique dans le coin gauche et ne
se lit qu'en partie}

Voici un contre-ex. Soient $\mathbf{F}$ le corps premier [ou un corps
\uncertain{parfait} quelc.], $x, y, a_i$ $(1 \leq i \leq p-1)$ des
indéterminées sur $\mathbf{F}$, et soit \struck{$\beta = y - \alpha x$}

\struck{$K^{p} = \mathbf{F}(x^{p}, y^{p}, \alpha)$} \qquad
\struck{donc $K = \mathbf{F}(x, y, \alpha^{1/p})$}

\[
  \begin{cases}
    a_0 = y - \sum_{1}^{p-1} a_i x^{i} \\
    a = x^{p}
  \end{cases}
  \qquad \text{d'où} \qquad y = \sum_{0}^{p-1} a_i x^{i}
\]
\[
  K^{p} = \mathbf{F}(a, a_0, \dots, a_{p-1})
  = \struck{\mathbf{F}(\alpha, x^{p}, y - \alpha x)}\;
    \mathbf{F}\Big(x^{p}, a_1, \dots, a_{p-1},\, y - \sum_{1}^{p-1} a_i x^{i}\Big)
\]
\note{la première expression du membre de droite est biffée et remplacée par la
seconde, écrite au-dessus}
\[
  \struck{K = \mathbf{F}\big(\alpha^{1/p}, x, (y - \alpha x)^{1/p}\big)}
  \qquad \text{i.e.} \qquad
  K = \mathbf{F}\big(x, a_1^{1/p}, \dots, a_{p-1}^{1/p}, \ill{}\big)
\]
N.B. $a$ et $(a_i)_{1 \leq i \leq p-1}$ sont alg.\ \uncertain{indép.}\ sur
$\mathbf{F}$ et $k = \mathbf{F}(x,y)$ \quad [N.B. $x, y \in K$,
\uncertain{et} $y = \alpha x + \beta \in k$, donc $k \subset K$
\note{le crochet ouvert de ce N.B. n'est pas refermé sur le feuillet}
```

## cote 22, scan 28 (cited by 7 entries)

**Pro first pass** `MPL_22+23_002-016` (GPT-6 Astra (ChatGPT Pro mode), 16 Nov 2026):

```latex
\scanpage{28}

\unsure{sur} des répartitions sur $K$. Pour un \uline{idèle} $I'$ de $K'$,
$\operatorname{Ext}_{K',K}(I')$ est un \unsure{idèle}
de $K$. En ce qui concerne les répartitions \uline{principales}, l'extension à $K$ de \unsure{celle}
attachée à $x'\in K'$ est la répartition principale de $K$ attachée à $x'$ \unsure{considéré}
comme élément de $K$. Pour un idèle $I'$ de $K'$ on a
\mspage{27}
\[
(39)\quad \operatorname{Ext}_{K',K}(D'(I'))=D(\operatorname{Ext}_{K',K}(I'))
\quad\text{(``extension du diviseur''=``diviseur de l'extension'').}
\]

Enfin une formule évidente de transitivité.

Etant donnée une répartition $X=(x_{\unsure{P|p}})$ sur $K$, on appelle \uline{trace} et \uline{norme} de $K$ à
$K'$ de $X$, et on note $\operatorname{Tr}_{K/K'}(X)$ et $N_{K/K'}(X)$ les répartitions $(a_{\unsure{P'|p'}})$ et $(b_{\unsure{P'|p'}})$ de
$K'$ définies par
\[
(40)\quad a_{\unsure{P'|p'}}=\sum_{\unsure{P|p}\unsure{\mid|/}\unsure{P'|p'}}\operatorname{Tr}_{\widehat K_{\unsure{P|p}}/\widehat K'_{\unsure{P'|p'}}}(x_{\unsure{P|p}})
\qquad\text{et}\qquad
b_{\unsure{P'|p'}}=\prod_{\unsure{P|p}\unsure{\mid|/}\unsure{P'|p'}}N_{\widehat K_{\unsure{P|p}}/\widehat K'_{\unsure{P'|p'}}}(x_{\unsure{P|p}}).
\]
D'après les formules (12) et (13) (§ 2,n°2) les restrictions de $\operatorname{Tr}_{K/K'}$ et
$N_{K/K'}$ aux répartitions \uline{principales} (identifiées aux éléments de $K$) coïncidant
avec les applications $\operatorname{Tr}_{K/K'}$ et $N_{K/K'}$ définies pour les éléments de $K$. Il est
clair que l'application $\operatorname{Tr}_{K/K'}$ est une \uline{application} $K'$-\uline{linéaire} de l'ensemble
des répartitions de $K$ dans celui de $K'$, pour leurs structures d'espaces vectoriels sur $K'$.
La norme d'un \uline{idèle} de $K$ est un idèle de $K'$, et l'application
$N_{K/K'}$ est un \uline{homomorphisme} du groupe multiplicatif $J_K$ dans le groupe multiplicatif $J_{K'}$.
On a enfin les formules suivantes (que l'on vérifie comme l'âne
qui trotte) :
\[
\begin{aligned}
(41)\quad&\operatorname{Tr}_{K/K'}(z.\operatorname{Ext}_{K',K}(X'))=(\operatorname{Tr}_{K/K'}(z)).X'
\quad\text{pour }z\in K.\\
(42)\quad&\operatorname{Tr}_{K/K'}(\operatorname{Ext}_{K',K}(X'))=n.X'.\\
(43)\quad&N_{K/K'}(\operatorname{Ext}_{K',K}(X'))=(X')^n.\\
(44)\quad&D'(N_{K/K'}(I))=N_{K/K'}(D(I))\quad\text{pour tout idèle }I\text{ de }K.\\
(45)\quad&\text{formules de transitivité.}
\end{aligned}
\]

\uline{5 . Topologies sur l'espace des répartitions et sur le groupe des idèles} .

Soit $(G_\alpha)$ une famille de groupes topologiques, $(H_\alpha)$ une famille se dous-groupes
\uline{ouverts distingués} de $G_\alpha$. Sur le groupe produit $G=\prod_\alpha G_\alpha$ on met la topologie
pour laquelle un système fondamental de voisinages de l'élément neutre est for-

\mspage{27}
```

**Work second reading** `K22-02` (GPT-6.2 Astra at reasoning effort max (ChatGPT Work), 18 Nov 2026):

```latex
\scanpage{28}
\mspage{27}

lui des répartitions sur $K$. Pour un \uline{idèle} $I'$ de $K'$, $\operatorname{Ext}_{K',K}(I')$ est un \unsure{idèle} de $K$. En ce qui concerne les répartitions \uline{principales}, l'extension à $K$ de \unsure{celle} attachée à $x'\handwritten{\in}K'$ est la répartition principale de $K$ attachée à $x'$ \unsure{considéré} comme élément de $K$. Pour un idèle $I'$ de $K'$ on \deleted{\unsure{e|a}}a

\[ \begin{aligned} \operatorname{Ext}_{K',K}(D'(I'))&=D(\operatorname{Ext}_{K',K}(I'))\quad \text{(\textquotedbl{}extension du diviseur\textquotedbl{}=\textquotedbl{}diviseur de}\\ &\text{l'extension\textquotedbl{}) .}\end{aligned}\tag*{(39)} \]

Enfin une formule évidente de transitivité .

Etant donnée une répartition $X=(x_P)$ sur $K$, on appelle \uline{trace} et \uline{norme} de $K$ à $K'$ de $X$, et on note $\operatorname{Tr}_{K/K'}(X)$ et $N_{K/K'}(X)$ les répartitions $(a_{P'})$ et $(b_{P'}\unsure{)|\}}$ de $K'$ définies par

\[ a_{P'}=\handwritten{\sum}_{P\handwritten{/}P'}\operatorname{Tr}_{\hat K_P/\hat K'_{P'}}(x_P)\qquad \text{et}\qquad b_{P'}=\handwritten{\prod}_{P\handwritten{\mid}P'}N_{\hat K_P/\hat K'_{P'}}(x_P)\,.\tag*{(40)} \]

D'après les formules (12) et (13) (\S{} 2,n\textsuperscript{o}2) les restrictions de $\operatorname{Tr}_{K/K'}$ et $N_{K/K'}$ aux répartitions \uline{principales} (identifiées aux éléments de $K$) coïncident avec les applications $\operatorname{Tr}_{K/K'}$ et $N_{K/K'}$ définies pour les éléments de $K$. Il est clair que l'application $\operatorname{Tr}_{K/K'}$ est une \uline{application} $K'$-\uline{linéaire} de l'ensemble des répartitions de $K$ dans celui de $K'$, pour leurs structures d'espaces vectoriels sur $K'$. La norme d'un \uline{idèle} de $K$ est un idèle de $K'$, et l'application $N_{K/K'}$ est un \uline{homomorphisme} du groupe multiplicatif $J_K$ dans le groupe multiplicatif $J_{K'}$. On a enfin les formules suivantes (que l'on vérifie comme l'âne qui trotte) :

\[ \operatorname{Tr}_{K/K'}(z.\operatorname{Ext}_{\unsure{K'|\,},K}(X'))=(\operatorname{Tr}_{K/K'}(z)).X'\quad \text{pour }z\handwritten{\in}K\,.\tag*{(41)} \]

\[ \operatorname{Tr}_{K/K'}(\operatorname{Ext}_{K',K}(X'))=n.X'\,.\tag*{(42)} \]

\[ N_{K/K'}(\operatorname{Ext}_{K',K}(X'))=(X')^n\,.\tag*{(43)} \]

\[ D'(N_{K/K'}(I))=N_{K/K'}(D(I))\quad\text{pour tout idèle }I\text{ de }K\,.\tag*{(44)} \]

\[ \text{formules de transitivité .}\tag*{(45)} \]

\uline{6 . Topologies sur l'espace des répartitions et sur le groupe des idèles} .

Soit $(G_{\handwritten{\alpha}})$ une famille de groupes topologiques, $(H_{\handwritten{\alpha}})$ une famille se \deleted{\unsure{d|s}}sous-groupes \uline{ouverts distingués} de $G_{\handwritten{\alpha}}$. Sur le groupe produit $G=\handwritten{\prod_{\alpha}}G_{\handwritten{\alpha}}$ on met la topologie pour laquelle un système fondamental de voisinages de l'élément neutre est for-
% archive sheet number: 27
```

## cote 22, scan 29 (cited by 7 entries)

**Pro first pass** `MPL_22+23_002-016` (GPT-6 Astra (ChatGPT Pro mode), 16 Nov 2026):

```latex
\scanpage{29}

\deleted{\unsure{Il faut bien} $x,y\notin$}
\margin{\unsure{cf le NB en final}}
\figure{\begin{tikzpicture}\draw (0,0) .. controls (-.5,.8) and (1.9,1) .. (2.4,.1)
.. controls (2.6,-.25) and (1.8,-.2) .. (1.6,-.35)
.. controls (1.5,-.5) and (1.5,-.7) .. (1.5,-.8);
\draw (0,0)..controls(.6,-.2)and(1.2,-.1)..(1.8,-.15);\end{tikzpicture}}
Par construction, on a $x\in K$, $x\notin K^p$, et
$y\notin K^p$, $y\in K^p(x)$, avec \deleted{$\unsure{\alpha,\beta}$}
\inserted{les $a_i$} sont les \uline{seuls} $\in K^p$
tels qu'on ait \deleted{$y=\alpha x+\beta$. \unsure{Evident}}
\inserted{$y=\sum_0^{p-1}a_i x^i$}.

Comme $x\notin K^p$, on a $x\notin K^p\cap k$, mais bien
sur $x^p\in K^p\cap k$ ; si donc $(x,y)$ \unsure{n'étaient}
\deleted{lin.} $p$-\unsure{libres} sur $K^p\cap k$, on aurait une
relation $y=\sum_0^{p-1}a_i' x^i$, les $a_i'\in K^p\cap k$, donc
\deleted{\unsure{les}} \inserted{on aurait} $a_i'=a_i$, donc
$a_i\in k=\mathbb F(x,y)$, absurde.

N.B. Condition essentielle
\[
\left\{\begin{array}{l}
(x,y)\quad p\text{-libres sur }\lambda=\mathbb F(a_1,\ldots,a_{p-1})\\
\deleted{\unsure{a_1}}\quad\lambda\unsure{\notin|\not\subset}\mathbb F(x,y)
\end{array}\right.
\]
\deleted{Il suffit \unsure{par}}
exemple
\deleted{que $x,y$ \unsure{soient} \inserted{\unsure{$p$-indépendants}}
\unsure{sur} $\lambda=\mathbb F(a_0,\ldots,a_{p-1})$, et
\unsure{que prendre} $\lambda$ \unsure{en un autre}]
\inserted{\unsure{de} $\mathbb F(x,y,a)$}}

Prendre $x,y,a_1$ \deleted{\unsure{alg.}} $p$-indép. sur $\unsure{\mathbb F_p|\mathbb F_0}$ et prendre
$a_i=0$ pour $1<i\le p-1$. Bien entendu, $F$ peut
être n'importe quel corps parfait \unsure{dans la sc.}
On peut aussi prendre $x,y$ alg. indép. sur $F$,
et $a_1$ alg. \deleted{\unsure{séparable}} \inserted{\unsure{irrationnel}} sur $F$, $a_1\notin F$, alors
$K$ est obtenu \unsure{en adjoignant} une racine
$p$-ième (celle de $y-ax$) dans $k(b)$, où $b$ est
alg. \unsure{séparable} sur $k$ $[b=a^{1/p}]$.

\mspage{28}
```

**Work second reading** `K22-02` (GPT-6.2 Astra at reasoning effort max (ChatGPT Work), 18 Nov 2026):

```latex
\scanpage{29}

\deleted{\unsure{Il est|Il s'|Je dis} \unsure{Comme|On a|que} $x,y\notin$}

Par construction, on a $x\in K$, $x\notin K^p$, \inserted{(cf le NB marginal)} et $y\notin K^p$, $y\in K^p(x)$, donc \deleted{$\alpha,\beta$} \inserted{les $a_i$} sont les \uline{seuls} $\unsure{c|\epsilon|\in|\vphantom{c}}\in K^p$ tels qu'on ait \deleted{$y=\alpha x+\beta$. Evident} \inserted{$y=\sum_0^{p-1}a_i x^i$}

Comme $x\notin K^p$, on a $x\notin K^p\cap k$, mais bien sûr $x^p\in K^p\cap k$, Si donc $(x,y)$ n'\deleted{était} \deleted{\unsure{lié|l'était}} p-libres sur $K^p\cap k$, on aurait une relation $y=\sum_0^{p-1}a'_i x^i$, les $a'_i\in K^p\cap k$, donc \deleted{les} \inserted{on aurait} $a'_i=a_i$, donc $a_i\in k=\mathbb F(x,y)$, absurde.

N.B. Conditions essentielles

\[ \left\{\begin{aligned} &(x,y)\quad\text{p libres sur }\lambda=\mathbb F(a_1,\ldots,a_{p-1})\\ &\deleted{\unsure{a_1=|a_1|a_i}}\ \lambda\not\subset\mathbb F(x,y)\end{aligned}\right. \]

\deleted{Il suffit \inserted{pour} que} exemple \deleted{que $x,y$ et \inserted{$p$ indép. sur} \unsure{$p$ libre sur un|$p$ libre ds un} $\lambda=\mathbb F(a_1,\ldots,a_{p-1})$, et \unsure{par} prendre $\lambda$ \unsure{l'un au seul|l'un au sens}} Prendre $x,y,a_1$ \deleted{alg} p-indép. sur $\mathbb F$, \inserted{dans $\mathbb F(x,y,a)$} et prendre $a_i=0$ pour $2\leq i\leq p-1$. Bien entendu, $\mathbb F$ peut être n'importe quel corps parfait dans \unsure{tt ça.|tt çà.|la sq.}.

On peut aussi prendre $x\unsure{+|\ \text{et}\ |,}y$ alg. indép sur $\mathbb F$, et $a_1$ alg\textsuperscript{\unsure{b|q|\vphantom{b}}} \deleted{séparable} sur $\mathbb F$, $a_1\notin\mathbb F$, Alors $K$ est obtenu \inserted{à partir de $k$,} en extrayant une racine $p$\textsuperscript{ième} (celle de $y-\unsure{a|\alpha}x$) dans $k(b)$, où $b$ est alg. séparable sur $k$ [$b=a^{1/p}$].
% archive sheet number: 28
```

**Witness H** (`batch-02.fr.tex`):

```latex
\page{28}
\struck{Je dis que $x, y \notin$} Vérifions les conditions, on a
$x \in K$, $x \notin K^{p}$, et
\marginal{(cf.\ le N.B. \uncertain{précédent})}
$y \notin K^{p}$, $y \in K^{p}(x)$, donc \add{les $a_i$}
\struck{$\alpha, \beta$} sont les \emph{seuls} $\in K^{p}$ tels que
\uncertain{l'on ait} \add{$y = \sum_{0}^{p-1} a_i x^{i}$}
\struck{$y = \alpha x + \beta$. Évident}

Comme $x \notin K^{p}$, on a $x \notin K^{p} \cap k$, mais bien sûr
$x^{p} \in K^{p} \cap k$, si donc $(x,y)$ n'était \struck{\ill{}} p-libre sur
$K^{p} \cap k$, on \uncertain{aurait} une relation
$y = \sum_{0}^{p-1} a'_i x^{i}$, les $a'_i \in K^{p} \cap k$, donc
\add{\uncertain{par unicité}} \struck{les} $a'_i = a_i$, donc
$a_i \in k = \mathbf{F}(x,y)$, absurde.

N.B. Conditions essentielles
\[
  \begin{cases}
    (x,y) \;\text{p-libre sur}\; \lambda = \mathbf{F}(a_1, \dots, a_{p-1}) \\
    \struck{a_i}\; \lambda \not\subset \mathbf{F}(x,y)
  \end{cases}
\]
\struck{Je \uncertain{voudrais} \ill{}} \uncertain{exemple}
\struck{où $x, y$ \ill{} \ill{} \ill{} \ill{}}
\struck{$\lambda = \mathbf{F}(a_1, \dots, a_{p-1})$, et \ill{}
\uncertain{parallèlement} \ill{} \ill{} $a_i$ \ill{}}
\add{\ill{}, $\mathbf{F}(x,y,a)$}

Prenons $x, y, a_1$ \struck{alg.}\ p-indép.\ sur $\mathbf{F}_0$
\add{et prendre} $a_i = 0$ pour $2 \leq i \leq p-1$.
Bien entendu, $\mathbf{F}$ peut être n'importe quel corps parfait
\ill{} \ill{}. On peut aussi prendre $x, y$ alg.\ indép.\ sur $\mathbf{F}$,
et $a_1$ alg.\ \struck{séparable} sur $\mathbf{F}$, $a_1 \notin \mathbf{F}$,
alors $K$ est obtenu \add{\ill{} \ill{} $k$} (en adjoignant une \ill{}
\ill{} (celle de $y - \alpha x$) dans $k(b)$, où $b$ est alg.\ séparable sur
$k$ \quad $[\,b = a^{1/p}\,]$.

\end{document}
```

## cote 22, scan 30 (cited by 7 entries)

**Pro first pass** `MPL_22+23_002-016` (GPT-6 Astra (ChatGPT Pro mode), 16 Nov 2026):

```latex
\scanpage{30}

Etant donné un diviseur $D'=\sum_{P'}m(P').P'$ de $K'$, nous appellerons \uline{extension} \unsure{de}
$D'$ à $K$ et noterons $\operatorname{Ext}_{K',K}(D')$ le diviseur de $K$ défini par
\mspage{29}
\[
(31)\quad\operatorname{Ext}_{K',K}\Bigl(\sum_{P'}m(P').P'\Bigr)
=\sum_{P'}m(P').\Bigl(\sum_{P\mid P'}e(P).P\Bigr).
\]
Il est clair que $\operatorname{Ext}_{K',K}$ est un \uline{isomorphisme croissant} du groupe
\deleted{\unsure{des}} ordonné des diviseurs de $K'$ dans celui des diviseurs de $K$.
En vertu de (29) on a
\[
(32)\quad\operatorname{Ext}_{K',K}(D'(x'))=D(x')\quad\text{pour }x'\in K'.
\]
Si $K''\subset K'\subset K$, et pour tout diviseur $D''$ de $K''$,on a
\[
(33)\quad\operatorname{Ext}_{K',K}(\operatorname{Ext}_{K'',K'}(D''))
=\operatorname{Ext}_{K'',K}(D'').
\]
Etant donné un diviseur $D=\sum_P m(P).P$ de $K$, nous appellerons \uline{norme} de $K$ à $K'$ \unsure{de}
$D$, et noterons $N_{K/K'}(D)$ le diviseur de $K'$ défini par
\[
(34)\quad N_{K/K'}(D)=\sum_{P'}\Bigl(\sum_{P\mid P'}m(P)\uline{f(P)}\Bigr).P'.
\]
Il est clair que $N_{K/K'}$ est un \uline{homomorphisme croissant} du groupe ordonné des diviseurs
de $K$ dans celui des diviseurs de $K'$. Comme $\sum_{P\mid P'}e(P)f(P)=n$, on voit que
\[
(35)\quad N_{K/K'}(\operatorname{Ext}_{K',K}(D'))=n.D'.
\]
D'autre part (30) montre que l'on a
\[
(36)\quad D'(N_{K/K'}(x))=N_{K/K'}(D(x))\quad\text{pour tout }x\in K.
\]
Enfin, si $K''\subset K'\subset K$, et si $D$ est un diviseur de $K$, on a
\[
(37)\quad N_{K'/K''}(N_{K/K'}(D))=N_{K/K''}(D).
\]
Supposons maintenant que $\unsure{\overline\Phi'}$ satisfasse à une formule du produit
$\prod_{P'}(f_{P'}(x'))^{r(P')}=1$.
Alors, en vertu de (30), $\unsure{\overline\Phi}$ satisfait à la formule
du produit $\prod_P(f_P(x))^{r(P)}=1$, où $r(P)=f(P)r(P')$ pour $P\mid P'$.
D'après la définition des \uline{degrés} des diviseurs, et comme
$\sum_{P\mid\unsure{P|P'}}e(P)f(P)=n$, on a, pour tout couple de diviseurs $D'$ de $K'$ et $D$ de $K$ :
\[
(38)\quad d(\operatorname{Ext}_{K',K}(D'))=n.d(D')\qquad\text{et}\qquad d(N_{K/K'}(D))=d(D).
\]
Etant donnée une \uline{répartition} \deleted{$\unsure{X'=(x'_P)}$}
$X'=(x'_{P'})$ $(x'_{P'}\in\widehat K'_{P'})$, nous appellerons
\uline{extension} de $X'$ à $K$ et noterons $\operatorname{Ext}_{K',K}(X')$ la répartition sur $K$ définie par
$X=(x_P)$, où, pour $P\mid P'$, l'élément $x_P$ de $\widehat K_P$ est $x'_{P'}$.
Il est clair que l'application $\operatorname{Ext}_{K',K}$ est un \uline{isomorphisme} de l'anneau des répartitions sur $K'$ dans ce

\mspage{26}
```

**Work second reading** `K22-02` (GPT-6.2 Astra at reasoning effort max (ChatGPT Work), 18 Nov 2026):

```latex
\scanpage{30}
\mspage{26}

Etant donné un diviseur $D'=\handwritten{\sum}_{P'}m(P').P'$ de $K'$, nous appellerons \uline{extension} de $D'$ à $K$ et noterons $\operatorname{Ext}_{K',K}(D')$ le diviseur de $K$ défini par

\[ \operatorname{Ext}_{K',K}\bigl(\handwritten{\sum}_{P'}m(P').P'\bigr)=\handwritten{\sum}_{P'}m(P').\bigl(\handwritten{\sum}_{P\handwritten{\mid} P'}e(\deleted{\unsure{B|P}}P).P\bigr)\,.\tag*{(31)} \]

Il est clair que $\operatorname{Ext}_{K',K}$ est un \uline{isomorphisme croissant} du groupe \deleted{des} ordonné des diviseurs de $K'$ dans celui des diviseurs de $K$. En vertu de (29) on a

\[ \operatorname{Ext}_{K',K}(D'(x'))=D(x')\quad\text{pour }x'\handwritten{\in} K'\,.\tag*{(32)} \]

Si $K''\handwritten{\subset} K'\handwritten{\subset} K$, et pour tout diviseur $D''$ de $K''$, on a

\[ \operatorname{Ext}_{K',K}(\operatorname{Ext}_{K'',K'}(D''))=\operatorname{Ext}_{K'',K}(D'')\,.\tag*{(33)} \]

Etant donné un diviseur $D=\handwritten{\sum}_P m(P).P$ de $K$, nous appellerons \uline{norme} de $K$ à $K'$ de $D$, et noterons $N_{K/K'}(D)$ le diviseur de $K'$ défini par

\[ N_{K/K'}(D)=\handwritten{\sum}_{P'}\bigl(\handwritten{\sum}_{P\handwritten{\mid} P'}m(P)\underline{f(P)}\bigr).P'\,.\tag*{(34)} \]

Il est clair que $N_{K/K'}$ est un \uline{homomorphisme croissant} du groupe ordonné des diviseurs de $K$ dans celui des diviseurs de $K'$. Comme $\handwritten{\sum}_{P\handwritten{\mid} P'}e(P)f(P)=n$, on voit que

\[ N_{K/K'}(\operatorname{Ext}_{\unsure{K'|\,},K}(D'))=n.D'\,.\tag*{(35)} \]

D'autre part (30) montre que l'on a

\[ D'(N_{K/K'}(x))=N_{K/K'}(D(x))\quad\text{pour tout }x\handwritten{\in} K\,.\tag*{(36)} \]

Enfin, si $K''\handwritten{\subset} K'\handwritten{\subset} K$, et si $D$ est un diviseur de $K$, on a

\[ N_{K'/K''}(N_{K/K'}(D))=N_{K/K''}(D)\,.\tag*{(37)} \]

Supposons maintenant que $\handwritten{\Phi'}$ satisfasse à une formule du produit $\handwritten{\prod}_{P'}(f_{P'}(x'))^{r(P')}=1$. Alors, en vertu de (30), $\handwritten{\Phi}$ satisfait à la formule du produit $\handwritten{\prod}_P(f_P(x))^{r(P)}=1$, où $r(P)=f(P)r(P')$ pour $P\handwritten{\mid} P'$. D'après la définition des \uline{degrés} des diviseurs, et comme $\handwritten{\sum}_{P\handwritten{\mid} P}e(P)f(P)=n$, on a, pour tout couple de diviseurs $D'$ de $K'$ et $D$ de $K$ :

\[ d(\operatorname{Ext}_{K',K}(D'))=n.d(D')\qquad\text{et}\qquad d(N_{K/K'}(D))=d(D)\,.\tag*{(38)} \]

Etant donnée une \uline{répartition} \deleted{$\unsure{X=(x_P)|X=(x_{P'})}$} $X\handwritten{'}=(x'_{P'})$ $(x'_{P'}\handwritten{\in}\hat K'_{P'})$, nous appellerons \uline{extension} de $X'$ à $K$ et noterons $\operatorname{Ext}_{K',K}(X')$ la répartition sur $K$ définie par $X=(x_P)$, où, pour $P\handwritten{\mid} P'$, l'élément $x_P$ de $\hat K_P$ est $x'_{P'}$. Il est clair que l'application $\operatorname{Ext}_{K',K}$ est un \uline{isomorphisme} de l'anneau des répartitions sur $K'$ dans ce
% archive sheet number: 29
```
