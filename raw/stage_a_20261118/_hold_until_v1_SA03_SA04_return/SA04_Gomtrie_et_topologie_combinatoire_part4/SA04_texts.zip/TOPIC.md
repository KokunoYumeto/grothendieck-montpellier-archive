# SA04: Géométrie et topologie combinatoire

| cote | catalogue title | pages | Pro | Codex | API | in this run |
|---|---|---:|---:|---:|---:|---|
| 69 | Graphes cubiques : notes manuscrites (s.d.), lettre (s.d.). | 119 | 0 | 0 | 0 | other part |
| 70 | Réalisations géométriques de structures combinatoires (n-polyèdres, n-hyperpolyèdres [2-polyèdres réguliers]…) (Vieilles rédactions) : notes manuscrites (s.d.). | 125 | 0 | 0 | 0 | other part |
| 71 | Théorème de Jordan[62] : notes manuscrites (1976, s.d.). | 47 | 0 | 41 | 0 | other part |
| 72 | Polyèdres réguliers et hyperpolyèdres réguliers (Calculs en dimension quelconque) : notes manuscrites (s.d.). | 112 | 47 | 0 | 0 | other part |
| 73 | Polygones : notes manuscrites (s.d.), lettre (s.d.). | 28 | 0 | 0 | 0 | other part |
| 74 | Complexes cubiques : notes manuscrites (s.d.). | 135 | 0 | 0 | 0 | other part |
| 75 | Cours C4, DEA : notes manuscrites (s.d.), lettre (1978), tapuscrit (1977-1978). | 32 | 0 | 31 | 0 | other part |
| 76 | n-cartes cellulaires : notes manuscrites (s.d.). | 62 | 0 | 0 | 0 | other part |
| 77 | Quadriques affines, extensions quadratiques : notes manuscrites (s.d.). | 157 | 0 | 0 | 0 | other part |
| 78 | [Polygones réguliers et polynômes cyclotomiques] : notes manuscrites (s.d.). | 129 | 0 | 0 | 0 | other part |
| 79 | 2-polyèdres réguliers triangulés, et modules libres de rangs 2 sur les anneaux $\Lambda=\mathbb{Z}/n\mathbb{Z}$ et $\Lambda=\mathbb{Z}$ : notes manuscrites (s.d.). | 296 | 0 | 0 | 0 | other part |
| 80 | Systèmes de pseudo-droites : notes manuscrites (s.d.). | 72 | 0 | 0 | 0 | other part |
| 81 | Immersions du disque et de la circonférence[72] : notes manuscrites (s.d.). | 54 | 0 | 52 | 0 | other part |
| 82 | SO(3) ≃ GP(1) : notes manuscrites (s.d.). | 78 | 0 | 0 | 0 | other part |
| 83 | [Icosaèdres, bi-icosaèdres et algèbres d'Azumaya de rang 4][75] : notes manuscrites (1982-1983, 1986, s.d.). | 221 | 43 | 0 | 0 | other part |
| 84 | [Formes quadratiques][77] : notes manuscrites (s.d.). | 192 | 96 | 0 | 0 | other part |
| 85 | 2-polyèdres et 1-polygônes : notes manuscrites (s.d.). | 97 | 0 | 0 | 0 | other part |
| 86 | [Polyèdres réguliers] : notes manuscrites (s.d.). | 32 | 0 | 0 | 0 | other part |
| 87 | Polyèdres convexes : notes manuscrites (s.d.). | 40 | 0 | 0 | 0 | other part |
| 88 | Cartes standards : notes manuscrites (s.d.). | 15 | 0 | 0 | 0 | other part |
| 89 | [Hexagone] combinatoire. [Ensembles 3-3] : notes manuscrites (s.d.). | 20 | 0 | 0 | 0 | other part |
| 90 | KG (X) : notes manuscrites (s.d.). | 24 | 24 | 0 | 0 | other part |
| 91 | Autour de Néron / Greenberg-Néron. Foncteurs Hom (méthodes non-projectives) : notes manuscrites (s.d.), lettre (1967). | 142 | 91 | 0 | 0 | other part |
| 93 | Connexions de Gauss-Manin et équations de Picard-Fuchs. Opération de Cartier : copies de tapuscrit annoté (s.d.), tiré à part (1981), notes manuscrites (s.d.). | 235 | 58 | 0 | 0 | MPL_93_047-091, MPL_93_221-236+161-5, K93-01, K93-02, K93-03, K93-04, K93-05, K93-06, K93-07, K93-08, K93-09, K93-10, K93-11, K93-12 |
| 94 | Dualité des modules / Construction de faisceaux de modules : notes manuscrites (s.d.). | 23 | 0 | 0 | 0 | other part |
| 97 | Classes de Chern des représentations[85] : lettre (1966), notes manuscrites (s.d.). | 18 | 0 | 7 | 0 | other part |
| 98 | Schémas de Hilbert. Normes : notes manuscrites (s.d.). | 43 | 0 | 0 | 0 | MPL_98 |
| 100 | Bonne réduction des variétés abéliennes via bonne réduction de Barsotti-Tate Tp (A) (base quelconque)[88] : notes manuscrites (s.d.), copies de tapuscrit annoté (s.d.). | 52 | 52 | 0 | 0 | MPL_8_079-081+9+4+100, K100-01, K100-02, K100-03, K100-04 |
| 101 | Cohomologie locale : notes manuscrites (s.d.). | 42 | 0 | 0 | 0 | other part |
| 102 | Etude générale des foncteurs (Sch)° → (Ens) : tapuscrit annoté (s.d.), notes manuscrites (s.d.). | 13 | 0 | 0 | 0 | other part |
