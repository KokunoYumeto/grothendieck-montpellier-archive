# SA13: Picard

| cote | catalogue title | pages | Pro | Codex | API | in this run |
|---|---|---:|---:|---:|---:|---|
| 57 | Picard[49] : tapuscrit annoté (s.d.), lettres (s.d., 1962). | 314 | 129 | 22 | 0 | MPL_57_089-132, MPL_57_226-270, MPL_57_271-315, A57-01, A57-02 |
| 58 | Théorie de " Lefschetz-Grauert ". Applications en π₁, à Pic etc… : notes manuscrites (s.d.). | 66 | 44 | 0 | 0 | MPL_58_020-067 |
| 59 | Construction des faisceaux inversibles sur schémas de Picard[51] : notes manuscrites (s.d.). | 27 | 0 | 0 | 0 | other part |
| 60 | Fonctions L / Équation fonctionnelle des fonctions L (cas géométrique) : notes manuscrites (s.d.). | 69 | 69 | 0 | 0 | MPL_60_002-035, MPL_60_036-070 |
