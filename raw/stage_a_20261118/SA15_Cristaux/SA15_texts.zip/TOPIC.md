# SA15: Cristaux

| cote | catalogue title | pages | Pro | Codex | API | in this run |
|---|---|---:|---:|---:|---:|---|
| 4 | Torsion en cohomologie cristalline : notes manuscrites (s.d.), copies de tapuscrit annoté (s.d.). | 11 | 12 | 0 | 0 | MPL_8_079-081+9+4+100, K4-01 |
| 5 | Cristaux et cohomologie de De Rham[5] : généralités, correspondances Deligne et Berthelot (1965-1969) : notes manuscrites (s.d.), lettre (1965). | 52 | 52 | 0 | 0 | MPL_5+6_001-037 |
| 6 | Lettre Tate (mai 66) (Cristaux) : lettre (1966), tapuscrit (s.d.), notes manuscrites (s.d.). | 66 | 64 | 0 | 0 | MPL_5+6_001-037, MPL_6_038-067+7_001-060 |
| 7 | Notes laïus novembre-décembre 1967 (Cristaux) : notes manuscrites (1966-1967). | 71 | 70 | 0 | 0 | MPL_6_038-067+7_001-060, MPL_7_061-072+8_001-078 |
| 8 | Cristaux (1970). Gribouillis et calculs divers : notes manuscrites (s.d.). | 80 | 77 | 0 | 0 | MPL_7_061-072+8_001-078, MPL_8_079-081+9+4+100, K8-01 |
| 9 | Groupe de Barsotti-Tate et cristaux (jusqu’en été 1969)[9] : notes manuscrites (s.d.). | 28 | 29 | 0 | 0 | MPL_8_079-081+9+4+100, K9-01, K9-02 |
