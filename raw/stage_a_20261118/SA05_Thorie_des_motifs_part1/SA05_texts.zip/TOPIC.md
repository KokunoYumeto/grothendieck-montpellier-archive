# SA05: Théorie des motifs

| cote | catalogue title | pages | Pro | Codex | API | in this run |
|---|---|---:|---:|---:|---:|---|
| 10 | Catégories tensorielles[11] : notes manuscrites (s.d.), tapuscrits (s.d.). | 197 | 0 | 84 | 0 | other part |
| 11 | Formalisme des correspondances : notes manuscrites (s.d.). | 57 | 54 | 0 | 0 | MPL_11_002-042, MPL_11_043-058+56, K11-01, K11-02, K11-03, K11-04 |
| 12 | Généralités (sous-groupes de Galois motiviques) (1964 ?) : notes manuscrites (s.d.), tapuscrit (s.d.). | 167 | 141 | 22 | 0 | MPL_12_002-050, MPL_12_051-098, MPL_12_099-149, B12-01, B12-02, K12-01, K12-02, K12-03, K12-04, K12-05, K12-06, K12-07, K12-08, K12-09 |
| 13 | Groupe de Galois motivique : notes manuscrites (s.d.), lettre (1965). | 51 | 0 | 44 | 0 | other part |
| 14 | Théorie des cycles algébriques : conjectures de Hodge, Tate, Lefschetz, Weil : notes manuscrites (s.d.), lettre (1965). | 131 | 81 | 0 | 0 | other part |
| 15 | Théorie arithmétique. Théorie de Galois des motifs (1965) : notes manuscites (s.d.), tapuscrit (s.d.). | 227 | 158 | 27 | 0 | other part |
| 16 | Formalisme algébrique des correspondances et algèbres de Poincaré-Hodge (cf conjectures standard) : notes manuscrites (s.d.), tapuscrit annoté (s.d.), lettres (1966-1967). | 55 | 54 | 0 | 0 | other part |
| 18 | Motifs et théorie de Hodge : notes manuscrites (s.d.). | 61 | 60 | 0 | 0 | other part |
| 19 | Topos : notes manuscrites (s.d.). | 95 | 0 | 0 | 0 | other part |
