# SA32: Dérivateurs

| cote | catalogue title | pages | Pro | Codex | API | in this run |
|---|---|---:|---:|---:|---:|---|
| 157-1 | Dérivateurs [chapitres I à IV, dont sommaire général][161] : notes manuscrites (s.d.). | 270 | 0 | 0 | 0 | other part |
| 157-2 | Dérivateurs [chapitres V à VIII][163] : notes manuscrites (1990, s.d.). | 441 | 0 | 0 | 0 | other part |
| 157-3 | Dérivateurs [chapitres IX à XII, dont sommaire et appendices du chapitre XII] : notes manuscrites (s.d., 1990). | 355 | 0 | 0 | 0 | other part |
| 157-4 | Dérivateurs [chapitres XIII à XVI, dont sommaire du chapitre XVI][166] : notes manuscrites (s.d.). | 408 | 0 | 0 | 0 | other part |
| 157-5 | Dérivateurs [chapitres XVII à XIX, dont sommaires de chacun des chapitres] : notes manuscrites (s.d.). | 661 | 0 | 0 | 0 | other part |
| 158 | [Autour des Dérivateurs] : notes manuscrites (s.d.). | 85 | 0 | 0 | 0 | K158-01, K158-02, K158-03, K158-04, K158-05 |
| 159 | Connexions projectives et uniformisation[171] : notes manuscrites (s.d.). | 33 | 0 | 0 | 0 | MPL_159 |
| 160 | Schémas [en] groupes : notes manuscrites (s.d.). | 22 | 0 | 0 | 0 | K160-01, K160-02 |
