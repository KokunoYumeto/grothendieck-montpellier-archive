# SA09: Complexe de De Rham

| cote | catalogue title | pages | Pro | Codex | API | in this run |
|---|---|---:|---:|---:|---:|---|
| 136 | Complexe de De Rham à puissance divisée [conférence de 1976 à l’IHÉS][138] : notes manuscrites (s.d.). | 375 | 318 | 0 | 0 | other part |
| 137 | Dévissage des complexes ½ simpliciaux ∂ - parfaits et structures multiplicatives… (1975 ou 1976) : notes manuscrites (s.d.). | 85 | 42 | 0 | 0 | MPL_137_002-044, MPL_137_045-086 |
| 138 | Cartes. Etude arithmétique (1976, 77 ?) : bon de commande (s.d.), notes manuscrites (s.d.). | 132 | 0 | 0 | 0 | MPL_138_001-045, MPL_138_046-089, MPL_138_090-133 |
| 139 | [Prix Émile Picard de l'Académie des Sciences de l'Institut de France][140] : médaille. | 2 | 0 | 0 | 0 | other part |
