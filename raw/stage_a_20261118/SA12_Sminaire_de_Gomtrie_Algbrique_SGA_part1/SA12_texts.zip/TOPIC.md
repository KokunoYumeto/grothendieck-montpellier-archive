# SA12: Séminaire de Géométrie Algébrique (SGA)

| cote | catalogue title | pages | Pro | Codex | API | in this run |
|---|---|---:|---:|---:|---:|---|
| 27 | SGA D [SGA 3]. Compléments XII à XVII : tapuscrit annoté (s.d.), notes manuscrites (s.d.). | 36 | 0 | 0 | 0 | other part |
| 28 | [Groupes algébriques (SGA 3)] : notes manuscrites (s.d.). | 10 | 0 | 0 | 0 | other part |
| 29 | Groupe fondamental [Autour de SGA 4 et SGA 7] : lettres (1959, 1967, 1969), tapuscrits et copies de tapuscrit annotés (s.d.), notes manuscrites (s.d.). | 216 | 0 | 50 | 0 | MPL_29_049-094, MPL_29_095-140, A29-01, C29-01, C29-02, C29-03, C29-04, C29-05, C29-06, C29-07, K29-01, K29-02, K29-03, K29-04, K29-05, K29-06, K29-07, K29-08, K29-09, K29-10, K29-11 |
| 31 | SGA A [SGA 4] (Résidus de rédaction)[29] : notes manuscrites (s.d.). | 101 | 46 | 0 | 0 | MPL_31_002-051, K31-01, K31-02, K31-03 |
| 32 | Corrections (références, rajouts) [dont SGA 4][30] : tapuscrit (s.d.), notes manuscrites (s.d.). | 47 | 0 | 8 | 0 | other part |
| 33 | SGA [32] 1965. MS [Manuscrit] brouillon : notes manuscrites (s.d.). | 180 | 179 | 0 | 0 | MPL_33_002-049 |
| 34 | SGA 7 : notes manuscrites (s.d.). | 209 | 15 | 0 | 0 | other part |
| 35 | Plan [SGA 7] : notes manuscrites (s.d.), tapuscrit annoté (s.d.). | 5 | 0 | 4 | 0 | other part |
| 36 | SGA 7 (ma part)[35] : notes manuscrites (s.d.), tapuscrit annoté (s.d.). | 84 | 64 | 18 | 0 | other part |
| 37 | Rééditions SGA, EGA [SGA 4 à SGA 7, EGA I et EGA II] : tapuscrits et copies de tapuscrit annoté (s.d.), lettres (1967-1971, s.d.), notes manuscrites (s.d.). | 99 | 0 | 55 | 0 | other part |
| 39 | Fonctions et structures " élémentaires" [Schémas formels, théorème de préparation] : notes manuscrites (s.d.). | 19 | 16 | 0 | 0 | other part |
| 40 | Calculs [affines sur des] fibrés principaux affines : notes manuscrites (s.d.). | 27 | 0 | 0 | 0 | other part |
| 41 | Construction de morphismes étales (Chap. V) : notes manuscrites (s.d.). | 13 | 0 | 0 | 0 | other part |
| 42 | Réseaux d'anneaux locaux : notes manuscrites (s.d.). | 6 | 0 | 0 | 0 | other part |
