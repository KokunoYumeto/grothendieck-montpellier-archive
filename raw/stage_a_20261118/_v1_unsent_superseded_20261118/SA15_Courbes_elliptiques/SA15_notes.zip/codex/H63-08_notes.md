# Notes on the six supplied sheets

## Steps the pages themselves mark as unverified

| Scan | Place | Words or symbols on the page |
|---|---|---|
| 78 | Footnote (1), first assertion | “Au moment d'écrire ces lignes, il n'est pas prouvé que les valeurs propres de l'homomorphisme de Frobenius opérant sur les $\mathrm{H}^{i}(\mathrm{X},\underline{\mathrm{Z}}_{\ell})$ sont des entiers algébriques” |
| 78 | Same sentence, second assertion | “ni à fortiori que leurs valeurs absolues sont égales à $\mathrm{q}^{i/2}$” |
| 80 | a), after 163 | “plus peut-être une autre valeur $\mathrm{d}_{?}$” |
| 80 | b), end of the conductor list | “et $\mathrm{d}_{?}$ (s'il existe).” |
| 81 | Last row | $\mathrm{d}_{?}.1\quad\rightarrow\quad\mathrm{j}=\ ?$ |
| 83, 84, 85 | Bibliography | None. |

## Title sheets, dates and page counts

The headings and upper-right page numbers are listed below. Separate cover sheets, composition dates and explicit total page counts: none. The archive numbers come from the lower corner of each scan.

| Scan | Heading on this sheet | Typescript page | Archive sheet | Dates and page references on this sheet |
|---|---|---|---|---|
| 78 | AVANT-PROPOS | - 1 - | 77 | SGA 1964/65. cf SGA 1965. |
| 80 | Liste des courbes elliptiques à multiplication complexe / dont l'invariant modulaire j est rationnel | X-1 | 79 | No date or reference page. The Weber book is cited as t.III. |
| 81 | Continuation of the list | X-2 | 80 | Weber references, in row order: p.721 in 2.1 and 3.2. 462 in 3.3. 460 in 7.1. 475 in 7.2. 462 in 11.1. Four ditto signs follow. |
| 83 | COURBES ELLIPTIQUES : BIBLIOGRAPHIE | B-1 | 82 | §1: 4ème édition - 1964; 1922. §2: 1908; I, 1924 and II, 1927; 157, p.115-139 (1927) and 165, p.64-88 (1931); 1957-1958; 1958. §3: 1951; 1963. |
| 84 | Bibliography sections 4–7 | B-2 | 83 | §4: 1948, 1959. §5: 175 (1936); 16, 1949, p.32-47. §6: all three Igusa entries have 81, 1959, with p.453-476, p.436-452 and p.561-577 in that order. §7: 1948; nᵒ7, 1959; 1957-62, exp.232 et 236; nᵒ21, 1964; 1965. |
| 85 | Bibliography sections 8–10 | B-3 | 84 | §8: 16, 1949, p.32-47; nᵒ6, 1961; p.9-22, 1955; I, II, III, IV, followed by 1953, 1955, 1956, 1957. §9: nᵒ11, 1962; 1962, p.234-246; 1964; 1961. §10: both references give 1965. |
