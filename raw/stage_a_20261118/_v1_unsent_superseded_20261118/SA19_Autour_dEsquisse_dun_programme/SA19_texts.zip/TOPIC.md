# SA19: Autour d’Esquisse d’un programme

| cote | catalogue title | pages | Pro | Codex | API | in this run |
|---|---|---:|---:|---:|---:|---|
| 119 | Esquisse d’un programme [dossier constitué en vue d'une candidature au CNRS (1984)][108] : copies de tapuscrits et de tapuscrits annotés (1972-1974, 1978-1979, 1984, 1990-1991, s.d.), tirés à part (1971), notes et copies de note manuscrites (1986, s.d.), lettres (1968, 1972, 1991). | 313 | 0 | 0 | 270 | other part |
| 120 | Topologie modérée [110] : notes manuscrites (s.d.). | 24 | 25 | 0 | 0 | MPL_152+120 |
| 121 | Topologie modérée [111] : notes manuscrites (s.d.), lettre (1974). | 72 | 65 | 0 | 0 | MPL_121_001-048, MPL_121_049-073+153+155 |
| 122 | Point singulier isolé de la fibre : notes manuscrites (s.d.). | 34 | 32 | 0 | 0 | MPL_122 |
| 123 | [Autour de Kostant] : tapuscrits (s.d.), notes manuscrites (s.d.), lettre (1969). | 47 | 0 | 11 | 0 | C123-01, C123-02, K123-01 |
| 125 | Dualité projective : notes manuscrites (s.d.). | 8 | 0 | 0 | 0 | other part |
