# SA21: Autour de l’enseignement - Thèmes liés (cours et directions de recherches)

| cote | catalogue title | pages | Pro | Codex | API | in this run |
|---|---|---:|---:|---:|---:|---|
| 66 | Problèmes : notes manuscrites (1964). | 4 | 0 | 4 | 0 | MPL_66+68_002-032, H66-01 |
| 67 | Chirurgie des surfaces conformes[57] : notes manuscrites (s.d., 1983-1984), lettres (1984). | 100 | 0 | 0 | 0 | MPL_67_002-052, MPL_67_053-101 |
| 68 | Jeux de position : notes manuscrites (s.d.). | 55 | 51 | 0 | 0 | MPL_66+68_002-032, MPL_68_033-056+162-1+162-6 |
