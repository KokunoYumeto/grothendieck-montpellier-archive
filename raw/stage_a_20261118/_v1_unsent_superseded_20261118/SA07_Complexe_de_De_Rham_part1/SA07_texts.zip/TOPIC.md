# SA07: Complexe de De Rham

| cote | catalogue title | pages | Pro | Codex | API | in this run |
|---|---|---:|---:|---:|---:|---|
| 136 | Complexe de De Rham à puissance divisée [conférence de 1976 à l’IHÉS][138] : notes manuscrites (s.d.). | 375 | 318 | 0 | 0 | MPL_136_002-046, MPL_136_047-094, MPL_136_095-141, MPL_136_189-234, MPL_136_235-281, MPL_136_282-327 |
| 137 | Dévissage des complexes ½ simpliciaux ∂ - parfaits et structures multiplicatives… (1975 ou 1976) : notes manuscrites (s.d.). | 85 | 42 | 0 | 0 | other part |
| 138 | Cartes. Etude arithmétique (1976, 77 ?) : bon de commande (s.d.), notes manuscrites (s.d.). | 132 | 0 | 0 | 0 | other part |
| 139 | [Prix Émile Picard de l'Académie des Sciences de l'Institut de France][140] : médaille. | 2 | 0 | 0 | 0 | other part |
