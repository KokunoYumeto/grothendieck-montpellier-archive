# SA14: Picard

| cote | catalogue title | pages | Pro | Codex | API | in this run |
|---|---|---:|---:|---:|---:|---|
| 57 | Picard[49] : tapuscrit annoté (s.d.), lettres (s.d., 1962). | 314 | 129 | 22 | 0 | MPL_57_089-132, MPL_57_226-270, MPL_57_271-315, A57-01, A57-02, K57-01, K57-02, K57-03, K57-04, K57-05, K57-06, K57-07, K57-08, K57-09, K57-10 |
| 58 | Théorie de " Lefschetz-Grauert ". Applications en π₁, à Pic etc… : notes manuscrites (s.d.). | 66 | 44 | 0 | 0 | MPL_58_020-067, K58-01, K58-02 |
| 59 | Construction des faisceaux inversibles sur schémas de Picard[51] : notes manuscrites (s.d.). | 27 | 0 | 0 | 0 | K59-01, K59-02 |
| 60 | Fonctions L / Équation fonctionnelle des fonctions L (cas géométrique) : notes manuscrites (s.d.). | 69 | 69 | 0 | 0 | MPL_60_002-035, MPL_60_036-070 |
