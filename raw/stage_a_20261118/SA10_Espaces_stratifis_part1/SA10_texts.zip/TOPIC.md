# SA10: Espaces stratifiés

| cote | catalogue title | pages | Pro | Codex | API | in this run |
|---|---|---:|---:|---:|---:|---|
| 150 | Espaces stratifiés et voisinages côniques (ou : déploiement des espaces stratifiés) : notes manuscrites (s.d.). | 98 | 97 | 0 | 0 | MPL_150_001-043, MPL_150_044-084, MPL_150_085-099+151_001-031 |
| 151 | Topos stratifié (1981) : notes manuscrites (s.d.). | 74 | 72 | 0 | 0 | MPL_150_085-099+151_001-031, MPL_151_032-075 |
| 152 | Catégorie des types de mots [dont arbres plans] : notes manuscrites (s.d.). | 12 | 13 | 0 | 0 | MPL_152+120 |
| 153 | Analyseurs : notes manuscrites (s.d.). | 10 | 11 | 0 | 0 | other part |
| 154 | [Système de pseudo-droites] : notes manuscrites (1983-1984, s.d.). | 175 | 174 | 0 | 0 | other part |
| 155 | [Rigidité de catégories tensorielles ?] : notes manuscrites (s.d.). | 10 | 11 | 0 | 0 | other part |
