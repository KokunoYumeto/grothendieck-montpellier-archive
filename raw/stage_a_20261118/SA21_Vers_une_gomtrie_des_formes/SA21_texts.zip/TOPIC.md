# SA21: Vers une géométrie des formes

| cote | catalogue title | pages | Pro | Codex | API | in this run |
|---|---|---:|---:|---:|---:|---|
| 156-1 | [Chapitre] I. Vers une géométrie des formes (topologiques) : notes manuscrites (05/06/1986). | 26 | 27 | 0 | 0 | MPL_156-1+156-2 |
| 156-2 | [Chapitre] II. Réalisations topologiques des réseaux : notes manuscrites (06/06/1986). | 18 | 19 | 0 | 0 | MPL_156-1+156-2 |
| 156-3 | [Chapitre] III. Réseaux via découpages : notes manuscrites (08/06/1986). | 40 | 0 | 40 | 0 | J156-3-01, J156-3-02, J156-3-03, J156-3-04, J156-3-05 |
| 156-4 | [Chapitre] IV. Analysis situs (première mouture) : notes manuscrites (10/06/1986). | 88 | 0 | 88 | 0 | J156-4-01, J156-4-02, J156-4-03, J156-4-04, J156-4-05, J156-4-06, J156-4-07, J156-4-08, J156-4-09, J156-4-10, J156-4-11 |
| 156-5 | [Chapitre] V. Algèbre des figures : notes manuscrites (14/06/1986). | 48 | 0 | 48 | 0 | J156-5-01, J156-5-02, J156-5-03, J156-5-04, J156-5-05, J156-5-06 |
| 156-6 | [Chapitre] VI. Analysis situs (deuxième mouture) : notes manuscrites (18-20/06/1986). | 93 | 0 | 93 | 0 | J156-6-01, J156-6-02, J156-6-03, J156-6-04, J156-6-05, J156-6-06, J156-6-07, J156-6-08, J156-6-09, J156-6-10, J156-6-11, J156-6-12 |
| 156-7 | [Chapitre] VII. Analysis situs (troisième mouture) : notes manuscrites (23-26/06/1986). | 113 | 0 | 56 | 0 | J156-7-01, J156-7-02, J156-7-03, J156-7-04, J156-7-05, J156-7-06, J156-7-07, J156-7-08, J156-7-09, J156-7-10, J156-7-11, J156-7-12, J156-7-13, J156-7-14 |
| 156-8 | [Chapitre] VIII. Analysis situs (quatrième mouture) : notes manuscrites (26/06-04/07/1986). | 126 | 0 | 0 | 0 | J156-8-01, J156-8-02, J156-8-03, J156-8-04, J156-8-05, J156-8-06, J156-8-07, J156-8-08, J156-8-09, J156-8-10, J156-8-11, J156-8-12, J156-8-13, J156-8-14, J156-8-15, J156-8-16 |
| 156-9 | [Chapitre] IX et IX bis. [Ateliers][159] : notes manuscrites (05-15/07/1986). | 139 | 0 | 0 | 0 | J156-9-01, J156-9-02, J156-9-03, J156-9-04, J156-9-05, J156-9-06, J156-9-07, J156-9-08, J156-9-09, J156-9-10, J156-9-11, J156-9-12, J156-9-13, J156-9-14, J156-9-15, J156-9-16, J156-9-17, J156-9-18 |
