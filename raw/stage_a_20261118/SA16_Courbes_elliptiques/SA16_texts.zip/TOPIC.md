# SA16: Courbes elliptiques

| cote | catalogue title | pages | Pro | Codex | API | in this run |
|---|---|---:|---:|---:|---:|---|
| 62 | Courbes elliptiques (généralités - vieille rédaction) : notes manuscrites (s.d.). | 96 | 46 | 0 | 0 | MPL_62_002-050, K62-01, K62-02, K62-03 |
| 63 | Formulaire courbes elliptiques : notes et copies de notes manuscrites (s.d.), tapuscrit (s.d.), copies d'articles (s.d.). | 100 | 0 | 68 | 0 | H63-01, H63-02, H63-03, H63-04, H63-05, H63-06, H63-07, H63-08, H63-09, K63-01, K63-02 |
| 64 | Modules courbes elliptiques en caractéristiques ≠2 : notes manuscrites (s.d.). | 156 | 0 | 0 | 0 | MPL_64_002-039, MPL_64_040-077, MPL_64_078-115, MPL_64_116-157 |
