# Notes on the sheets

## Steps the pages themselves mark as unverified

| Scan | Words on the sheet | What is open at that point |
|---|---|---|
| 73 | « Sous quelle condition, pour la forme … naturelle sur V, a-t-on … ? » | A calculation follows. Its stated answer is « β purement imaginaire ». |
| 75 | « qui est-il ? » following « α » | The author asks what the remaining parameter represents after computing β. |
| 77 | « Il reste à donner … arg α » | The paragraph goes on to use the normalization of the twelfth power of ω and to specify the sixth power of the argument. |
| 96 | « M′ est-il régulier ?? »; « M″ est-il régulier ?? » | Both questions receive written answers. M′ has a qualification at 2 and M″ at both 2 and 3. The sheet gives no regularity calculation. |
| 98 | « sans exclure 2 (ni 3 ?) » | The parenthesis asks whether 3 must be excluded in the good-reduction assertion. |
| 98 | « mais le … est encore trop lâche » in the slanted left-hand note | The noun is doubtful. The comment follows the proposed identifications of the fibres at a. |
| 98 | « A examiner si les … 4 composantes … “à tangentes distinctes” »; « Comment opère-t-il sur l’espace tangent de Zariski … en a ? » | Distinctness is examined through the group action. The last line breaks after « Donc les quatre ». Scan 100 begins with the assertion that the tangents are equal. |
| 99 | « Question Donner la structure de l’anneau local complété de M … »; « et les équations des diviseurs … » | The sheet displays W[[t]] and gives t for each characteristic. An ellipsis follows the request for the equations. |
| 100 | « vraisemblablement précisément le 2-sous-groupe invariant »; « Il faudrait encore déterminer lequel … c’est » | The subgroup identification is qualified and the choice in the map to the group of order three is left open. |
| 101 | « Il faudrait montrer que cet homomorphisme passe au quotient »; « Or un calcul d’intersections facile (     ) »; « pourvu que l’expression … soit définie » | The first phrase replaces « Je dis ». The parentheses after facile are empty, and the last assertion has an explicit definability condition. The whole passage is cancelled. |

## Titles, dates and page counts on the sheets

| Scan | Visible information |
|---|---|
| 74 | Bibliographical titles under Tohoku, CG, CF, AS and DCA. The respective date or status lines give 1957, 1964, « en préparation », « Mai 1963 » and 1962. The ending mentions « les trois premiers chapitres de GT ». These are citations and a chapter count. |
| 76 | Typed page « - 3 - ». The plan refers to « séminaire Artin 1962 ». The notes give « entre Septembre 1962 et Mars 1963 », « en Février-Mars 1963 », and « SGA 1965 ». These dates belong to the seminar narrative and footnotes. |
| 96 | Two internal headings introduce V(c₄) = M′ and V(c₆) = M″, each followed by a) and b). |
| 97 | Letter heading « Wattignies 9/III/68 ». |
| 99 | Underlined heading « Paramètres locaux du site modulaire ». |
| 101 | (7.11.2), (*), and (**), with references to (7.10.1) and (7.11.1), are formula labels. |

No title sheet or total page count occurs in these eleven images. The small archival numbers are 72–76 and 95–100, recorded as comments in the page files. They differ from the scan numbers by one.
