# SA17: Descentes

| cote | catalogue title | pages | Pro | Codex | API | in this run |
|---|---|---:|---:|---:|---:|---|
| 126 | Descente fidèlement plate. Divers[113] : notes manuscrites (s.d.). | 34 | 0 | 0 | 0 | K126-01, K126-02 |
| 127 | Descente non plate : notes manuscrites (s.d.). | 23 | 0 | 0 | 0 | K127-01, K127-02 |
| 128 | Descente non plate. Modules formels. Cf Notes Murre-Levelt[114] : notes manuscrites (s.d.). | 31 | 0 | 0 | 0 | K128-01, K128-02 |
| 129 | Notes séminaire Montréal (Delale, Labute, Hakim, Messing) : copies de tapuscrits annotés (s.d.), notes manuscrites (s.d.). | 114 | 37 | 0 | 74 | MPL_129_077-115 |
| 130 | Hauteurs et symboles locaux : notes manuscrites (s.d.). | 49 | 0 | 0 | 0 | K130-01, K130-02, K130-03 |
| 131 | Foncteurs représentables par schéma quasi fini : notes manuscrites (s.d.). | 41 | 38 | 0 | 0 | MPL_131 |
| 132 | Plongements dans surfaces (Ladegaillerie) : notes manuscrites (s.d.), tirés à part (1974). | 31 | 0 | 0 | 0 | K132-01, K132-02 |
| 133 | [Groupes de Witt et formes quadratiques, groupes formels] : notes manuscrites (s.d.), tirés à part (1974). | 53 | 50 | 0 | 0 | MPL_133 |
