# SA28: Autour de La "Longue Marche" à travers la théorie de Galois

| cote | catalogue title | pages | Pro | Codex | API | in this run |
|---|---|---:|---:|---:|---:|---|
| 141 | Théorie de Kumer ? + note Alexandre (bi tenseur…) : notes manuscrites (s.d.). | 15 | 16 | 0 | 0 | MPL_143+141 |
| 142 | Action de Galois sur Teichmüller[147] : notes manuscrites (s.d.). | 121 | 119 | 0 | 0 | MPL_142_001-093, MPL_142_094-122 |
| 143 | Paradigmes des courbes algébriques (version provisoire) : notes manuscrites (s.d.). | 33 | 34 | 0 | 0 | MPL_143+141 |
| 144 | [Suite autour de Teichmüller dont] Teichmülleries, 1981-1982 : notes manuscrites (1981-1983, s.d.), lettres (1981, s.d.). | 183 | 176 | 0 | 0 | other part |
| 145 | Printemps 81 (vieille rédaction)[149] : notes manuscrites (s.d.). | 37 | 38 | 0 | 0 | other part |
| 146 | Groupoïdes de Teichmüller et les S0 Tg,!ν, S0 TG : notes manuscrites (s.d.). | 133 | 123 | 0 | 0 | other part |
| 147 | Structure à l'infini des Mg,ν [pages 1 à 90, dont table des matières] : notes manuscrites (s.d.). | 189 | 188 | 0 | 0 | other part |
| 148 | Teichmüller (1983) : notes manuscrites (1983). | 71 | 72 | 0 | 0 | other part |
| 149 | [Autour de La "Longue Marche" à travers la théorie de Galois, pages 1 à 67] : notes manuscrites (s.d.). | 135 | 136 | 0 | 0 | other part |
