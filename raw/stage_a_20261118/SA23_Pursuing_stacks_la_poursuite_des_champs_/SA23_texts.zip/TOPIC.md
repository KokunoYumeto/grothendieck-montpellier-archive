# SA23: Pursuing stacks (À la poursuite des champs). First episode : The Modelizing Story (Histoire de Modèles)

| cote | catalogue title | pages | Pro | Codex | API | in this run |
|---|---|---:|---:|---:|---:|---|
| 134-1 | Lettres Breen 75,76 [correspondance avec Larry Breen, Pierre Deligne et Daniel Quillen] : lettres et copies de lettre (1974-1976, 1984). | 6 | 0 | 5 | 0 | other part |
| 134-2 | [Chapitre I : Take off (pages 1 à 65) et table des matières provisoire][122] : tapuscrits annotés (19/02-22/02/1983), note manuscrite (s.d.), copies de lettre (1975, s.d.). | 184 | 0 | 40 | 107 | other part |
| 134-3 | [Chapitre II (points 14 à 44, pages 1 à 88) : Reflections on homotopical algebra et Notes for Chapter II] : tapuscrit annoté (27/02-26/03/1983). | 93 | 0 | 0 | 93 | other part |
| 134-4 | [Chapitre III (pages 89 à 187) : Homotopy structures] : tapuscrit annoté (27/03-09/04/[1983]). | 100 | 0 | 0 | 99 | other part |
| 134-5 | [Chapitre IV (pages 188 à 319) : Asphericity structures] : tapuscrit annoté (11/04-03/07/[1983]). | 132 | 0 | 0 | 132 | other part |
| 134-6 | [Chapitre V (pages 320 à 442) : Homology and cohomology (abelianization of homotopy types)] : tapuscrit annoté (05/07-23/08/[1983]). | 124 | 0 | 0 | 124 | other part |
| 134-7 | [Chapitre VI (pages 443 à 554) : Schematization] : tapuscrit annoté (24/08-16/09/[1983]). | 112 | 0 | 0 | 112 | other part |
| 134-8 | [Chapitre VII (pages 555 à 593) : Linearization of homotopy types] : tapuscrit annoté (22/10-12/11/[1983]), notes manuscrites (s.d.). | 86 | 44 | 0 | 39 | MPL_134-8_043-087 |
| 135 | Catégories [et Gr-catégories][136] : notes manuscrites (s.d.), copies de tapuscrit annoté (s.d.), copies de manuscrit annoté (s.d.). | 58 | 0 | 0 | 0 | other part |
