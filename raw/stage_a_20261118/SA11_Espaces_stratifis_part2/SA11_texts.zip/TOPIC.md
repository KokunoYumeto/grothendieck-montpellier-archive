# SA11: Espaces stratifiés

| cote | catalogue title | pages | Pro | Codex | API | in this run |
|---|---|---:|---:|---:|---:|---|
| 150 | Espaces stratifiés et voisinages côniques (ou : déploiement des espaces stratifiés) : notes manuscrites (s.d.). | 98 | 97 | 0 | 0 | other part |
| 151 | Topos stratifié (1981) : notes manuscrites (s.d.). | 74 | 72 | 0 | 0 | other part |
| 152 | Catégorie des types de mots [dont arbres plans] : notes manuscrites (s.d.). | 12 | 13 | 0 | 0 | other part |
| 153 | Analyseurs : notes manuscrites (s.d.). | 10 | 11 | 0 | 0 | MPL_121_049-073+153+155 |
| 154 | [Système de pseudo-droites] : notes manuscrites (1983-1984, s.d.). | 175 | 174 | 0 | 0 | MPL_154_001-045, MPL_154_077-126, MPL_154_127-176, MPL_81_038-055+154_046-076, K154-01, K154-02 |
| 155 | [Rigidité de catégories tensorielles ?] : notes manuscrites (s.d.). | 10 | 11 | 0 | 0 | MPL_121_049-073+153+155 |
