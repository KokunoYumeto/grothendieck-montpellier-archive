# SA18: Variétés abéliennes

| cote | catalogue title | pages | Pro | Codex | API | in this run |
|---|---|---:|---:|---:|---:|---|
| 45 | Groupes semi-simples : notes manuscrites (s.d.), tapuscrit annoté (1961). | 79 | 39 | 8 | 0 | MPL_45_033-080, C45-01, K45-01, K45-02 |
| 46 | Schémas en groupes et fibrés principau[x] (Divers) : notes manuscrites (s.d.), tapuscrit (s.d.). | 94 | 42 | 5 | 0 | MPL_46_002-048, C46-01, K46-01, K46-02, K46-03 |
| 47 | Produit de convolution sur les VA [variétés abéliennes] et transformation de Fourier dans les VA [variétés abéliennes] : notes manuscrites (s.d.). | 10 | 11 | 0 | 0 | MPL_16+47+54+44 |
| 48 | Plan EGA VII[41] : notes manuscrites (s.d.). | 5 | 0 | 5 | 0 | H48-01 |
| 49 | Picard des schémas abéliens : notes manuscrites (s.d.). | 9 | 0 | 0 | 0 | K49-01 |
| 50 | Sur bouquin Lang : notes manuscrites (s.d.). | 10 | 0 | 0 | 0 | K50-01 |
| 51 | " Bonne réduction " (Shimura-Koizumi) : notes manuscrites (s.d.). | 22 | 0 | 0 | 0 | K51-01, K51-02 |
| 52 | Théorème de Torelli : notes manuscrites (s.d.). | 13 | 0 | 0 | 0 | K52-01 |
| 53 | Groupes algébriques : notes manuscrites (s.d.), lettre (1973). | 33 | 0 | 33 | 0 | J53-01, J53-02, J53-03, J53-04, J53-05 |
| 54 | Dualité en cohomologie des V. A [variétés abéliennes][44] : notes manuscrites (s.d.). | 7 | 8 | 0 | 0 | MPL_16+47+54+44 |
| 55 | Espaces analytiques : notes manuscrites (s.d.). | 17 | 0 | 0 | 0 | K55-01 |
| 56 | Lefschetz-Hodge - Vanishing cycles[47] : notes manuscrites (s.d.), tiré à part (1962). | 38 | 35 | 0 | 0 | MPL_11_043-058+56, K56-01, K56-02, K56-03 |
