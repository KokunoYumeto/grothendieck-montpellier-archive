# SA19: Jacobiennes

| cote | catalogue title | pages | Pro | Codex | API | in this run |
|---|---|---:|---:|---:|---:|---|
| 43 | Dualité des groupes. Jacobiennes généralisées etc : notes et copies de notes manuscrites (s.d.). | 207 | 46 | 0 | 0 | MPL_43_094-142, K43-01, K43-02, K43-03, K43-04, K43-05, K43-06, K43-07, K43-08, K43-09, K43-10 |
| 44 | Jacobiennes intermédiaires : notes manuscrites (s.d.), lettre (1964). | 8 | 9 | 0 | 0 | MPL_16+47+54+44 |
