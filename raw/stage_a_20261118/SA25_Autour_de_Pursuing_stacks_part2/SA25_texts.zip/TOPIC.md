# SA25: Autour de Pursuing stacks

| cote | catalogue title | pages | Pro | Codex | API | in this run |
|---|---|---:|---:|---:|---:|---|
| 103 | Courrier [Correspondance sur la thèse de Sinh][91] : copies d'article annoté (1974), lettres (1974). | 17 | 0 | 16 | 0 | other part |
| 104 | [Champs (stacks) 1][92] : copies de notes manuscrites (s.d.). | 16 | 0 | 16 | 0 | other part |
| 105 | [Champs (stacks) 2] : notes manuscrites (s.d.). | 52 | 48 | 0 | 0 | other part |
| 106 | [Champs (stacks) 3] : notes manuscrites (s.d.). | 16 | 16 | 0 | 0 | MPL_106+107 |
| 107 | Closed models [notes postérieures à PS ?] : notes manuscrites (s.d.). | 25 | 25 | 0 | 0 | MPL_106+107 |
| 108 | Divers, liste questions : notes manuscrites (s.d.). | 5 | 5 | 0 | 0 | MPL_108+112+113+114+115 |
| 109 | Tables [Corrections et préparation à l'édition][98] : notes manuscrites (s.d.), copies de notes manuscrites annotées (s.d.), copies de tapuscrit annoté (s.d.), copies de notes manuscrites (1983-1984). | 37 | 0 | 27 | 0 | other part |
| 111 | Tapis de Quillen [notes du 10/09/1968][99] : copies de tapuscrit annoté (1968). | 16 | 0 | 0 | 0 | other part |
| 112 | Linéarisation : notes manuscrites (s.d.). | 4 | 4 | 0 | 0 | MPL_108+112+113+114+115 |
| 113 | Abelianization : notes manuscrites (s.d.). | 12 | 12 | 0 | 0 | MPL_108+112+113+114+115 |
| 114 | Asphéricité[102] : notes manuscrites (s.d.). | 5 | 5 | 0 | 0 | MPL_108+112+113+114+115 |
| 115 | " Correspondances " fonctorielles. Dualité des topos : notes manuscrites (s.d.). | 14 | 14 | 0 | 0 | MPL_108+112+113+114+115 |
| 116 | Mapping-cône etc. : notes manuscrites (s.d.). | 10 | 9 | 0 | 0 | MPL_116+117 |
| 117 | Théories homotopiques : notes manuscrites (1983, s.d.). | 25 | 25 | 0 | 0 | MPL_116+117 |
| 118 | Cohomology properties of maps in (Cat) : notes manuscrites (s.d.). | 40 | 0 | 0 | 0 | other part |
