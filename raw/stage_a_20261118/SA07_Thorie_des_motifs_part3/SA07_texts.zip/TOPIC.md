# SA07: Théorie des motifs

| cote | catalogue title | pages | Pro | Codex | API | in this run |
|---|---|---:|---:|---:|---:|---|
| 10 | Catégories tensorielles[11] : notes manuscrites (s.d.), tapuscrits (s.d.). | 197 | 0 | 84 | 0 | other part |
| 11 | Formalisme des correspondances : notes manuscrites (s.d.). | 57 | 54 | 0 | 0 | other part |
| 12 | Généralités (sous-groupes de Galois motiviques) (1964 ?) : notes manuscrites (s.d.), tapuscrit (s.d.). | 167 | 141 | 22 | 0 | other part |
| 13 | Groupe de Galois motivique : notes manuscrites (s.d.), lettre (1965). | 51 | 0 | 44 | 0 | other part |
| 14 | Théorie des cycles algébriques : conjectures de Hodge, Tate, Lefschetz, Weil : notes manuscrites (s.d.), lettre (1965). | 131 | 81 | 0 | 0 | other part |
| 15 | Théorie arithmétique. Théorie de Galois des motifs (1965) : notes manuscites (s.d.), tapuscrit (s.d.). | 227 | 158 | 27 | 0 | MPL_15_195-228+18_002-017, B15-01, B15-02, B15-03, K15-01, K15-02, K15-08 |
| 16 | Formalisme algébrique des correspondances et algèbres de Poincaré-Hodge (cf conjectures standard) : notes manuscrites (s.d.), tapuscrit annoté (s.d.), lettres (1966-1967). | 55 | 54 | 0 | 0 | MPL_16+47+54+44 |
| 18 | Motifs et théorie de Hodge : notes manuscrites (s.d.). | 61 | 60 | 0 | 0 | MPL_15_195-228+18_002-017, MPL_18_018-062 |
| 19 | Topos : notes manuscrites (s.d.). | 95 | 0 | 0 | 0 | other part |
